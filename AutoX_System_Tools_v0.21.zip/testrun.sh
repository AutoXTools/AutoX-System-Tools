#!/bin/sh
# ==============================================================================
# AutoX Boot Forensic Tracer (v0.20 Streamlined)
# Target: Mazda Connect CMU (FW 74.00.324 / Linux ARM i.MX6)
# ==============================================================================
STAGE_1="/jci/scripts/stage_1.sh"
[ ! -f "$STAGE_1" ] && STAGE_1="/jci/scripts/Stage_1.sh"
HOOK_TAG="AUTOX_BOOT_EVAL_HOOK"
RAM_LOG="/tmp/autox_early_boot_ram.txt"
PERSIST_NAND="/tmp/mnt/data_persist/autox"
PERSIST_LOG="$PERSIST_NAND/autox_live_boot_trace.txt"

find_source_script() {
    [ -f "$0" ] && echo "$0" && return 0
    for u in /tmp/mnt/sd* /mnt/sd*; do
        [ -f "$u/testrun.sh" ] && echo "$u/testrun.sh" && return 0
        [ -f "$u/_autox/testrun.sh" ] && echo "$u/_autox/testrun.sh" && return 0
    done
    [ -f "$PERSIST_NAND/testrun.sh" ] && echo "$PERSIST_NAND/testrun.sh" && return 0
    return 1
}

sync_to_usb() {
    _SRC="$1"
    [ ! -f "$_SRC" ] && return 1
    for u in /tmp/mnt/sd* /mnt/sd*; do
        if [ -d "$u" ] && [ "$u" != "$PERSIST_NAND" ]; then
            mount -o remount,rw "$u" 2>/dev/null
            cp -f "$_SRC" "$u/autox_live_boot_trace.txt" 2>/dev/null
        fi
    done
    sync
}

run_trace() {
    echo "# ==========================================================================" > "$RAM_LOG"
    echo "# AUTOX CMU BOOT FORENSIC TRACE (v0.20 Streamlined)" >> "$RAM_LOG"
    echo "# Boot Timestamp: $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'Time Unsynced')" >> "$RAM_LOG"
    echo "# ==========================================================================" >> "$RAM_LOG"
    printf "%-5s | %-6s | %-7s | %-5s | %-5s | %-5s | %-6s | %-14s | %-8s\n" \
           "STEP" "UPTIME" "LOCK" "UI" "VBUS" "OPERA" "LO_NET" "LOAD (1/5/15m)" "FREE_RAM" >> "$RAM_LOG"
    echo "--------------------------------------------------------------------------" >> "$RAM_LOG"

    step=1
    while [ "$step" -le 60 ]; do
        uptime_sec=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo "$step")
        lockstate="CLEAR"
        [ -f /var/lock/*.core ] || [ -f /var/lock/LCK*.core ] && lockstate="LOCKED"
        dbusstate="DOWN"
        dbus-send --session --dest=org.freedesktop.DBus --type=method_call --print-reply /org/freedesktop/DBus org.freedesktop.DBus.ListNames 2>/dev/null | grep -q "com.jci.gui" && dbusstate="ACTIVE"
        vbusstate="DOWN"
        pidof vbus >/dev/null 2>&1 && vbusstate="UP"
        operastate="DOWN"
        pidof opera >/dev/null 2>&1 && operastate="UP"
        lostate="DOWN"
        ifconfig lo 2>/dev/null | grep -q "inet addr" && lostate="UP"
        loadavg=$(awk '{printf "%s %s %s", $1, $2, $3}' /proc/loadavg 2>/dev/null || echo "0.00 0.00 0.00")
        freeram=$(awk '/MemFree/ {free=$2} /Cached/ {cached+=$2} END {printf "%dMB", int((free+cached)/1024)}' /proc/meminfo 2>/dev/null || echo "0MB")

        printf "%3ds   | %5ss  | %-7s | %-5s | %-5s | %-5s | %-6s | %-14s | %-8s\n" \
               "$step" "$uptime_sec" "$lockstate" "$dbusstate" "$vbusstate" "$operastate" "$lostate" "$loadavg" "$freeram" >> "$RAM_LOG"

        if [ $((step % 10)) -eq 0 ]; then
            mkdir -p "$PERSIST_NAND" 2>/dev/null
            cp -f "$RAM_LOG" "$PERSIST_LOG" 2>/dev/null
            sync_to_usb "$RAM_LOG"
        fi
        sleep 1
        step=$((step + 1))
    done

    echo "" >> "$RAM_LOG"
    echo "--- DMESG KERNEL RING BUFFER (TAIL 40) ---" >> "$RAM_LOG"
    dmesg | tail -n 40 >> "$RAM_LOG" 2>&1
    mkdir -p "$PERSIST_NAND" 2>/dev/null
    cp -f "$RAM_LOG" "$PERSIST_LOG" 2>/dev/null
    sync_to_usb "$RAM_LOG"
    rm -f "$RAM_LOG" 2>/dev/null
    exit 0
}

install_hook() {
    echo "==> Installing AutoX Boot Tracer..."
    mount -o remount,rw / 2>/dev/null
    mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null
    mkdir -p "$PERSIST_NAND" 2>/dev/null
    SELF_PATH=$(find_source_script)
    if [ -n "$SELF_PATH" ] && [ -f "$SELF_PATH" ]; then
        cp -f "$SELF_PATH" "$PERSIST_NAND/testrun.sh" 2>/dev/null
        chmod 755 "$PERSIST_NAND/testrun.sh" 2>/dev/null
    fi
    sed -i "/$HOOK_TAG/d" "$STAGE_1" 2>/dev/null
    cat << EOF >> "$STAGE_1"
# === $HOOK_TAG START ===
[ -f "$PERSIST_NAND/testrun.sh" ] && /bin/sh "$PERSIST_NAND/testrun.sh" run & # $HOOK_TAG
# === $HOOK_TAG END ===
EOF
    chmod 755 "$STAGE_1" 2>/dev/null
    mount -o remount,ro / 2>/dev/null
    sync
    echo "[OK] Installed boot tracer hook to $STAGE_1."
    exit 0
}

uninstall_hook() {
    echo "==> Uninstalling AutoX Boot Tracer..."
    mount -o remount,rw / 2>/dev/null
    sed -i "/$HOOK_TAG/d" "$STAGE_1" 2>/dev/null
    rm -f "$PERSIST_NAND/testrun.sh" "$PERSIST_LOG" 2>/dev/null
    mount -o remount,ro / 2>/dev/null
    sync
    echo "[OK] Uninstalled boot tracer hook."
    exit 0
}

show_status() {
    echo "AutoX Boot Tracer Status:"
    grep -q "$HOOK_TAG" "$STAGE_1" 2>/dev/null && echo "  Hook: INSTALLED" || echo "  Hook: NOT INSTALLED"
    [ -f "$PERSIST_NAND/testrun.sh" ] && echo "  Engine: PRESENT ($PERSIST_NAND/testrun.sh)" || echo "  Engine: NOT PRESENT"
    [ -f "$PERSIST_LOG" ] && echo "  Trace: $PERSIST_LOG ($(wc -l < "$PERSIST_LOG" 2>/dev/null) lines)" || echo "  Trace: None"
    exit 0
}

case "$1" in
    install|--install) install_hook ;;
    uninstall|--uninstall) uninstall_hook ;;
    run|--run|start) run_trace ;;
    status|--status) show_status ;;
    *) echo "Usage: $0 [install | uninstall | status | run]"; exit 1 ;;
esac

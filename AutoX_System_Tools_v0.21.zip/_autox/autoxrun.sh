#!/bin/sh
# ==========================================================================
# Filename: autoxrun.sh
# Author: AutoX + AI
# Version: 0.21 (Pre-release)
# Target Platform: Mazda Connect FW 74.00.324 ONLY
# Description: Safe Non-Destructive Installer/Uninstaller with Factory
#              Boot Preservations & Fast Vault Recovery
# File Location: USB_DRIVE/autox/autoxrun.sh
# ==========================================================================

# Guarantee standard system binary search paths for terminal and background daemon shells
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

VERSION="0.21"

# --------------------------------------------------------------------------
# PRE-INSTALL FIRMWARE VERSION CHECK
# --------------------------------------------------------------------------
VERSION_INI="/jci/version.ini"
MIN_SW_VER="74.00.324"

# Validate firmware version is >= 74.00.324
check_cmu_firmware_compatibility() {
    _cur_ver="$1"
    _min_ver="${2:-74.00.324}"

    # 1. First attempt awk comparison if available (handles strings like MAZ_CMU-150_74.00.324A_EU)
    if command -v awk >/dev/null 2>&1; then
        awk -v cur="$_cur_ver" -v min="$_min_ver" '
        BEGIN {
            match(cur, /[0-9]+\.[0-9]+\.[0-9]+/)
            c_str = (RSTART > 0) ? substr(cur, RSTART, RLENGTH) : cur
            match(min, /[0-9]+\.[0-9]+\.[0-9]+/)
            m_str = (RSTART > 0) ? substr(min, RSTART, RLENGTH) : min
            split(c_str, c, ".")
            split(m_str, m, ".")
            for (i = 1; i <= 3; i++) {
                c[i] = c[i] + 0
                m[i] = m[i] + 0
                if (c[i] > m[i]) exit 0
                if (c[i] < m[i]) exit 1
            }
            exit 0
        }'
        return $?
    fi

    # 2. Pure shell / sed fallback
    _c_clean=$(echo "$_cur_ver" | sed -e 's/.*[^0-9]\([0-9]\{2,\}\.[0-9]\{2,\}\.[0-9]\{3,\}\).*/\1/' -e 's/[^0-9.].*//')
    _c_maj=$(echo "$_c_clean" | cut -d'.' -f1)
    _c_min=$(echo "$_c_clean" | cut -d'.' -f2)
    _c_pat=$(echo "$_c_clean" | cut -d'.' -f3)

    [ -z "$_c_maj" ] && _c_maj=0
    [ -z "$_c_min" ] && _c_min=0
    [ -z "$_c_pat" ] && _c_pat=0

    # Minimum: 74.00.324 (maj=74, min=0, pat=324)
    if [ "$_c_maj" -gt 74 ]; then
        return 0
    elif [ "$_c_maj" -eq 74 ]; then
        if [ "$_c_min" -gt 0 ]; then
            return 0
        elif [ "$_c_min" -eq 0 ]; then
            if [ "$_c_pat" -ge 324 ]; then
                return 0
            fi
        fi
    fi
    return 1
}

if [ -f "$VERSION_INI" ]; then
    CURRENT_SW_VER=$(grep -m1 '^JCI_SW_VER=' "$VERSION_INI" 2>/dev/null | tr -d '\r"' | cut -d'=' -f2)
    if [ -n "$CURRENT_SW_VER" ] && ! check_cmu_firmware_compatibility "$CURRENT_SW_VER" "$MIN_SW_VER"; then
        log_install "[AutoX Pre-check FAILED] Unsupported CMU version: '$CURRENT_SW_VER' (Minimum required: '$MIN_SW_VER' or greater)"
        bus_broadcast 1 "Error: Unsupported CMU version ($CURRENT_SW_VER)"
        exit 1
    else
        echo "[AutoX Pre-check OK] Verified compatible CMU firmware: '$CURRENT_SW_VER' (>= $MIN_SW_VER)"
    fi
fi

# Standard NAND Flush & Remount Helpers
cmu_remount_rw() {
    # Try standard and alternative BusyBox remount syntax for /
    mount -o remount,rw / 2>/dev/null || mount -o rw,remount / 2>/dev/null
    
    # Also ensure persistent data partition is read-write
    if [ -d "/tmp/mnt/data_persist" ]; then
        mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null || mount -o rw,remount /tmp/mnt/data_persist 2>/dev/null
    fi
}

cmu_remount_ro() {
    # NAND flush & Read-Only sealing of rootfs ONLY: Dual-sync + sleep commits write journals safely
    sync
    sleep 0.5
    sync
    mount -o remount,ro / 2>/dev/null || mount -o ro,remount / 2>/dev/null
    # Note: Do NOT remount /tmp/mnt/data_persist as ro; it is the car's permanent read-write data partition!
}

# Robust absolute path resolution for BusyBox compatibility
case "$0" in
    /*) AUTOX_SCRIPT_DIR="${0%/*}" ;;
    */*) AUTOX_SCRIPT_DIR="$(cd "${0%/*}" 2>/dev/null && pwd)" ;;
    *) AUTOX_SCRIPT_DIR="$(pwd)" ;;
esac
[ -z "$AUTOX_SCRIPT_DIR" ] && AUTOX_SCRIPT_DIR="$(pwd)"

# Global CLI argument scanner for Silent Mode & Actions
SILENT_MODE=0
[ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] && SILENT_MODE=1
[ "$AUTOX_SILENT_MODE" = "1" ] && SILENT_MODE=1
CLI_ACTION=""

for _arg in "$@"; do
    case "$_arg" in
        silent|--silent|-s)
            SILENT_MODE=1
            ;;
        reinstall|install|--reinstall|--install)
            CLI_ACTION="install"
            ;;
        uninstall|--uninstall)
            CLI_ACTION="uninstall"
            ;;
        dumplogs|dump_logs|carlogs|export_logs)
            CLI_ACTION="dumplogs"
            ;;
        /tmp/mnt/*|/mnt/*)
            if [ -d "$_arg" ]; then
                AUTOX_USB_MOUNT="$_arg"
                USB_ROOT="$_arg"
                USB_MOUNT_POINT="$_arg"
                AUTOX_USB_DIR="$_arg/_autox"
                AUTOX_SCRIPT_DIR="$_arg/_autox"
            fi
            ;;
    esac
done

# If Web GUI or CGI environment detected, ensure silent mode & install action are latched
if [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] || [ "$AUTOX_SILENT_MODE" = "1" ]; then
    SILENT_MODE=1
    [ -z "$CLI_ACTION" ] && CLI_ACTION="install"
fi

# Direct Removable Drive Discovery (Strictly sda1, sdb1, sdc1 - Zero Redundancy)
find_valid_autox_usb() {
    # 1. Fast Path: Use already verified mount from reinstall.cgi / parent caller
    if [ -n "$AUTOX_USB_MOUNT" ] && [ -d "$AUTOX_USB_MOUNT" ]; then
        if [ -f "$AUTOX_USB_MOUNT/_autox/autoxrun.sh" ]; then
            echo "$AUTOX_USB_MOUNT"
            return 0
        fi
    fi

    # 2. Direct check of sda1, sdb1, sdc1 only when executed standalone
    for dev in /tmp/mnt/sdb1 /tmp/mnt/sda1 /tmp/mnt/sdc1 /mnt/sdb1 /mnt/sda1 /mnt/sdc1; do
        if [ -d "$dev" ] && [ -f "$dev/_autox/autoxrun.sh" ]; then
            echo "$dev"
            return 0
        fi
    done
    return 1
}

# Resolve USB root and active package directory
FOUND_USB_ROOT="$(find_valid_autox_usb 2>/dev/null)"
if [ -n "$FOUND_USB_ROOT" ]; then
    USB_ROOT="$FOUND_USB_ROOT"
    USB_MOUNT_POINT="$FOUND_USB_ROOT"
    AUTOX_USB_DIR="$FOUND_USB_ROOT/_autox"
    AUTOX_SCRIPT_DIR="$FOUND_USB_ROOT/_autox"
fi

# Standard Mazda CMU dialog binary
JCI_DIALOG="/jci/tools/jci-dialog"



# Standard helper to remount USB storage Read-Write with full permissions
cmu_remount_usb_rw() {
    if [ -n "$USB_MOUNT_POINT" ] && [ "$USB_MOUNT_POINT" != "/" ]; then
        mount -o remount,rw "$USB_MOUNT_POINT" 2>/dev/null || mount -o rw,remount "$USB_MOUNT_POINT" 2>/dev/null
        mount -o remount,rw,umask=000 "$USB_MOUNT_POINT" 2>/dev/null
    fi
}

# Ensure persistent storage and USB storage partitions are writeable
cmu_remount_rw
cmu_remount_usb_rw

# Dual-Vault Logging Architecture (Section 5 & 12)
# Vault A: CMU internal persistent NAND flash
NAND_LOG_FILE="/tmp/mnt/data_persist/autox/logs/system_service.log"
mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
touch "$NAND_LOG_FILE" 2>/dev/null
chmod 666 "$NAND_LOG_FILE" 2>/dev/null

# Active logging destinations
INSTALL_LOG="$NAND_LOG_FILE"
LOG_FILE="$NAND_LOG_FILE"

# Vault B: Removable USB Mass Storage (mirrored log)
USB_LOG_FILE=""
if [ -n "$AUTOX_SCRIPT_DIR" ] && [ -d "$AUTOX_SCRIPT_DIR" ]; then
    mkdir -p "$AUTOX_SCRIPT_DIR/logs" 2>/dev/null
    if touch "$AUTOX_SCRIPT_DIR/logs/.autox_rw_check" 2>/dev/null; then
        rm -f "$AUTOX_SCRIPT_DIR/logs/.autox_rw_check" 2>/dev/null
        USB_LOG_FILE="$AUTOX_SCRIPT_DIR/logs/system_service.log"
        touch "$USB_LOG_FILE" 2>/dev/null
    fi
fi

# Deduplication Guard: Detect if stdout/stderr was redirected to system_service.log (e.g. via legacy Web GUI / CGI)
# Detach stdout/stderr to /tmp/autox_reinstall.log so raw echoes and command outputs do not create duplicate entries
_STDOUT_TARGET=""
if [ -e "/proc/$$/fd/1" ]; then
    _STDOUT_TARGET=$(readlink "/proc/$$/fd/1" 2>/dev/null || true)
fi
if [ -z "$_STDOUT_TARGET" ] && [ -e "/proc/self/fd/1" ]; then
    _STDOUT_TARGET=$(readlink "/proc/self/fd/1" 2>/dev/null || true)
fi

case "$_STDOUT_TARGET" in
    *system_service.log*)
        exec >>/tmp/autox_reinstall.log 2>&1
        ;;
    *)
        if [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] && [ ! -t 1 ]; then
            exec >>/tmp/autox_reinstall.log 2>&1
        fi
        ;;
esac

log_install() {
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "00:00:00")
    MSG="[$TIMESTAMP] $1"
    echo "$MSG"
    mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
    printf "%s\n" "$MSG" >> "$NAND_LOG_FILE" 2>/dev/null
    if [ -n "$USB_LOG_FILE" ]; then
        ( printf "%s\n" "$MSG" >> "$USB_LOG_FILE" ) 2>/dev/null || true
    fi
}

log_cmd() {
    log_install "$1"
}

bus_broadcast() {
    local step=$1
    local msg=$2
    local ts=$(date +%s 2>/dev/null || echo "0")
    echo "$ts UNINSTALL STATUS $step $msg" > /tmp/autox_com_bus.tmp 2>/dev/null
    mv /tmp/autox_com_bus.tmp /tmp/autox_com_bus 2>/dev/null
    log_install "[STEP $step/6] $msg"
}

# --------------------------------------------------------------------------
# STORAGE SPACE GUARD: /tmp/mnt/data_persist (Minimum 10% partition space)
# Zero fallback policy: strictly queries canonical /tmp/mnt/data_persist
# --------------------------------------------------------------------------
check_persist_space() {
    _TARGET_MNT="/tmp/mnt/data_persist"

    if [ ! -d "$_TARGET_MNT" ]; then
        log_install "[FATAL ERROR] Canonical partition $_TARGET_MNT does not exist. Aborting."
        return 1
    fi

    _DF_LINE=$(df -k "$_TARGET_MNT" 2>/dev/null | tail -n 1)
    if [ -z "$_DF_LINE" ]; then
        log_install "[FATAL ERROR] Unable to query filesystem metrics for $_TARGET_MNT via df. Aborting."
        return 1
    fi

    # Parse Used% and calculate Free% in a single awk pass
    _FREE_PCT=$(echo "$_DF_LINE" | awk '{
        for(i=1; i<=NF; i++) {
            if ($i ~ /%$/) {
                u = $i
                sub(/%/, "", u)
                print (100 - u)
                exit
            }
        }
    }')

    _AVAIL_KB=$(echo "$_DF_LINE" | awk '{print $(NF-2)}')
    _AVAIL_MB=$(( ${_AVAIL_KB:-0} / 1024 ))

    if [ -z "$_FREE_PCT" ]; then
        log_install "[FATAL ERROR] Failed to parse partition usage from df output. Aborting."
        return 1
    fi

    log_install "[STORAGE] Partition: $_TARGET_MNT | Free: ${_AVAIL_MB} MB (${_FREE_PCT}% free) | Minimum Required: 10%"

    if [ "$_FREE_PCT" -lt 10 ]; then
        log_install "[FATAL ERROR] Insufficient storage space on $_TARGET_MNT (${_FREE_PCT}% free < 10% minimum threshold). Aborting."
        
        bus_broadcast 1 "Error: Low storage on /tmp/mnt/data_persist (<10% free)"
        return 1
    fi

    return 0
}

log_install "=========================================================================="
log_install "AutoX System Tools v$VERSION - Execution Engine Started (PID $$)"
log_install "Action: ${CLI_ACTION:-default} | Silent: $SILENT_MODE | Source: ${AUTOX_REINSTALL_SOURCE:-CLI}"
log_install "Persistent Log (Vault A): $NAND_LOG_FILE"
if [ -n "$USB_LOG_FILE" ]; then
    log_install "Mirrored USB Log (Vault B): $USB_LOG_FILE"
fi
log_install "=========================================================================="

show_info() {
    title="$1"
    text="$2"
    log_install "[$title] $text"
    echo "[$title] $text"

    # In silent mode, bypass all screen dialog popups
    if [ "$SILENT_MODE" = "1" ] || [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] || [ "$AUTOX_SILENT_MODE" = "1" ]; then
        return 0
    fi

    killall -q jci-dialog 2>/dev/null || pkill -9 -f "jci-dialog" 2>/dev/null
    sleep 0.5
    if [ -x "$JCI_DIALOG" ]; then
        "$JCI_DIALOG" --info --title="$title" --text="$text" 2>/dev/null &
    fi
}

show_silent_reinstall_dialog() {
    # If invoked from Web GUI, Opera 12 DOM renders live telemetry, so skip native dialog
    if [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ]; then
        return 0
    fi

    log_install "[DIALOG] Spawning background notification: Reinstallation running, auto-reboot upon completion."
    killall -q jci-dialog 2>/dev/null || pkill -9 -f "jci-dialog" 2>/dev/null
    sleep 0.3
    if [ -x "$JCI_DIALOG" ]; then
        "$JCI_DIALOG" --info \
            --title="AutoX Reinstalling" \
            --text="AutoX System Tools is reinstalling in background.\n\n- Do not turn off vehicle or remove USB\n- System will automatically reboot when completed" 2>/dev/null &
    else
        echo "[AutoX Reinstalling] Reinstall in progress. System will automatically reboot when completed."
    fi
}

ask_question() {
    title="$1"
    text="$2"
    ok_label="${3:-OK}"
    cancel_label="${4:-Cancel}"

    # In silent mode, automatically assume "No / Cancel / Skip" (return 1)
    if [ "$SILENT_MODE" = "1" ] || [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] || [ "$AUTOX_SILENT_MODE" = "1" ]; then
        echo "[$title] $text (Silent mode: auto-skipping dialog)"
        return 1
    fi

    # Terminate any lingering dialog processes and release GUI socket/focus
    killall -q jci-dialog 2>/dev/null || pkill -9 -f "jci-dialog" 2>/dev/null
    sleep 0.6

    if [ -x "$JCI_DIALOG" ]; then
        # Mazda Connect jci-dialog standard modal interactive flag is --confirm
        if [ -n "$cancel_label" ]; then
            "$JCI_DIALOG" --confirm --title="$title" --text="$text" --ok-label="$ok_label" --cancel-label="$cancel_label"
            ret=$?
        else
            "$JCI_DIALOG" --confirm --no-cancel --title="$title" --text="$text" --ok-label="$ok_label"
            ret=$?
        fi

        # Allow GUI layer time to settle and dismiss modal window before script continues
        killall -q jci-dialog 2>/dev/null || pkill -9 -f "jci-dialog" 2>/dev/null
        sleep 0.6
        return $ret
    else
        echo "[$title] $text ($ok_label / $cancel_label)"
        return 0
    fi
}

# --------------------------------------------------------------------------
# Decoupled Plugin Architecture: Universal Plugin Resolver & Runner
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Plugin Search & Execution Dispatcher (Strict Persistent Execution)
# --------------------------------------------------------------------------
find_plugin() {
    _P_NAME="$1"
    [ -z "$_P_NAME" ] && return 1

    # Strip potential .sh suffix and autox_ prefix for normalized matching
    _BASE="${_P_NAME%.sh}"
    _BASE_CLEAN="${_BASE#autox_}"

    # Search strictly in NAND persistent plugins
    for _cand in \
        "/tmp/mnt/data_persist/autox/plugins/autox_${_BASE_CLEAN}.sh" \
        "/tmp/mnt/data_persist/autox/plugins/${_BASE}.sh"; do
        if [ -f "$_cand" ]; then
            echo "$_cand"
            return 0
        fi
    done
    return 1
}

run_plugin() {
    _PLUGIN_ID="$1"
    [ -z "$_PLUGIN_ID" ] && { echo "[AutoX Plugin Runner] Usage: autoxrun.sh plugin <plugin_id> [args...]"; return 1; }
    shift
    _TARGET_SCRIPT=$(find_plugin "$_PLUGIN_ID")
    if [ -n "$_TARGET_SCRIPT" ] && [ -f "$_TARGET_SCRIPT" ]; then
        chmod 755 "$_TARGET_SCRIPT" 2>/dev/null
        sed -i 's/\r$//' "$_TARGET_SCRIPT" 2>/dev/null
        /bin/sh "$_TARGET_SCRIPT" "$@"
        return $?
    else
        echo "[AutoX Plugin Runner] ERROR: Plugin '$_PLUGIN_ID' not found in /tmp/mnt/data_persist/autox/plugins/."
        return 1
    fi
}

list_plugins() {
    echo "=========================================================================="
    echo "AutoX System Tools v$VERSION - Decoupled Plugin Ecosystem"
    echo "=========================================================================="
    printf "%-20s %-10s %-12s %-30s\n" "PLUGIN ID" "VERSION" "STATUS" "PATH"
    echo "--------------------------------------------------------------------------"
    
    for _p in /tmp/mnt/data_persist/autox/plugins/*.sh "$AUTOX_SCRIPT_DIR/plugins"/*.sh; do
        if [ -f "$_p" ]; then
            _PNAME=$(basename "$_p" .sh)
            _PVER=$(grep "^VERSION=" "$_p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
            [ -z "$_PVER" ] && _PVER="$VERSION"
            _PSTAT="AVAILABLE"
            if [ -x "/tmp/mnt/data_persist/autox/plugins/$_PNAME.sh" ] || [ -f "/tmp/mnt/data_persist/autox/plugins/$_PNAME.sh" ]; then
                _PSTAT="INSTALLED"
            fi
            printf "%-20s %-10s %-12s %-30s\n" "$_PNAME" "v$_PVER" "$_PSTAT" "$_p"
        fi
    done
    echo "=========================================================================="
}

# Fast-path non-interactive subcommands & decoupled plugin router
case "$1" in
    plugin|--plugin)
        shift
        run_plugin "$@"
        exit $?
        ;;
    plugins|--plugins|list-plugins)
        list_plugins
        exit 0
        ;;
esac

# --------------------------------------------------------------------------
# STEP 1: Remount System Root & USB Storage Read-Write
# --------------------------------------------------------------------------
cmu_remount_rw

USB_MOUNT_POINT=$(df "$AUTOX_SCRIPT_DIR" 2>/dev/null | tail -n 1 | awk '{print $NF}')
if [ -n "$USB_MOUNT_POINT" ]; then
    mount -o remount,rw "$USB_MOUNT_POINT" 2>/dev/null
    mount -o remount,rw,umask=000 "$USB_MOUNT_POINT" 2>/dev/null
fi

SYSTEM_JS="/jci/gui/apps/system/js/systemApp.js"
STAGE_1="/jci/scripts/stage_1.sh"
STAGE_3="/jci/scripts/stage_3.sh"
STAGE_NET="/jci/scripts/start_network.sh"

# Inspect active system hooks to verify installation status
IS_INSTALLED=0
if grep -q "AUTOX_SYSTEMAPP_HOOK" "$SYSTEM_JS" 2>/dev/null || grep -q "SelectAutoX" "$SYSTEM_JS" 2>/dev/null || grep -q "AUTOX BOOT HOOK" "$STAGE_1" 2>/dev/null || grep -q "AUTOX WEB DAEMON" "$STAGE_1" 2>/dev/null || grep -q "AUTOX RECOVERY" "$STAGE_1" 2>/dev/null; then
    IS_INSTALLED=1
fi

DO_UNINSTALL=0
DO_INSTALL=0

if [ "$CLI_ACTION" = "dumplogs" ] || [ "$1" = "dumplogs" ] || [ "$1" = "dump_logs" ] || [ "$1" = "carlogs" ] || [ "$1" = "export_logs" ]; then
    log_install "=========================================================================="
    log_install "[CAR LOGS] Dumping Mazda system & diagnostic logs to USB..."
    log_install "=========================================================================="
    if [ -f "/tmp/mnt/data_persist/autox/plugins/autox_recovery.sh" ]; then
        /bin/sh "/tmp/mnt/data_persist/autox/plugins/autox_recovery.sh" dumplogs
    elif [ -f "$AUTOX_SCRIPT_DIR/plugins/autox_recovery.sh" ]; then
        /bin/sh "$AUTOX_SCRIPT_DIR/plugins/autox_recovery.sh" dumplogs
    fi
    show_message "AutoX System Tools" "Mazda system and diagnostic logs successfully exported to USB (_autox/crash_logs)."
    log_install "[OK] Mazda system logs export complete."
    exit 0
elif [ "$CLI_ACTION" = "uninstall" ] || [ "$1" = "uninstall" ] || [ "$1" = "uninstall_web" ] || [ "$2" = "web" ]; then
    DO_UNINSTALL=1
elif [ "$1" = "test" ] || [ "$1" = "verify" ] || [ "$1" = "--test" ] || [ "$1" = "--verify" ]; then
    shift
    if [ -f "$AUTOX_SCRIPT_DIR/test_verify.sh" ]; then
        exec /bin/sh "$AUTOX_SCRIPT_DIR/test_verify.sh" "$@"
    elif [ -f "/tmp/mnt/data_persist/autox/test_verify.sh" ]; then
        exec /bin/sh "/tmp/mnt/data_persist/autox/test_verify.sh" "$@"
    elif [ -n "$USB_ROOT" ] && [ -f "$USB_ROOT/_autox/test_verify.sh" ]; then
        exec /bin/sh "$USB_ROOT/_autox/test_verify.sh" "$@"
    elif [ -n "$USB_ROOT" ] && [ -f "$USB_ROOT/test.sh" ]; then
        exec /bin/sh "$USB_ROOT/test.sh" "$@"
    else
        echo "[ERROR] test_verify.sh not found."
        exit 1
    fi
elif [ "$CLI_ACTION" = "install" ] || [ "$1" = "install" ] || [ "$1" = "reinstall" ] || [ "$1" = "--install" ] || [ "$SILENT_MODE" -eq 1 ] || [ "$AUTOX_REINSTALL_SOURCE" = "Web GUI" ] || [ "$AUTOX_SILENT_MODE" = "1" ]; then
    DO_INSTALL=1
    if [ "$SILENT_MODE" -eq 1 ] && [ "$AUTOX_REINSTALL_SOURCE" != "Web GUI" ]; then
        show_silent_reinstall_dialog
    fi
elif [ "$IS_INSTALLED" -eq 1 ]; then
    ask_question "AutoX System Tools v$VERSION" \
                 "AutoX is currently installed on this CMU.\n\nSelect an action:" \
                 "Reinstall" \
                 "Cancel"
    if [ $? -eq 0 ]; then
        ask_question "Reinstallation Mode" \
                     "Choose reinstallation execution mode:\n\n- Interactive: Prompts for NAND backup & password\n- Reinstall Silent: Fast automated install" \
                     "Interactive" \
                     "Reinstall Silent"
        if [ $? -eq 0 ]; then
            DO_INSTALL=1
            SILENT_MODE=0
            log_install "[INFO] User confirmed interactive re-install via on-screen dialog."
        else
            DO_INSTALL=1
            SILENT_MODE=1
            export AUTOX_SILENT_MODE=1
            log_install "[INFO] User confirmed silent re-install via on-screen dialog."
            show_silent_reinstall_dialog
        fi
    else
        log_install "[INFO] User canceled re-install via on-screen dialog."
        exit 0
    fi
else
    ask_question "AutoX System Tools v$VERSION" \
                 "Install AutoX System Tools v$VERSION on this Mazda CMU?" \
                 "Install" \
                 "Cancel"
    if [ $? -eq 0 ]; then
        DO_INSTALL=1
        log_install "[INFO] User confirmed fresh install via on-screen dialog."
    else
        log_install "[INFO] User canceled fresh install via on-screen dialog."
        exit 0
    fi
fi

# Pre-install storage space validation on /tmp/mnt/data_persist (requires >= 10% free space)
if [ "$DO_INSTALL" -eq 1 ] && [ "$DO_UNINSTALL" -eq 0 ]; then
    if ! check_persist_space; then
        exit 1
    fi
fi

# --------------------------------------------------------------------------
# STEP 2: UNINSTALL FLOW (Stock Restoration & Complete /tmp/mnt/data_persist/autox Removal)
# --------------------------------------------------------------------------
if [ "$DO_UNINSTALL" -eq 1 ]; then

    # Re-exec from /tmp if executing from /tmp/mnt/data_persist or if CWD is within data_persist
    _CURRENT_CWD="$(pwd 2>/dev/null)"
    _IS_PERSIST=0
    case "$0" in
        *data_persist*) _IS_PERSIST=1 ;;
    esac
    case "$_CURRENT_CWD" in
        *data_persist*) _IS_PERSIST=1 ;;
    esac
    if [ "$_IS_PERSIST" -eq 1 ] && [ "$AUTOX_REEXECED_FROM_TMP" != "1" ]; then
        cp -f "$0" /tmp/autoxrun_uninstall.sh 2>/dev/null || cp -f "$AUTOX_SCRIPT_DIR/autoxrun.sh" /tmp/autoxrun_uninstall.sh 2>/dev/null
        chmod 755 /tmp/autoxrun_uninstall.sh 2>/dev/null
        export AUTOX_REEXECED_FROM_TMP=1
        cd /tmp 2>/dev/null || true
        exec /bin/sh /tmp/autoxrun_uninstall.sh "$@"
    fi

    # Determine uninstallation mode: "nuke" (default) or "save_config"
    UNINSTALL_MODE="nuke"
    for arg in "$@"; do
        case "$arg" in
            save_config|save-config|--save-config|save)
                UNINSTALL_MODE="save_config"
                ;;
            nuke|nuke_all|nuke-all|--nuke)
                UNINSTALL_MODE="nuke"
                ;;
        esac
    done

    # Determine triggering source
    UNINSTALL_SRC="Terminal Execution (SSH / Serial / USB autoxrun.sh)"
    if [ -n "$UNINSTALL_SOURCE" ]; then
        UNINSTALL_SRC="$UNINSTALL_SOURCE"
    fi
    if [ "$2" = "web" ] || [ "$1" = "uninstall_web" ]; then
        UNINSTALL_SRC="AutoX Tools Web Uninstall process (Opera /cgi-bin/uninstall.cgi)"
    fi

    if [ "$UNINSTALL_MODE" = "save_config" ]; then
        log_cmd "[AutoX-Tools v$VERSION] Starting Stock Uninstallation (Save Config Mode)..."
    else
        log_cmd "[AutoX-Tools v$VERSION] Starting Full Stock Uninstallation (Nuke All Mode)..."
    fi
    log_cmd "[INFO] Triggered by: $UNINSTALL_SRC"
    log_cmd "[INFO] Mode: $UNINSTALL_MODE"

    # Immediately ensure partitions are read-write for initial log writing
    cmu_remount_rw

    # Detect active persistent data root (force /tmp/mnt/data_persist)
    DATA_PERSIST_DIR="/tmp/mnt/data_persist"

    # Locate USB mount point deterministically via dynamic discovery & verification
    USB_ROOT="$(find_valid_autox_usb 2>/dev/null)"

    if [ -n "$USB_ROOT" ]; then
        mount -o remount,rw "$USB_ROOT" 2>/dev/null
        mount -o remount,rw,umask=000 "$USB_ROOT" 2>/dev/null
        mkdir -p "$USB_ROOT/_autox/logs" 2>/dev/null
        if touch "$USB_ROOT/_autox/logs/.autox_rw_check" 2>/dev/null; then
            rm -f "$USB_ROOT/_autox/logs/.autox_rw_check" 2>/dev/null
            USB_LOG_FILE="$USB_ROOT/_autox/logs/system_service.log"
            touch "$USB_LOG_FILE" 2>/dev/null
        fi
    fi

    LOG_FILE="$NAND_LOG_FILE"

    # Initialize log directory on persistent NAND
    mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
    chmod 777 /tmp/mnt/data_persist /tmp/mnt/data_persist/autox /tmp/mnt/data_persist/autox/logs 2>/dev/null
    touch /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
    chmod 666 /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null

    log_cmd "=========================================================================="
    log_cmd "AutoX System Tools - CMU Stock Uninstaller Execution"
    log_cmd "Trigger Source: $UNINSTALL_SRC"
    log_cmd "Log File Path: $LOG_FILE"
    log_cmd "Process ID: $$ | Target Platform: Mazda Connect FW 74.00.324"
    log_cmd "=========================================================================="
    log_cmd "[INIT] Uninstallation process kicked off by: $UNINSTALL_SRC"

    bus_broadcast 1 "Stopping background processes and telemetry..."
    if [ "$2" = "web" ]; then
        log_cmd "[INFO] Uninstallation initiated via Web GUI."
    fi
    # Web services kept alive here so GUI can receive COM_BUS updates
    
    if [ -f /tmp/autox_recovery.pid ]; then
        _REC_PID=$(cat /tmp/autox_recovery.pid 2>/dev/null)
        [ -n "$_REC_PID" ] && kill -TERM "$_REC_PID" 2>/dev/null
        rm -f /tmp/autox_recovery.pid 2>/dev/null
    fi
    pkill -9 -f "tweak_" 2>/dev/null || true
    log_cmd "[OK] Background daemons and lockfiles cleaned."
    sleep 2

    bus_broadcast 2 "Remounting CMU root filesystem read-write..."
    cmu_remount_rw
    log_cmd "[OK] Root partition remounted RW."
    sleep 2

    SYSTEM_JS="/jci/gui/apps/system/js/systemApp.js"
    STAGE_1="/jci/scripts/stage_1.sh"
    STAGE_NET="/jci/scripts/start_network.sh"

    bus_broadcast 3 "Surgically clearing AutoX hooks from system files..."
    # Comprehensive surgical reversal of all AutoX hooks via SED (preserves other installed plugins/mods)
    if [ -s "$SYSTEM_JS" ]; then
        sed -i '/\/\* === AUTOX_SYSTEMAPP_HOOK_START === \*\//,/\/\* === AUTOX_SYSTEMAPP_HOOK_END === \*\//d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\/ >>> AUTOX_CALLBACK_START/,/\/\/ <<< AUTOX_CALLBACK_END/d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\/ === AUTOX_TEARDOWN_START ===/,/\/\/ === AUTOX_TEARDOWN_END ===/d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\* AutoX System Tools - Presto-Compliant Clean-Room Hook/,/\}\)\(\)\;/d' "$SYSTEM_JS" 2>/dev/null
        log_cmd "[OK] Surgically removed AutoX hooks from systemApp.js via SED (other plugins preserved)."
    elif [ -f "${SYSTEM_JS}.autox_orig" ]; then
        # Catastrophic fallback only if systemApp.js was lost or empty
        cp -p "${SYSTEM_JS}.autox_orig" "$SYSTEM_JS" 2>/dev/null
        log_cmd "[WARN] Fallback: Restored stock systemApp.js from .autox_orig backup."
    fi
    sed -i '/# === AUTOX/,$d' "$STAGE_1" 2>/dev/null
    sed -i '/# === AutoX/,$d' "$STAGE_1" 2>/dev/null
    sed -i '/autox_recovery/d; /daemon_dispatcher/d; /httpd -p 8080/d; /server\.lua/d; /tcpsvd/d; /AUTOX_DIR/d' "$STAGE_1" 2>/dev/null
    chmod 755 "$STAGE_1" 2>/dev/null
    sed -i '/# === AutoX SSH/,/# === AutoX SSH Server Boot Hook End/d' /jci/scripts/stage_wifi.sh 2>/dev/null
    sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' /jci/scripts/stage_wifi.sh 2>/dev/null
    sed -i '/# === AutoX Wi-Fi/,/&$/d' "$STAGE_NET" 2>/dev/null
    sed -i '/jci-wifiap\.sh/d' "$STAGE_NET" 2>/dev/null
    chmod 755 "$STAGE_NET" 2>/dev/null
    if [ -f "$STAGE_3" ]; then
        sed -i '/# === AUTOX STAGE 3/,$d' "$STAGE_3" 2>/dev/null
        sed -i '/AUTOX-STAGE3/d; /server\.lua/d; /autox_server\.pid/d' "$STAGE_3" 2>/dev/null
        chmod 755 "$STAGE_3" 2>/dev/null
    fi

    # Remove any obsolete legacy .org backup files to reclaim NAND storage
    rm -f /jci/gui/apps/system/js/systemApp.js.org 2>/dev/null
    rm -f /jci/scripts/stage_1.sh.org 2>/dev/null
    rm -f /jci/scripts/start_network.sh.org 2>/dev/null

    log_cmd "[OK] Cleared all residual AutoX hooks and menu entries from systemApp.js, stage_1.sh, and start_network.sh."
    sleep 2

    bus_broadcast 4 "Executing decoupled plugin uninstallation routines..."
    
    # Generic Decoupled Plugin Sweep: Discover and trigger all installed plugins dynamically
    export IS_UNINSTALLING=1
    export AUTOX_UNINSTALLING=1
    for plugin_script in /tmp/mnt/data_persist/autox/plugins/*.sh; do
        if [ -f "$plugin_script" ]; then
            PLUGIN_BASE=$(basename "$plugin_script" .sh)
            log_cmd "--> [PLUGIN RUNNER] Executing standalone $PLUGIN_BASE uninstaller..."
            /bin/sh "$plugin_script" uninstall >/dev/null 2>&1
            log_cmd "[OK] Completed $PLUGIN_BASE uninstallation via plugin contract."
        fi
    done

    # Remove temporary lock files and residual plugin state flags
    rm -f /tmp/autox_*.lock /tmp/autox_*.tmp 2>/dev/null
    if [ "$UNINSTALL_MODE" = "nuke" ]; then
        rm -rf /tmp/mnt/data_persist/autox/plugins/enabled 2>/dev/null
        rm -f /tmp/mnt/data_persist/autox/*_enabled /tmp/mnt/data_persist/autox/data/*_enabled 2>/dev/null
    fi
    sleep 2

    bus_broadcast 5 "Flushing disk buffers and removing flash persistence..."

    # Purge runtime directories and leftover scripts from /tmp/mnt/data_persist/autox according to selected mode
    if [ -d "/tmp/mnt/data_persist/autox" ]; then
        if [ "$UNINSTALL_MODE" = "save_config" ]; then
            # Save Config: Preserve plugins/enabled folder & state flags, remove plugin scripts and other components
            mkdir -p /tmp/autox_saved_enabled 2>/dev/null
            if [ -d "/tmp/mnt/data_persist/autox/plugins/enabled" ]; then
                cp -rf /tmp/mnt/data_persist/autox/plugins/enabled/* /tmp/autox_saved_enabled/ 2>/dev/null
            fi
            rm -rf /tmp/mnt/data_persist/autox/plugins 2>/dev/null
            mkdir -p /tmp/mnt/data_persist/autox/plugins/enabled 2>/dev/null
            cp -rf /tmp/autox_saved_enabled/* /tmp/mnt/data_persist/autox/plugins/enabled/ 2>/dev/null
            rm -rf /tmp/autox_saved_enabled 2>/dev/null
            chmod 777 /tmp/mnt/data_persist/autox/plugins /tmp/mnt/data_persist/autox/plugins/enabled 2>/dev/null

            rm -rf /tmp/mnt/data_persist/autox/org_files 2>/dev/null
            rm -f /tmp/mnt/data_persist/autox/autoxrun.sh /tmp/mnt/data_persist/autox/test_verify.sh 2>/dev/null
            rm -f /tmp/mnt/data_persist/autox/*.lock /tmp/mnt/data_persist/autox/*.tmp 2>/dev/null
        else
            # Nuke All: Full purge of entire autox directory on NAND flash
            rm -rf /tmp/mnt/data_persist/autox 2>/dev/null
        fi
    fi

    if [ "$UNINSTALL_MODE" = "save_config" ]; then
        log_cmd "[OK] Removed /tmp/mnt/data_persist/autox plugin scripts (Preserved /plugins/enabled and log files)"
        log_cmd "[OK] Removed /tmp/mnt/data_persist/autox/org_files"
    else
        log_cmd "[OK] Removed all persistent components from flash"
    fi

    # Ensure persistent log directory and final uninstall audit trail handling
    if [ "$UNINSTALL_MODE" = "save_config" ]; then
        mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
        if [ -f "$LOG_FILE" ]; then
            cp -f "$LOG_FILE" /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
        fi
        chmod 777 /tmp/mnt/data_persist /tmp/mnt/data_persist/autox /tmp/mnt/data_persist/autox/logs 2>/dev/null
        chmod 666 /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
        log_cmd "[SUCCESS] AutoX runtime components removed; persistent config and log folder saved in /tmp/mnt/data_persist/autox/."
    else
        log_cmd "[SUCCESS] AutoX runtime components and all persistent files completely nuked from NAND flash."
    fi

    # Remount root partition Read-Only (leaving /tmp/mnt/data_persist read-write for system and logs)
    cmu_remount_ro
    log_cmd "[OK] Restored read-only root filesystem (mount -o remount,ro /)."

    # Signal completion in status file for web UI
    bus_broadcast 5 "Uninstallation complete. Stock MZD Connect restored. Rebooting..."
    sleep 2

    log_cmd "=========================================================================="
    log_cmd "[COMPLETED] Uninstallation complete. Stock MZD Connect restored."
    log_cmd "=========================================================================="

    # Final mirror copy of completed log: save_config mode on NAND + USB mirrored audit trail
    if [ "$UNINSTALL_MODE" = "save_config" ] && [ -f "$LOG_FILE" ]; then
        mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
        cp -f "$LOG_FILE" /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
        chmod 666 /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
    fi
    if [ -f "$LOG_FILE" ] && [ -n "$USB_LOG_FILE" ]; then
        mkdir -p "$(dirname "$USB_LOG_FILE")" 2>/dev/null
        ( cp -f "$LOG_FILE" "$USB_LOG_FILE" ) 2>/dev/null || true
    fi

    # Mandatory Dual Sync (Section 5.2): Flush USB Mass Storage FAT32 + NAND flash journals
    sync
    sleep 0.5
    sync

    log_cmd "[OK] Uninstallation complete! AutoX System Tools removed."
    log_cmd "[INFO] Restarting Mazda Connect in 5 seconds to finalize stock restoration..."

    # Countdown to clean soft reboot
    sleep 4
    
    # Gracefully terminate AutoX web daemon via recorded PID right before reboot
    if [ -f /tmp/autox_server.pid ]; then
        _SERVER_PID=$(cat /tmp/autox_server.pid 2>/dev/null)
        if [ -n "$_SERVER_PID" ]; then
            kill -TERM "$_SERVER_PID" 2>/dev/null
        fi
        rm -f /tmp/autox_server.pid 2>/dev/null
    fi
    sleep 0.5
    
    # Safely wipe leftover directories now that web processes are terminated
    if [ -d "/tmp/mnt/data_persist/autox" ]; then
        if [ "$UNINSTALL_MODE" = "nuke" ]; then
            rm -rf /tmp/mnt/data_persist/autox 2>/dev/null
        else
            rm -rf /tmp/mnt/data_persist/autox/www 2>/dev/null
        fi
    fi
    sync
    sleep 1
    
    reboot
    exit 0

# --------------------------------------------------------------------------
# STEP 3: INSTALLATION FLOW (If Not Installed or Re-install Selected)
# --------------------------------------------------------------------------
elif [ "$DO_INSTALL" -eq 1 ]; then

    INSTALL_STEP_INDEX=1
    log_install "[AutoX-Tools v$VERSION] Starting Framework Installation..."
    bus_broadcast $INSTALL_STEP_INDEX "Environment & /jci partition check verified"

    # Pre-flight Check: Assert valid removable drive with autorun.sh and _autox/ exists
    VERIFIED_USB="$(find_valid_autox_usb 2>/dev/null)"
    if [ -z "$VERIFIED_USB" ]; then
        log_install "[FATAL ERROR] Installation/Reinstallation aborted: No removable drive in /tmp/mnt/ contains a verified AutoX package (missing autorun.sh and _autox/ directory)."
        bus_broadcast $INSTALL_STEP_INDEX "Error: Valid AutoX USB drive (autorun.sh + _autox/) not found"
        exit 1
    fi
    USB_ROOT="$VERIFIED_USB"
    USB_MOUNT_POINT="$VERIFIED_USB"
    AUTOX_SCRIPT_DIR="$VERIFIED_USB/_autox"
    AUTOX_USB_DIR="$VERIFIED_USB/_autox"
    log_install "[OK] Verified AutoX installation source on removable drive: $USB_ROOT"

        # Ensure persistent data partition is read-write for NAND logging
        mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null
        mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
        chmod -R 777 /tmp/mnt/data_persist/autox 2>/dev/null

        log_install "=========================================================================="
        log_install "AutoX System Tools - CMU Framework Installer Execution"
        log_install "Log File Path: $NAND_LOG_FILE"
        log_install "Process ID: $$ | Target Platform: Mazda Connect FW 74.00.324"
        log_install "=========================================================================="

        # Single validation of canonical Lua binary (MANDATORY per CMU architecture)
        if [ ! -x /usr/bin/lua ]; then
            log_install "[FATAL ERROR] Canonical Lua binary /usr/bin/lua not found or not executable. Aborting."
            bus_broadcast $INSTALL_STEP_INDEX "Error: /usr/bin/lua missing"
            exit 1
        fi
        log_install "[OK] Canonical Lua binary verified (/usr/bin/lua)."

        log_install "[STEP $INSTALL_STEP_INDEX] Remounting CMU root filesystem read-write (mount -o rw,remount /)..."
        cmu_remount_rw
        
        # Verify root filesystem write access
        if touch /test_rw 2>/dev/null && rm -f /test_rw 2>/dev/null; then
            log_install "[OK] Root partition remounted Read-Write successfully."
        else
            log_install "[ERROR] Failed to obtain write permissions on /."
        fi

        # Dynamically locate and remount the active USB drive with full permissions
        if [ -n "$USB_MOUNT_POINT" ] && [ "$USB_MOUNT_POINT" != "/" ]; then
            mount -o remount,rw "$USB_MOUNT_POINT" 2>/dev/null || mount -o rw,remount "$USB_MOUNT_POINT" 2>/dev/null
            mount -o remount,rw,umask=000 "$USB_MOUNT_POINT" 2>/dev/null
            log_install "[OK] Remounted USB storage ($USB_MOUNT_POINT) Read-Write."
        fi

        # --------------------------------------------------------------------------
        # STEP 2: Storage Space Check on /tmp/mnt/data_persist (requires >= 10% free)
        # --------------------------------------------------------------------------
        INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
        bus_broadcast $INSTALL_STEP_INDEX "Checking storage space on /tmp/mnt/data_persist"
        log_install "[STEP $INSTALL_STEP_INDEX] Checking storage space on /tmp/mnt/data_persist (requires >= 10% free)..."
        if ! check_persist_space; then
            bus_broadcast $INSTALL_STEP_INDEX "Error: Low storage on /tmp/mnt/data_persist (<10% free)"
            exit 1
        fi
        log_install "[OK] Storage space verified on /tmp/mnt/data_persist."

        # Optional Full NAND Drive Backup (Step broadcast if selected)
        PERFORM_NAND_BACKUP=0
        if [ "$AUTOX_BACKUP_NAND" = "1" ]; then
            PERFORM_NAND_BACKUP=1
            log_install "[NAND BACKUP] Pre-configured full NAND backup selected."
        elif [ "$SILENT_MODE" -ne 1 ] && [ -z "$AUTOX_REINSTALL_SOURCE" ] && [ "$AUTOX_SILENT_MODE" != "1" ]; then
            ask_question "NAND Drive Backup" \
                         "Do you want to create a full backup of the NAND drive to USB?\n\nNote: This process takes ~5-8 minutes." \
                         "Backup" \
                         "Skip"
            if [ $? -eq 0 ]; then
                PERFORM_NAND_BACKUP=1
                log_install "[NAND BACKUP] User opted to create a full copy of the NAND drive."
            else
                log_install "[INFO] Skipped full NAND drive copy."
            fi
        fi

        if [ $PERFORM_NAND_BACKUP -eq 1 ]; then
            INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
            bus_broadcast $INSTALL_STEP_INDEX "Full NAND system backup to USB (4GB) in progress..."
            MZD_OS_DIR="$AUTOX_SCRIPT_DIR/MZD_OS"
            log_install "[NAND BACKUP] Creating target directory at usb/_autox/MZD_OS ($MZD_OS_DIR)..."
            mkdir -p "$MZD_OS_DIR" 2>/dev/null

            for item in /jci /etc /usr /bin /sbin /lib /var /tmp/mnt/data; do
                if [ -d "$item" ]; then
                    log_install "[NAND BACKUP] Copying $item -> $MZD_OS_DIR/..."
                    mkdir -p "$MZD_OS_DIR$(dirname "$item")" 2>/dev/null
                    cp -rf "$item" "$MZD_OS_DIR/" 2>/dev/null
                fi
            done
            sync
            log_install "[OK] Full NAND drive copy successfully created at usb/_autox/MZD_OS."
            bus_broadcast $INSTALL_STEP_INDEX "Full NAND system backup completed"
        fi

        # Optional CMU Password Setup (Step broadcast if selected)
        if [ "$SILENT_MODE" -ne 1 ] && [ -z "$AUTOX_REINSTALL_SOURCE" ] && [ "$AUTOX_SILENT_MODE" != "1" ] && [ -z "$AUTOX_NEW_PASS" ]; then
            ask_question "CMU Password Setup" \
                         "Set CMU root/SSH password to 'jci'?\n(Recommended for SSH and recovery access)" \
                         "Set jci" \
                         "No Change"
            if [ $? -eq 0 ]; then
                AUTOX_NEW_PASS="jci"
                log_install "[INFO] User selected default password 'jci'."
            else
                log_install "[INFO] User opted for No Change to CMU password."
            fi
        fi

        if [ -n "$AUTOX_NEW_PASS" ]; then
            INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
            bus_broadcast $INSTALL_STEP_INDEX "Setting CMU root password ($AUTOX_NEW_PASS)..."
            log_install "[INFO] Applying configured CMU password..."
            cmu_remount_rw
            
            PASS_HASH=$(echo "$AUTOX_NEW_PASS" | mkpasswd 2>/dev/null | awk '{print $NF}')

            if [ -n "$PASS_HASH" ]; then
                sed -i "s~^cmu:[^:]*~cmu:${PASS_HASH}~" /etc/passwd 2>/dev/null || true
                sed -i "s~^root:[^:]*~root:${PASS_HASH}~" /etc/passwd 2>/dev/null || true
                if [ -f /etc/shadow ]; then
                    sed -i "s~^cmu:[^:]*~cmu:${PASS_HASH}~" /etc/shadow 2>/dev/null || true
                    sed -i "s~^root:[^:]*~root:${PASS_HASH}~" /etc/shadow 2>/dev/null || true
                fi

                if command -v config-update.sh >/dev/null 2>&1; then
                    config-update.sh --start >/dev/null 2>&1
                    [ -f /tmp/configtmp/passwd ] && sed -i "s~^cmu:[^:]*~cmu:${PASS_HASH}~" /tmp/configtmp/passwd 2>/dev/null || true
                    [ -f /tmp/configtmp/passwd ] && sed -i "s~^root:[^:]*~root:${PASS_HASH}~" /tmp/configtmp/passwd 2>/dev/null || true
                    [ -f /tmp/configtmp/shadow ] && sed -i "s~^cmu:[^:]*~cmu:${PASS_HASH}~" /tmp/configtmp/shadow 2>/dev/null || true
                    [ -f /tmp/configtmp/shadow ] && sed -i "s~^root:[^:]*~root:${PASS_HASH}~" /tmp/configtmp/shadow 2>/dev/null || true
                    config-update.sh --commit >/dev/null 2>&1
                fi
                log_install "[OK] CMU user password successfully updated and committed to config partition."
                bus_broadcast $INSTALL_STEP_INDEX "CMU root password successfully updated"
            else
                log_install "[WARN] Could not generate password hash with mkpasswd."
            fi
            cmu_remount_rw
        fi

        INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
        bus_broadcast $INSTALL_STEP_INDEX "Deploying Web UI assets, plugins & Lua daemon"
        if [ "$SILENT_MODE" -ne 1 ] && [ -z "$AUTOX_REINSTALL_SOURCE" ] && [ "$AUTOX_SILENT_MODE" != "1" ]; then
            show_info "AutoX System Tools v$VERSION" "Deploying AutoX files and system hooks...\nPlease wait and do not remove the USB drive."
        fi
        # 1. Deploy Web UI assets to permanent storage (/tmp/mnt/data_persist/autox/www)
        log_install "[STEP $INSTALL_STEP_INDEX] Deploying Web UI assets & plugins to /tmp/mnt/data_persist/autox/..."
        mkdir -p /tmp/mnt/data_persist/autox/www /tmp/mnt/data_persist/autox/www/js /tmp/mnt/data_persist/autox/plugins /tmp/mnt/data_persist/autox/logs /tmp/mnt/data_persist/autox/www/cgi-bin
        chmod 777 /tmp/mnt/data_persist/autox /tmp/mnt/data_persist/autox/logs 2>/dev/null

        if [ -f "$INSTALL_LOG" ] && [ -d "/tmp/mnt/data_persist/autox/logs" ]; then
            cp -f "$INSTALL_LOG" /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
        fi
        cp -rf "$AUTOX_SCRIPT_DIR/index.html" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        sed -i "s/__AUTOX_VERSION__/$VERSION/g" /tmp/mnt/data_persist/autox/www/index.html 2>/dev/null
        if [ -f "$AUTOX_SCRIPT_DIR/plugins.json" ]; then
            cp -f "$AUTOX_SCRIPT_DIR/plugins.json" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        fi
        if [ -f "$AUTOX_SCRIPT_DIR/plugins.js" ]; then
            cp -f "$AUTOX_SCRIPT_DIR/plugins.js" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        fi
        if [ -d "$AUTOX_SCRIPT_DIR/fonts" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/fonts
            cp -rf "$AUTOX_SCRIPT_DIR/fonts/"* /tmp/mnt/data_persist/autox/www/fonts/ 2>/dev/null
        fi
        if [ -d "$AUTOX_SCRIPT_DIR/cgi-bin" ]; then
            cp -rf "$AUTOX_SCRIPT_DIR/cgi-bin/"* /tmp/mnt/data_persist/autox/www/cgi-bin/ 2>/dev/null
            chmod 755 /tmp/mnt/data_persist/autox/www/cgi-bin/* 2>/dev/null
        fi
        if [ -d "$AUTOX_SCRIPT_DIR/plugins/ui" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/plugins/ui
            cp -rf "$AUTOX_SCRIPT_DIR/plugins/ui/"* /tmp/mnt/data_persist/autox/www/plugins/ui/ 2>/dev/null
        fi
        if [ -d "$AUTOX_SCRIPT_DIR/js" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/js
            cp -rf "$AUTOX_SCRIPT_DIR/js/"* /tmp/mnt/data_persist/autox/www/js/ 2>/dev/null
            chmod -R 755 /tmp/mnt/data_persist/autox/www/js 2>/dev/null
        elif [ -n "$USB_ROOT" ] && [ -d "$USB_ROOT/_autox/js" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/js
            cp -rf "$USB_ROOT/_autox/js/"* /tmp/mnt/data_persist/autox/www/js/ 2>/dev/null
            chmod -R 755 /tmp/mnt/data_persist/autox/www/js 2>/dev/null
        elif [ -n "$USB_MOUNT_POINT" ] && [ -d "$USB_MOUNT_POINT/_autox/js" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/js
            cp -rf "$USB_MOUNT_POINT/_autox/js/"* /tmp/mnt/data_persist/autox/www/js/ 2>/dev/null
            chmod -R 755 /tmp/mnt/data_persist/autox/www/js 2>/dev/null
        elif [ -d "/tmp/mnt/sda1/_autox/js" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/www/js
            cp -rf "/tmp/mnt/sda1/_autox/js/"* /tmp/mnt/data_persist/autox/www/js/ 2>/dev/null
            chmod -R 755 /tmp/mnt/data_persist/autox/www/js 2>/dev/null
        fi
        
        # Deploy server.lua HTTP/CGI daemon for Mazda CMU
        if [ -f "$AUTOX_SCRIPT_DIR/server.lua" ]; then
            cp -f "$AUTOX_SCRIPT_DIR/server.lua" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        elif [ -n "$USB_ROOT" ] && [ -f "$USB_ROOT/_autox/server.lua" ]; then
            cp -f "$USB_ROOT/_autox/server.lua" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        elif [ -n "$USB_MOUNT_POINT" ] && [ -f "$USB_MOUNT_POINT/_autox/server.lua" ]; then
            cp -f "$USB_MOUNT_POINT/_autox/server.lua" /tmp/mnt/data_persist/autox/www/ 2>/dev/null
        fi

        # If server.lua is missing from media, dynamically self-generate it to guarantee CGI execution
        if [ ! -f /tmp/mnt/data_persist/autox/www/server.lua ]; then
            log_install "[INFO] Embedding native server.lua HTTP/CGI daemon..."
            cat << 'EOF_LUA' > /tmp/mnt/data_persist/autox/www/server.lua
local socket = require("socket")
local WWW_ROOT = "/tmp/mnt/data_persist/autox/www"
local PORT = 8080
local MIME = { html="text/html", htm="text/html", css="text/css", js="application/javascript", json="application/json", png="image/png", jpg="image/jpeg", jpeg="image/jpeg", svg="image/svg+xml", ttf="font/ttf", otf="font/otf", woff="font/woff", txt="text/plain" }
local function recordPid()
  local f = io.open("/proc/self/stat", "r")
  if f then
    local pid = f:read("*number")
    f:close()
    if pid then
      local pf = io.open("/tmp/autox_server.pid", "w")
      if pf then pf:write(tostring(pid) .. "\n"); pf:close() end
    end
  end
end
recordPid()
local function getWwwRoot() local f = io.open(WWW_ROOT .. "/index.html", "r"); if f then f:close(); return WWW_ROOT end; return "." end
local actualRoot = getWwwRoot()
local server, bindErr = socket.bind("0.0.0.0", PORT)
if not server then
  io.stderr:write("[server.lua] ERROR: Port " .. tostring(PORT) .. " bind failed: " .. tostring(bindErr) .. "\n")
  os.exit(1)
end
server:settimeout(5)
while true do
  local client = server:accept()
  if client then
    client:settimeout(10)
    pcall(function()
      local reqLine = client:receive()
      if reqLine then
        local method, uri = reqLine:match("^(%u+)%s+(%S+)")
        if method and uri then
          local headers = {}
          local line = client:receive()
          while line and line ~= "" and line ~= "\r" do
            local k, v = line:match("^([^:]+):%s*(.+)")
            if k and v then headers[k:lower()] = v:gsub("\r$", "") end
            line = client:receive()
          end
          local body = ""
          if method == "POST" and headers["content-length"] then
            local cl = tonumber(headers["content-length"])
            if cl and cl > 0 then body = client:receive(cl) or "" end
          end
          local path, query = uri:match("^([^?]*)%??(.*)")
          path = path or "/"; query = query or ""
          if path == "" or path == "/" then path = "/index.html" end
          if path:match("^/cgi%-bin/") then
            local scriptName = path:match("^/cgi%-bin/(.+)")
            local scriptPath = actualRoot .. "/cgi-bin/" .. scriptName
            local envPrefix = "QUERY_STRING='" .. query:gsub("'", "'\\''") .. "' REQUEST_METHOD='" .. method .. "' SCRIPT_NAME='" .. path:gsub("'", "'\\''") .. "' CONTENT_LENGTH='" .. tostring(#body) .. "' PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH"
            local cmd
            if method == "POST" and #body > 0 then
              local tmpBody = "/tmp/autox_post_" .. os.time() .. ".tmp"
              local bf = io.open(tmpBody, "wb")
              if bf then bf:write(body); bf:close(); cmd = envPrefix .. " /bin/sh " .. scriptPath .. " < " .. tmpBody .. "; rm -f " .. tmpBody else cmd = envPrefix .. " /bin/sh " .. scriptPath end
            else
              cmd = envPrefix .. " /bin/sh " .. scriptPath
            end
            local p = io.popen(cmd)
            if p then
              local output = p:read("*a") or ""
              p:close()
              if not output:match("^HTTP/%d") and not output:match("^[Cc]ontent%-[Tt]ype:") then
                client:send("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n" .. output)
              else
                client:send("HTTP/1.0 200 OK\r\n" .. output)
              end
            else
              client:send("HTTP/1.0 500 Internal Server Error\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\nCGI failed\n")
            end
          elseif method == "OPTIONS" then
            client:send("HTTP/1.0 200 OK\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
          else
            local filePath = actualRoot .. path
            local f = io.open(filePath, "rb")
            if f then
              local content = f:read("*a"); f:close()
              local ext = path:match("%.([^%.]+)$") or ""
              local ctype = MIME[ext:lower()] or "application/octet-stream"
              client:send("HTTP/1.1 200 OK\r\nContent-Type: " .. ctype .. "\r\nContent-Length: " .. #content .. "\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: public, max-age=86400\r\nConnection: close\r\n\r\n" .. content)
            else
              client:send("HTTP/1.0 404 Not Found\r\nContent-Type: text/plain\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n404 Not Found\n")
            end
          end
        end
      end
    end)
    pcall(function() client:close() end)
  end
end
EOF_LUA
        fi
        chmod 755 /tmp/mnt/data_persist/autox/www/server.lua 2>/dev/null
        sed -i 's/\r$//' /tmp/mnt/data_persist/autox/www/server.lua 2>/dev/null

        # Deploy autoxrun.sh directly under /tmp/mnt/data_persist/autox
        if [ -f "$AUTOX_SCRIPT_DIR/autoxrun.sh" ]; then
            cp -f "$AUTOX_SCRIPT_DIR/autoxrun.sh" /tmp/mnt/data_persist/autox/autoxrun.sh
        elif [ -f "$0" ]; then
            cp -f "$0" /tmp/mnt/data_persist/autox/autoxrun.sh
        fi
        chmod 755 /tmp/mnt/data_persist/autox/autoxrun.sh 2>/dev/null
        sed -i 's/\r$//' /tmp/mnt/data_persist/autox/autoxrun.sh 2>/dev/null

        # Ensure full permissions and CRLF removal on all CGI scripts
        chmod -R 777 /tmp/mnt/data_persist/autox/logs 2>/dev/null
        chmod -R 755 /tmp/mnt/data_persist/autox/www /tmp/mnt/data_persist/autox/www/cgi-bin /tmp/mnt/data_persist/autox/www/js 2>/dev/null
        chmod +x /tmp/mnt/data_persist/autox/www/cgi-bin/* 2>/dev/null
        sed -i 's/\r$//' /tmp/mnt/data_persist/autox/www/cgi-bin/* 2>/dev/null
        log_install "[OK] Deployed autoxrun.sh and Web UI assets."

        # 3. Deploy Plugins directly from USB to /tmp/mnt/data_persist/autox/plugins
        log_install "[STEP 4/6] Deploying all plugins from USB to /tmp/mnt/data_persist/autox/plugins..."
        mkdir -p /tmp/mnt/data_persist/autox/plugins /tmp/mnt/data_persist/autox/plugins/enabled /tmp/mnt/data_persist/autox/logs /tmp/mnt/data_persist/autox/data 2>/dev/null
        rm -rf /tmp/mnt/data_persist/autox/plugins/enabled/* 2>/dev/null
        rm -f /tmp/mnt/data_persist/autox/*_enabled /tmp/mnt/data_persist/autox/data/*_enabled /tmp/autox_*.lock 2>/dev/null
        
        # Purge legacy autox_*.log files from NAND and USB logs
        rm -f /tmp/mnt/data_persist/autox/logs/autox_*.log /tmp/autox_*.log 2>/dev/null
        rm -f /tmp/mnt/data_persist/autox/logs/wifi.log /tmp/mnt/data_persist/autox/logs/ssh.log 2>/dev/null
        if [ -n "$USB_MOUNT_POINT" ] && [ -d "$USB_MOUNT_POINT/_autox/logs" ]; then
            rm -f "$USB_MOUNT_POINT"/_autox/logs/autox_*.log "$USB_MOUNT_POINT"/_autox/logs/wifi.log "$USB_MOUNT_POINT"/_autox/logs/ssh.log 2>/dev/null
        fi
        
        # 1. Locate source plugins directory on USB deterministically
        SRC_PLUGINS_DIR=""
        if [ -n "$AUTOX_SCRIPT_DIR" ] && [ -d "$AUTOX_SCRIPT_DIR/plugins" ]; then
            SRC_PLUGINS_DIR="$AUTOX_SCRIPT_DIR/plugins"
        elif [ -n "$USB_ROOT" ] && [ -d "$USB_ROOT/_autox/plugins" ]; then
            SRC_PLUGINS_DIR="$USB_ROOT/_autox/plugins"
        elif [ -n "$USB_MOUNT_POINT" ] && [ -d "$USB_MOUNT_POINT/_autox/plugins" ]; then
            SRC_PLUGINS_DIR="$USB_MOUNT_POINT/_autox/plugins"
        else
            for mnt in /tmp/mnt/sd*; do
                if [ -d "$mnt/_autox/plugins" ]; then
                    SRC_PLUGINS_DIR="$mnt/_autox/plugins"
                    break
                elif [ -d "$mnt/autox/plugins" ]; then
                    SRC_PLUGINS_DIR="$mnt/autox/plugins"
                    break
                fi
            done
        fi

        # Sync plugin configuration files if present (without overwriting existing CMU configs)
        if [ -d "$AUTOX_SCRIPT_DIR/data" ]; then
            for data_file in "$AUTOX_SCRIPT_DIR/data/"*; do
                if [ -f "$data_file" ]; then
                    _DF_BASE=$(basename "$data_file")
                    if [ ! -f "/tmp/mnt/data_persist/autox/data/$_DF_BASE" ]; then
                        cp -f "$data_file" "/tmp/mnt/data_persist/autox/data/$_DF_BASE" 2>/dev/null
                    fi
                fi
            done
        fi

        # Direct copy of all plugin files and plugin resource directories from USB
        _COPIED_COUNT=0
        if [ -n "$SRC_PLUGINS_DIR" ] && [ -d "$SRC_PLUGINS_DIR" ]; then
            for plugin_item in "$SRC_PLUGINS_DIR"/*; do
                if [ -f "$plugin_item" ]; then
                    _P_BASE=$(basename "$plugin_item")
                    cp -f "$plugin_item" "/tmp/mnt/data_persist/autox/plugins/$_P_BASE" 2>/dev/null
                    chmod 755 "/tmp/mnt/data_persist/autox/plugins/$_P_BASE" 2>/dev/null
                    log_install "[OK] Copied $_P_BASE -> /tmp/mnt/data_persist/autox/plugins/$_P_BASE"
                    _COPIED_COUNT=$((_COPIED_COUNT + 1))
                elif [ -d "$plugin_item" ]; then
                    _DIR_BASE=$(basename "$plugin_item")
                    mkdir -p "/tmp/mnt/data_persist/autox/plugins/$_DIR_BASE" 2>/dev/null
                    cp -rf "$plugin_item"/* "/tmp/mnt/data_persist/autox/plugins/$_DIR_BASE"/ 2>/dev/null
                    log_install "[OK] Copied plugin resource tree: $_DIR_BASE -> /tmp/mnt/data_persist/autox/plugins/$_DIR_BASE"
                fi
            done
            log_install "[SUMMARY] Successfully deployed $_COPIED_COUNT plugin(s) and resources to /tmp/mnt/data_persist/autox/plugins/."
        else
            log_install "[WARN] No USB plugins directory detected. Checking existing persistent plugins..."
        fi

        # Ensure executable permissions and line endings
        chmod 755 /tmp/mnt/data_persist/autox/plugins/*.sh 2>/dev/null
        sed -i 's/\r$//' /tmp/mnt/data_persist/autox/plugins/*.sh 2>/dev/null

        # Generic Decoupled Plugin Installation Loop (re-ensuring write access for each)
        cmu_remount_rw
        for plugin_exec in /tmp/mnt/data_persist/autox/plugins/*.sh; do
            if [ -f "$plugin_exec" ]; then
                PLUGIN_NAME=$(basename "$plugin_exec" .sh)
                log_install "--> [PLUGIN RUNNER] Initializing plugin: $PLUGIN_NAME..."
                /bin/sh "$plugin_exec" install --silent >/dev/null 2>&1 || /bin/sh "$plugin_exec" install >/dev/null 2>&1
                cmu_remount_rw 2>/dev/null
                log_install "[OK] Initialized $PLUGIN_NAME via decoupled plugin lifecycle contract."
            fi
        done

        # Rebuild dynamic plugins.json manifest for Web GUI
        log_install "--> [PLUGIN REGISTRY] Dynamically generating /tmp/mnt/data_persist/autox/www/plugins.json from installed plugins..."
        _TMP_JSON="/tmp/mnt/data_persist/autox/www/plugins.json.tmp"
        _FINAL_JSON="/tmp/mnt/data_persist/autox/www/plugins.json"
        echo '{"plugins":[' > "$_TMP_JSON"
        _P_FIRST=1
        for psh in /tmp/mnt/data_persist/autox/plugins/*.sh; do
            [ -f "$psh" ] || continue
            _META=$(/bin/sh "$psh" --meta 2>/dev/null)
            if [ -z "$_META" ] || echo "$_META" | grep -qv "^{"; then
                _PID=$(grep "^PLUGIN_ID=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                [ -z "$_PID" ] && _PID=$(basename "$psh" .sh | sed 's/^autox_//')
                _PTITLE=$(grep "^PLUGIN_TITLE=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                [ -z "$_PTITLE" ] && _PTITLE=$(grep "^PLUGIN_NAME=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                [ -z "$_PTITLE" ] && _PTITLE="$_PID"
                _PSUB=$(grep "^PLUGIN_SUBTITLE=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                _PORDER=$(grep "^PLUGIN_ORDER=" "$psh" 2>/dev/null | head -n 1 | tr -cd '0-9')
                [ -z "$_PORDER" ] && _PORDER=99
                _PVER=$(grep "^VERSION=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                _PGUI=$(grep "^SHOW_IN_GUI=" "$psh" 2>/dev/null | head -n 1 | cut -d'"' -f2)
                [ -z "$_PGUI" ] && _PGUI="true"
                _STAT=$(/bin/sh "$psh" status 2>/dev/null || echo "DISABLED")
                _META="{\"id\":\"$_PID\",\"title\":\"$_PTITLE\",\"subtitle\":\"$_PSUB\",\"category\":\"tweak\",\"order\":$_PORDER,\"version\":\"$_PVER\",\"status\":\"$_STAT\",\"show_in_gui\":$_PGUI}"
            fi
            if echo "$_META" | grep -q '"show_in_gui":true'; then
                [ $_P_FIRST -eq 0 ] && echo "," >> "$_TMP_JSON"
                _P_FIRST=0
                echo "    $_META" >> "$_TMP_JSON"
            fi
        done
        echo "]}" >> "$_TMP_JSON"
        if grep -q '"id"' "$_TMP_JSON"; then
            mv -f "$_TMP_JSON" "$_FINAL_JSON" 2>/dev/null
            chmod 644 "$_FINAL_JSON" 2>/dev/null
            # Generate clean synchronous plugins.js for instant Frame 1 rendering
            _FINAL_JS="/tmp/mnt/data_persist/autox/www/plugins.js"
            echo "window.AUTOX_PLUGINS = [" > "$_FINAL_JS"
            sed -n '/"id":/p' "$_FINAL_JSON" | sed '$ ! s/$/,/' >> "$_FINAL_JS"
            echo "];" >> "$_FINAL_JS"
            chmod 644 "$_FINAL_JS" 2>/dev/null
            log_install "[OK] Generated dynamic GUI button registry: $_FINAL_JSON and $_FINAL_JS."
        else
            log_install "[WARN] Dynamic plugin generation yielded 0 plugins. Keeping bundled plugins.json."
            rm -f "$_TMP_JSON"
            if [ -f "$AUTOX_SCRIPT_DIR/plugins.json" ]; then
                cp -f "$AUTOX_SCRIPT_DIR/plugins.json" "$_FINAL_JSON" 2>/dev/null
                chmod 644 "$_FINAL_JSON" 2>/dev/null
            fi
            if [ -f "$AUTOX_SCRIPT_DIR/plugins.js" ]; then
                cp -f "$AUTOX_SCRIPT_DIR/plugins.js" "$_FINAL_JS" 2>/dev/null
                chmod 644 "$_FINAL_JS" 2>/dev/null
            fi
        fi

        chmod 755 /tmp/mnt/data_persist/autox/plugins/* 2>/dev/null
        sed -i 's/\r$//' /tmp/mnt/data_persist/autox/plugins/* 2>/dev/null

        INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
        bus_broadcast $INSTALL_STEP_INDEX "Registering plugin manifest & permissions"

        INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
        bus_broadcast $INSTALL_STEP_INDEX "Patching systemApp.js & configuring stage_1.sh boot hook"
        # 4. Inject Native Applications Menu Entry (Slot 3, before CarPlay) & stage_1.sh Boot Hook
        log_install "[STEP $INSTALL_STEP_INDEX] Injecting Applications menu entry & stage_1.sh boot hook..."
        cmu_remount_rw
        chmod 666 "$SYSTEM_JS" 2>/dev/null
        chmod 777 "$STAGE_1" 2>/dev/null

        # Backup pristine stock systemApp.js once before any patch (only if stock registerAppCode is present)
        if [ -s "$SYSTEM_JS" ] && grep -q "registerAppCode" "$SYSTEM_JS" 2>/dev/null; then
            if [ ! -f "${SYSTEM_JS}.autox_orig" ] || ! grep -q "registerAppCode" "${SYSTEM_JS}.autox_orig" 2>/dev/null; then
                cp -p "$SYSTEM_JS" "${SYSTEM_JS}.autox_orig" 2>/dev/null
            fi
        fi

        # Clean existing AutoX hooks surgically using exact SED boundary markers (preserves other mods/plugins)
        sed -i '/\/\* === AUTOX_SYSTEMAPP_HOOK_START === \*\//,/\/\* === AUTOX_SYSTEMAPP_HOOK_END === \*\//d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\/ >>> AUTOX_CALLBACK_START/,/\/\/ <<< AUTOX_CALLBACK_END/d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\/ === AUTOX_TEARDOWN_START ===/,/\/\/ === AUTOX_TEARDOWN_END ===/d' "$SYSTEM_JS" 2>/dev/null
        sed -i '/\/\* AutoX System Tools - Presto-Compliant Clean-Room Hook/,/\}\)\(\)\;/d' "$SYSTEM_JS" 2>/dev/null

        # Append pure Presto-compliant (ES5) Slot 3 native prototype hook
        cat << 'EOF' >> "$SYSTEM_JS"

/* === AUTOX_SYSTEMAPP_HOOK_START === */
/* AutoX System Tools - Presto-Compliant Clean-Room Hook (Slot 3 Visible Injection) */
(function() {
    if (typeof systemApp === "undefined" || !systemApp.prototype) return;
    var p = systemApp.prototype;

    var brandHtml = '<table cellspacing="0" cellpadding="0" style="border:none;margin:0;padding:0;width:auto;height:100%;min-height:68px;display:table;vertical-align:middle;line-height:normal;white-space:nowrap;">' +
        '<tbody><tr style="height:100%;vertical-align:middle;">' +
        '<td style="vertical-align:middle;padding-right:12px;line-height:1;">' +
        '<span style="font-size:38px;font-weight:bold;color:#FFFFFF;letter-spacing:-0.5px;font-family:inherit;vertical-align:middle;display:inline-block;">AutoX</span>' +
        '</td>' +
        '<td style="vertical-align:middle;line-height:1.15;padding-left:4px;">' +
        '<div style="font-size:20px;font-weight:bold;color:#D1D5DB;letter-spacing:0.8px;text-transform:uppercase;font-family:inherit;line-height:1.15;margin:0;padding:0;">SYSTEM TOOLS</div>' +
        '<div style="font-size:21px;font-weight:bold;color:#F59E0B;letter-spacing:0.5px;font-family:inherit;line-height:1.15;margin:0;padding:0;margin-top:2px;">v0.21</div>' +
        '</td>' +
        '</tr></tbody>' +
        '</table>';

    // Helper: Passive _setText prototype hook for List2Ctrl (zero continuous polling, 100% native fonts)
    function installSetTextHook(targetProto) {
        if (!targetProto || targetProto._autoxSetTextHooked) return;
        targetProto._autoxSetTextHooked = true;
        var orig = targetProto._setText;
        if (typeof orig === "function") {
            targetProto._setText = function(li, className, content, preserveHTML) {
                if (typeof content === "string" && (content === "AutoX" || content.indexOf("AutoX") === 0)) {
                    try {
                        var el = li ? (li.querySelector ? li.querySelector(className) : (li.getElementsByClassName ? li.getElementsByClassName(className.replace('.', ''))[0] : null)) : null;
                        if (el) {
                            el.innerHTML = brandHtml;
                            if (el.style) {
                                el.style.overflow = "visible";
                                el.style.position = "absolute";
                                el.style.top = "0";
                                el.style.bottom = "0";
                                el.style.height = "100%";
                                el.style.display = "block";
                                el.style.lineHeight = "normal";
                            }
                            if (el.parentElement && el.parentElement.style) {
                                el.parentElement.style.overflow = "visible";
                            }
                            if (li && li.style) {
                                li.style.overflow = "visible";
                            }
                            return li;
                        }
                    } catch(e) {}
                }
                return orig.apply(this, arguments);
            };
        }
    }

    function tryHook() {
        try {
            if (typeof List2Ctrl !== "undefined" && List2Ctrl.prototype) {
                installSetTextHook(List2Ctrl.prototype);
                return true;
            }
        } catch(e) {}
        return false;
    }
    tryHook();

    // Direct DOM updater for instant visual rendering without waiting for next redraw cycle (zero polling)
    function applyBrandToRow() {
        try {
            var items = document.querySelectorAll ? document.querySelectorAll('.line1') : document.getElementsByClassName('line1');
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (!item) continue;
                var txt = item.textContent || item.innerText || '';
                if (txt && txt.indexOf('AutoX') !== -1 && (!item.children || item.children.length === 0 || txt.indexOf('<') !== -1)) {
                    item.innerHTML = brandHtml;
                    if (item.style) {
                        item.style.overflow = "visible";
                        item.style.position = "absolute";
                        item.style.top = "0";
                        item.style.bottom = "0";
                        item.style.height = "100%";
                        item.style.display = "block";
                        item.style.lineHeight = "normal";
                    }
                    if (item.parentElement && item.parentElement.style) {
                        item.parentElement.style.overflow = "visible";
                    }
                }
            }
        } catch(e) {}
    }

    // 1. Safe master list registration: Slot 3 Native Two-Line Item
    // (Fixes BUG-021: Places AutoX at index 2, directly visible without scrolling to bypass touch scroll snap)
    var _origInit = p._initApplicationsDataList;
    p._initApplicationsDataList = function() {
        tryHook();
        if (typeof _origInit === "function") {
            try { _origInit.call(this); } catch(e) {}
        }
        try {
            if (this._masterApplicationDataList && this._masterApplicationDataList.items) {
                var items = this._masterApplicationDataList.items;
                var found = false;
                for (var i = 0; i < items.length; i++) {
                    if (items[i] && items[i].appData && (items[i].appData.appName === 'autox' || items[i].appData === 'autox')) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    var autoxItem = {
                        appData: { appName: 'autox', isVisible: true },
                        text1: 'AutoX System Tools v0.21',
                        text1Id: null,
                        disabled: false,
                        itemStyle: 'style01',
                        hasCaret: false
                    };
                    if (items.length >= 2) {
                        items.splice(2, 0, autoxItem);
                    } else {
                        items.push(autoxItem);
                    }
                }
            }
        } catch(e) {}
    };

    // Context Transition Hooks (Guarantees List2Ctrl is hooked on initial open and app switching)
    var _origReady = p._readyApplications;
    p._readyApplications = function() {
        tryHook();
        try {
            if (this._currentContextTemplate && this._currentContextTemplate.list2Ctrl) {
                installSetTextHook(this._currentContextTemplate.list2Ctrl.constructor.prototype);
                installSetTextHook(this._currentContextTemplate.list2Ctrl);
            }
        } catch(e) {}
        if (typeof _origReady === "function") {
            try { _origReady.call(this); } catch(e) {}
        }
        applyBrandToRow();
    };

    var _origSetCtxt = p._setCurrentContext;
    p._setCurrentContext = function(contextName) {
        tryHook();
        try {
            if (this._currentContextTemplate && this._currentContextTemplate.list2Ctrl) {
                installSetTextHook(this._currentContextTemplate.list2Ctrl.constructor.prototype);
            }
        } catch(e) {}
        var res;
        if (typeof _origSetCtxt === "function") {
            try { res = _origSetCtxt.apply(this, arguments); } catch(e) {}
        }
        applyBrandToRow();
        return res;
    };

    if (p.templateContextCapture) {
        var _origTCC = p.templateContextCapture;
        p.templateContextCapture = function(templateCtxt) {
            try {
                if (templateCtxt && templateCtxt.template && templateCtxt.template.list2Ctrl) {
                    installSetTextHook(templateCtxt.template.list2Ctrl.constructor.prototype);
                    installSetTextHook(templateCtxt.template.list2Ctrl);
                }
            } catch(e) {}
            if (typeof _origTCC === "function") {
                try { return _origTCC.apply(this, arguments); } catch(e) {}
            }
        };
    }

    if (p.handleControllerEvent) {
        var _origHandleCtrl = p.handleControllerEvent;
        p.handleControllerEvent = function(eventID) {
            tryHook();
            if (typeof _origHandleCtrl === "function") {
                try { return _origHandleCtrl.apply(this, arguments); } catch(e) {}
            }
        };
    }

    // 2. Hardened Vehicle Configuration Array Check (Prevents Early CAN Boot Loops)
    var _origStruct = p._updateApplicationStructure;
    p._updateApplicationStructure = function(vehicleConfiguration) {
        if (typeof _origStruct === "function") {
            try { _origStruct.call(this, vehicleConfiguration); } catch(e) {}
        }
        try {
            if (this._applicationsCtxtWiseAppNames && this._applicationsCtxtWiseAppNames.Applications) {
                var apps = this._applicationsCtxtWiseAppNames.Applications;
                var exists = false;
                for (var j = 0; j < apps.length; j++) {
                    if (apps[j] === 'autox') { exists = true; break; }
                }
                if (!exists) {
                    if (apps.length >= 2) {
                        apps.splice(2, 0, 'autox');
                    } else {
                        apps.push('autox');
                    }
                }
            }
        } catch(e) {}
    };

    // 3. Strict Context Isolation Interceptor & Presto-Compliant Seamless Loader
    function showAutoXLoader() {
        try {
            var loader = document.getElementById('autox_loader');
            if (!loader) {
                loader = document.createElement('div');
                loader.id = 'autox_loader';
                loader.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:99998;background:rgba(14,16,22,0.85);display:table;text-align:center;pointer-events:auto;';
                loader.innerHTML = '<div style="display:table-cell;vertical-align:middle;text-align:center;">' +
                    '<div style="font-family:Arial,Helvetica,sans-serif;font-size:36px;font-weight:bold;color:#FFFFFF;letter-spacing:0.5px;margin-bottom:6px;">' +
                    'AutoX <span style="font-size:22px;color:#D1D5DB;font-weight:normal;">SYSTEM TOOLS</span>' +
                    '</div>' +
                    '<div style="font-family:Arial,Helvetica,sans-serif;font-size:32px;font-weight:bold;color:#00FF66;letter-spacing:2px;text-transform:uppercase;">' +
                    'Loading...' +
                    '</div>' +
                    '</div>';
                var target = document.body || document.documentElement;
                if (target) {
                    target.appendChild(loader);
                }
            } else {
                loader.style.display = 'table';
            }
        } catch(e) {}
    }

    function hideAutoXLoader() {
        try {
            var loader = document.getElementById('autox_loader');
            if (loader) {
                loader.style.display = 'none';
            }
        } catch(e) {}
    }

    var _isAutoXRequested = false;
    var _autoxPreloadTimer = null;

    function revealAutoXFrame(frame) {
        if (!frame) return;
        hideAutoXLoader();
        // 0ms translation: Move into view and set visible
        frame.style.left = '0px';
        frame.style.visibility = 'visible';
        // Force Opera 12 Presto layout reflow flush to guarantee instant paint
        void frame.offsetWidth;
        try {
            if (frame.contentWindow && frame.contentWindow.postMessage) {
                frame.contentWindow.postMessage('resume_telemetry', '*');
            }
            if (frame.contentDocument) {
                var c = frame.contentDocument.getElementById('main-card');
                if (c) c.style.display = 'block';
            }
        } catch(e) {}
    }

    var _origSelect = p._menuItemSelectCallback;
    p._menuItemSelectCallback = function(listCtrlObj, appData, params) {
        var isAutoX = false;
        if (appData && typeof appData === 'object') {
            if (appData.appName === 'autox' || appData.mmuiEvent === 'SelectAutoX') {
                isAutoX = true;
            }
        } else if (appData === 'autox') {
            isAutoX = true;
        }

        if (isAutoX) {
            try {
                _isAutoXRequested = true;
                if (_autoxPreloadTimer) {
                    clearTimeout(_autoxPreloadTimer);
                    _autoxPreloadTimer = null;
                }
                var frame = document.getElementById('autox_frame');
                if (!frame) {
                    // Show semi-transparent "Loading..." screen immediately
                    showAutoXLoader();

                    // Presto-Compliant Creation: Display block off-screen (never display:none)
                    frame = document.createElement('iframe');
                    frame.id = 'autox_frame';
                    frame.setAttribute('allowtransparency', 'true');
                    frame.style.cssText = 'position:fixed;top:0;left:-9999px;width:100%;height:100%;z-index:99999;border:0;background:#101218;display:block;visibility:hidden;';
                    
                    frame.onload = function() {
                        if (_isAutoXRequested) {
                            revealAutoXFrame(frame);
                        }
                    };

                    frame.src = 'http://127.0.0.1:8080/index.html';

                    var target = document.body || document.documentElement;
                    if (target) {
                        target.appendChild(frame);
                    }
                } else {
                    // Warm launch: Instant 0ms reveal from memory
                    revealAutoXFrame(frame);
                }
            } catch(e) {}
            return;
        }

        if (typeof _origSelect === "function") {
            _origSelect.call(this, listCtrlObj, appData, params);
        }
    };

    // 4. Safe Teardown Helper (Presto-Compliant Warm Caching - Never display:none)
    window.closeAutoXFrame = function(isUninstall) {
        try {
            _isAutoXRequested = false;
            hideAutoXLoader();
            var frame = document.getElementById('autox_frame');
            if (frame) {
                if (isUninstall) {
                    frame.style.display = 'none';
                    if (frame.parentNode) frame.parentNode.removeChild(frame);
                    var loader = document.getElementById('autox_loader');
                    if (loader && loader.parentNode) loader.parentNode.removeChild(loader);
                } else {
                    // Presto Warm State: Move off-screen & hide, DO NOT set display:none
                    try {
                        if (frame.contentWindow && frame.contentWindow.postMessage) {
                            frame.contentWindow.postMessage('pause_telemetry', '*');
                        }
                    } catch(e) {}
                    frame.style.visibility = 'hidden';
                    frame.style.left = '-9999px';
                }
            }
            if (typeof window.focus === "function") window.focus();
        } catch(e) {}
    };

    if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
        window.addEventListener('message', function(e) {
            try {
                if (e) {
                    if (e.data === 'close_autox' || e.data === 'uninstall_autox') {
                        if (typeof window.closeAutoXFrame === "function") {
                            window.closeAutoXFrame(e.data === 'uninstall_autox');
                        }
                    } else if (e.data === 'autox_ready') {
                        var f = document.getElementById('autox_frame');
                        if (f && _isAutoXRequested) {
                            revealAutoXFrame(f);
                        }
                    }
                }
            } catch(e) {}
        }, false);
    }

    // 5. 90-Second Deferred Preload: Presto-compliant off-screen loading
    _autoxPreloadTimer = setTimeout(function() {
        try {
            _autoxPreloadTimer = null;
            var frame = document.getElementById('autox_frame');
            if (!frame) {
                frame = document.createElement('iframe');
                frame.id = 'autox_frame';
                frame.setAttribute('allowtransparency', 'true');
                frame.style.cssText = 'position:fixed;top:0;left:-9999px;width:100%;height:100%;z-index:99999;border:0;background:#101218;display:block;visibility:hidden;';
                frame.onload = function() {
                    if (_isAutoXRequested) {
                        revealAutoXFrame(frame);
                    }
                };
                frame.src = 'http://127.0.0.1:8080/index.html';
                var target = document.body || document.documentElement;
                if (target) target.appendChild(frame);
            }
        } catch(e) {}
    }, 90000);
})();
/* === AUTOX_SYSTEMAPP_HOOK_END === */
EOF
        chmod 644 "$SYSTEM_JS" 2>/dev/null
        log_install "[OK] Injected native Applications menu entry into systemApp.js (Slot 3, before CarPlay)."

        # Clean all legacy, unbracketed, or duplicate AutoX hooks from stage_1.sh
        sed -i '/# === AUTOX/,$d' "$STAGE_1" 2>/dev/null
        sed -i '/# === AutoX/,$d' "$STAGE_1" 2>/dev/null
        sed -i '/autox_recovery/d; /daemon_dispatcher/d; /httpd -p 8080/d; /server\.lua/d; /tcpsvd/d; /AUTOX_DIR/d' "$STAGE_1" 2>/dev/null

        # 4a. Clean Single Patch of stage_1.sh (AutoX Recovery & Web Daemon Boot Hook)
        cat << 'EOF' >> "$STAGE_1"

# === AUTOX RECOVERY & WEB DAEMON BOOT HOOK START ===
AUTOX_DIR="/tmp/mnt/data_persist/autox"
[ -d "/jci/autox" ] && AUTOX_DIR="/jci/autox"
(
    # Bounded fast polling for /tmp/mnt/data_persist in kernel mount table (max 24 x 250ms = 6s)
    for _i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24; do
        if grep -q "/tmp/mnt/data_persist" /proc/mounts 2>/dev/null; then
            break
        fi
        usleep 250000 2>/dev/null || sleep 1
    done

    # 1. Recovery service (evaluates Mazda native /data/unexpectedshutdownflag & rapid forensics)
    REC_SCRIPT="$AUTOX_DIR/plugins/autox_recovery.sh"
    if [ -f "$REC_SCRIPT" ]; then
        /bin/sh "$REC_SCRIPT" watch &
    fi

    # 2. Launch AutoX Web Daemon in background with low CPU priority to protect vehicle boot services
    _RUNNING=0
    if [ -f /tmp/autox_server.pid ]; then
        _PID=$(cat /tmp/autox_server.pid 2>/dev/null)
        if [ -n "$_PID" ] && kill -0 "$_PID" 2>/dev/null && grep -q "lua" /proc/$_PID/cmdline 2>/dev/null; then
            _RUNNING=1
        fi
    fi

    if [ "$_RUNNING" -eq 0 ] && ! ps | grep -v grep | grep -q "server\.lua"; then
        LUA_SCRIPT="$AUTOX_DIR/www/server.lua"
        if [ -f "$LUA_SCRIPT" ]; then
            nice -n 15 /usr/bin/lua "$LUA_SCRIPT" &
            echo $! > /tmp/autox_server.pid 2>/dev/null
            echo "AUTOX LUA SERVER LAUNCHED IN STAGE_1 [PID $!]" > /dev/kmsg 2>/dev/null || true
        fi
    fi
) &
# === AUTOX RECOVERY & WEB DAEMON BOOT HOOK END ===
EOF
        chmod 755 "$STAGE_1" 2>/dev/null
        log_install "[OK] Injected AutoX Recovery & Web Daemon boot hook into stage_1.sh."

        # Clean legacy stage_3.sh hook if present (server.lua is now launched strictly on-demand via stage_1.sh watcher)
        if [ -f "$STAGE_3" ]; then
            chmod 777 "$STAGE_3" 2>/dev/null
            sed -i '/# === AUTOX STAGE 3/,$d' "$STAGE_3" 2>/dev/null
            sed -i '/AUTOX-STAGE3/d; /server\.lua/d; /autox_server\.pid/d' "$STAGE_3" 2>/dev/null
        fi

        # 5. Ensure AutoX Web Daemon is active on port 8080 (Zero-Kill preservation)
        log_install "[STEP 6/6] Ensuring AutoX Web Daemon is active on port 8080..."
        _SERVER_RUNNING=0
        if [ -f /tmp/autox_server.pid ]; then
            _SPID=$(cat /tmp/autox_server.pid 2>/dev/null)
            if [ -n "$_SPID" ] && kill -0 "$_SPID" 2>/dev/null; then
                _SERVER_RUNNING=1
            fi
        fi
        if [ "$_SERVER_RUNNING" -eq 0 ] && ps | grep -v grep | grep -q "server\.lua"; then
            _SERVER_RUNNING=1
        fi
        if [ "$_SERVER_RUNNING" -eq 1 ]; then
            log_install "[OK] AutoX Web Daemon active (PID $_SPID) - preserving live connection."
        else
            log_install "[INFO] Launching AutoX Web Daemon (/usr/bin/lua)..."
            nice -n 10 /usr/bin/lua /tmp/mnt/data_persist/autox/www/server.lua &
            echo $! > /tmp/autox_server.pid 2>/dev/null
            sleep 1
        fi
        log_install "[OK] AutoX Web Daemon active on port 8080."

        # Automated self-test of Web Daemon and CGI telemetry pipeline
        log_install "[VERIFY] Running automated self-test of HTTP daemon and CGI engine..."
        _CGI_VERIFIED=0
        for _v_try in 1 2 3 4 5; do
            sleep 1
            _TEST_RESP=$(wget -q -O - -T 2 "http://127.0.0.1:8080/cgi-bin/plugins.cgi?action=drivespace" 2>/dev/null)
            if [ -n "$_TEST_RESP" ]; then
                if echo "$_TEST_RESP" | grep -q "#!/bin/sh"; then
                    log_install "[WARN] CGI test attempt $_v_try: Server returned static script text."
                elif echo "$_TEST_RESP" | grep -q '"partitions"'; then
                    log_install "[OK] Self-test passed! CGI engine and telemetry pipeline verified operational."
                    _CGI_VERIFIED=1
                    break
                fi
            fi
        done
        if [ "$_CGI_VERIFIED" -ne 1 ]; then
            log_install "[WARN] CGI self-test unconfirmed after 5 attempts. Daemon active."
        fi
        log_install "=========================================================================="
        log_install "[COMPLETED] Installation successfully finished."
        log_install "=========================================================================="

        # Dual-sync: Flush USB storage and commit NAND journal, then seal rootfs RO (mount -o ro,remount /)
        log_install "[SEAL] Restoring read-only root filesystem (mount -o ro,remount /)..."
        cmu_remount_ro

        # Verify filesystem is sealed Read-Only
        if touch /test_ro_check 2>/dev/null; then
            rm -f /test_ro_check 2>/dev/null
            log_install "[WARN] Root partition is still writable."
        else
            log_install "[OK] Root partition successfully sealed Read-Only (RO)."
        fi

        INSTALL_STEP_INDEX=$((INSTALL_STEP_INDEX + 1))
        bus_broadcast $INSTALL_STEP_INDEX "Sealing rootfs read-only & finalizing reboot"
        log_install "[STEP $INSTALL_STEP_INDEX] Restoring read-only root filesystem & finalizing reboot..."

        # Allow time for status broadcast to be polled by active GUI
        sleep 2
        
        # Dual-Vault log synchronization: flush complete log to NAND flash and USB drive
        if [ -n "$INSTALL_LOG" ] && [ -f "$INSTALL_LOG" ]; then
            mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null
            cp -f "$INSTALL_LOG" /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
            chmod 666 /tmp/mnt/data_persist/autox/logs/system_service.log 2>/dev/null
            if [ -n "$USB_LOG_FILE" ]; then
                mkdir -p "$(dirname "$USB_LOG_FILE")" 2>/dev/null
                ( cp -f "$INSTALL_LOG" "$USB_LOG_FILE" ) 2>/dev/null || true
            fi
        fi
        for _p_shutdown in /tmp/mnt/data_persist/autox/plugins/*.sh; do
            [ -f "$_p_shutdown" ] && /bin/sh "$_p_shutdown" shutdown >/dev/null 2>&1
        done
        mkdir -p /tmp/mnt/data_persist/autox/recovery 2>/dev/null
        touch /tmp/mnt/data_persist/autox/recovery/clean_reboot 2>/dev/null
        sync
        sleep 0.5
        sync
        if [ "$SILENT_MODE" -ne 1 ] && [ -z "$AUTOX_REINSTALL_SOURCE" ] && [ "$AUTOX_SILENT_MODE" != "1" ]; then
            killall -q jci-dialog 2>/dev/null
            sleep 0.3
            show_info "AutoX Complete" "AutoX System Tools v$VERSION installed successfully!\nRestarting Mazda Connect in 5 seconds..."
            sleep 5
            killall -q jci-dialog 2>/dev/null
        else
            killall -q jci-dialog 2>/dev/null
        fi
        /sbin/reboot 2>/dev/null || reboot 2>/dev/null || /bin/reboot 2>/dev/null || (echo 1 > /proc/sys/kernel/sysrq 2>/dev/null; echo b > /proc/sysrq-trigger 2>/dev/null)
        exit 0
fi
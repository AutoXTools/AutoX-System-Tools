/**
 * AutoX Core Subsystem (Clean-Room Modular Architecture)
 * Target Platform: Mazda Connect IHU (Opera 12 Presto) & Modern Web Simulator
 */
(function(window, document) {
  'use strict';

  window.AutoX = window.AutoX || {};

  // Utility String Helpers
  AutoX.trim = function(str) {
    if (!str) return '';
    return String(str).replace(/^\s+|\s+$/g, '');
  };

  AutoX.escapeHtml = function(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };

  AutoX.parseJson = function(text) {
    if (!text) return null;
    try {
      var str = AutoX.trim(text);
      var start = str.indexOf('{');
      var end = str.lastIndexOf('}');
      if (start !== -1 && end !== -1 && end > start) {
        return JSON.parse(str.substring(start, end + 1));
      }
      return JSON.parse(str);
    } catch(e) {
      return null;
    }
  };

  // Centralized System Logger
  AutoX.log = function(msg) {
    try {
      var container = document.getElementById('term-logs-container');
      var output = document.getElementById('term-output');
      var time = new Date().toTimeString().split(' ')[0];
      var div = document.createElement('div');
      div.className = 'term-log-line';
      div.innerHTML = '<span style="color: #00FF66; font-weight: bold;">[' + time + ']</span> ' + AutoX.escapeHtml(msg);
      
      if (container) {
        container.appendChild(div);
      } else if (output) {
        output.appendChild(div);
      }

      if (AutoX.ScrollEngine && typeof AutoX.ScrollEngine.scrollToBottom === 'function') {
        AutoX.ScrollEngine.scrollToBottom('term-output');
      } else if (output) {
        output.scrollTop = output.scrollHeight;
      }
    } catch(err) {}
  };

  AutoX.clearLogs = function() {
    try {
      var container = document.getElementById('term-logs-container');
      var time = new Date().toTimeString().split(' ')[0];
      if (container) {
        container.innerHTML = '<div class="term-log-line"><span style="color: #00FF66; font-weight: bold;">[' + time + ']</span> Log cleared. AutoX System Tools active.</div>';
      }
    } catch(e) {}
  };

  // Keyboard Isolation to prevent CMU Commander Back conflicts on input typing
  AutoX.bindKeyboardIsolation = function(inputEl) {
    if (!inputEl || inputEl._autoxIsolated) return;
    inputEl._autoxIsolated = true;

    var trapHandler = function(e) {
      if (e.stopPropagation) e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    };

    inputEl.addEventListener('keydown', trapHandler, false);
    inputEl.addEventListener('keyup', trapHandler, false);
    inputEl.addEventListener('keypress', trapHandler, false);
  };

  // Global Keydown Handler for Exit / Isolation
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', function(e) {
      var activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
        if (e.keyCode === 8 || e.keyCode === 13 || e.keyCode === 27) {
          if (e.stopPropagation) e.stopPropagation();
          if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        }
      } else {
        var code = e.keyCode || e.which;
        if (e.key === 'Escape' || code === 27 || code === 8) {
          AutoX.close();
        }
      }
    }, true);
  }

  // Safe Cross-Window / Simulator Messaging (Non-destructive)
  AutoX.sendMessage = function(msg) {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage(msg, '*');
      }
    } catch(e) {}
  };

  // Mazda Connect Framework Context Exit & Teardown
  AutoX.close = function(msg) {
    msg = msg || 'close_autox';
    var isUninstall = (msg === 'uninstall_autox');

    // Dismiss any open modal sub-screens so reopening AutoX always presents the clean main dashboard
    try {
      if (AutoX.Modal && typeof AutoX.Modal.close === 'function') {
        AutoX.Modal.close('console-modal');
        AutoX.Modal.close('drive-space-modal');
        AutoX.Modal.close('recovery-modal');
        AutoX.Modal.close('aamod-reboot-modal');
      }
      var modals = ['console-modal', 'drive-space-modal', 'recovery-modal', 'aamod-reboot-modal'];
      for (var m = 0; m < modals.length; m++) {
        var modalEl = document.getElementById(modals[m]);
        if (modalEl) modalEl.style.display = 'none';
      }
      // Guarantee main-card is visible in memory for warm re-opens
      var card = document.getElementById('main-card');
      if (card) card.style.display = 'block';
    } catch(e) {}

    setTimeout(function() {
      if (isUninstall) {
        try {
          if (window.parent && window.parent.framework) {
            var sysApp = window.parent.framework.getAppInstance('system');
            if (sysApp && sysApp._masterApplicationDataList && sysApp._masterApplicationDataList.items) {
              var filtered = [];
              for (var i = 0; i < sysApp._masterApplicationDataList.items.length; i++) {
                var itm = sysApp._masterApplicationDataList.items[i];
                if (!itm.appData || (itm.appData.appName !== 'autox' && itm.appData !== 'autox')) {
                  filtered.push(itm);
                }
              }
              sysApp._masterApplicationDataList.items = filtered;
            }
          }
        } catch(e) {}
      }

      // 1. Invoke closeAutoXFrame on parent window if available
      try {
        if (window.parent && typeof window.parent.closeAutoXFrame === 'function') {
          window.parent.closeAutoXFrame(isUninstall);
        }
      } catch(e) {}

      // 2. Direct parent DOM frame cleanup fallback (ONLY on uninstall)
      try {
        if (isUninstall && window.parent && window.parent.document) {
          var frame = window.parent.document.getElementById('autox_frame');
          if (frame && frame.parentNode) {
            frame.parentNode.removeChild(frame);
          }
        }
      } catch(e) {}

      // 3. Restore parent window focus for touch and commander input
      try {
        if (window.parent && typeof window.parent.focus === 'function') {
          window.parent.focus();
        }
      } catch(e) {}

      try { window.location.hash = msg; } catch(e) {}

      // 4. Send postMessage to parent
      try {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage(msg, '*');
        }
      } catch(e) {}

      // 5. Only pop context if window itself (not parent) has a local framework instance
      try {
        if (window.framework && typeof window.framework.popContext === 'function') {
          window.framework.popContext();
        }
      } catch(e) {}

      try {
        if (window.opera && typeof window.close === 'function') {
          window.close();
        }
      } catch(e) {}
    }, 15);
  };

  // Backwards compatibility aliases for inline handlers
  window.log = AutoX.log;
  window.safeTrim = AutoX.trim;
  window.escapeHtml = AutoX.escapeHtml;
  window.parseJsonSafe = AutoX.parseJson;
  window.sendParentMessage = AutoX.sendMessage;
  window.closeAutoX = AutoX.close;

})(window, document);

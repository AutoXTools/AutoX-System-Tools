/**
 * AutoX Universal Modal & Plugin Sub-Screen Manager
 * Target Platform: Opera 12 Presto & Modern Browsers
 */
(function(window, document) {
  'use strict';

  window.AutoX = window.AutoX || {};

  AutoX.Modal = {
    open: function(modalId) {
      var modal = document.getElementById(modalId);
      if (modal) {
        modal.style.display = 'block';
      }
    },
    close: function(modalId) {
      var modal = document.getElementById(modalId);
      if (modal) {
        modal.style.display = 'none';
      }
    }
  };

  window.openConsoleModal = function() {
    AutoX.Modal.open('console-modal');
  };

  window.closeConsoleModal = function() {
    AutoX.Modal.close('console-modal');
  };

  window.openAamodRebootModal = function() {
    AutoX.Modal.open('aamod-reboot-modal');
  };

  window.closeAamodRebootModal = function() {
    AutoX.Modal.close('aamod-reboot-modal');
  };

})(window, document);

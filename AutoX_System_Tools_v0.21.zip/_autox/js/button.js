/**
 * AutoX Clean-Room Automotive Tactile Button & Touch Engine
 * 
 * Target Platform: Mazda Connect IHU (Opera 12 Presto, Linux ARM) & Modern Web Simulator
 * 
 * Key Principles Learned from Automotive GUI Engineering:
 * 1. 0ms instant visual depression on physical touch contact
 * 2. Dynamic bounding-box calculation with generous road-vibration hysteresis (TOUCH_SLOP)
 * 3. Bidirectional sliding tolerance (finger sliding out un-highlights; sliding back in restores highlight)
 * 4. Document-level release tracking ensuring 0ms action execution without dropped taps
 * 5. Synthetic ghost click suppression across Presto & modern engines
 * 6. Global event delegation supporting all views, modals, and dynamically loaded plugin components
 */
(function(window, document) {
  'use strict';

  window.AutoX = window.AutoX || {};

  var TOUCH_SLOP = 22; // 22px boundary margin for in-car road vibrations & finger roll
  var SYNTHETIC_CLICK_LOCKOUT_MS = 450; // Lockout window for slow synthetic browser clicks

  var currentSession = null;
  var lastTouchEndTime = 0;
  var isProgrammaticDispatch = false;

  function findInteractiveTarget(startEl) {
    var el = startEl;
    while (el && el !== document.body && el !== document.documentElement) {
      if (el.nodeType !== 1) {
        el = el.parentNode;
        continue;
      }

      var cls = el.className || '';
      if (typeof cls === 'string') {
        if (
          cls.indexOf('plugin-button') !== -1 ||
          cls.indexOf('status-badge') !== -1 ||
          cls.indexOf('close-btn') !== -1 ||
          cls.indexOf('drive-modal-close-btn') !== -1 ||
          cls.indexOf('btn-') !== -1 ||
          cls.indexOf('autox-logo-brand') !== -1 ||
          cls.indexOf('drive-mount-pill') !== -1
        ) {
          return el;
        }
      }

      var tag = el.tagName ? el.tagName.toUpperCase() : '';
      if (tag === 'BUTTON' || tag === 'A') {
        return el;
      }

      if (el.getAttribute) {
        if (
          el.getAttribute('onclick') ||
          el.getAttribute('data-action') ||
          el.getAttribute('data-fast-touch') ||
          el.getAttribute('role') === 'button'
        ) {
          return el;
        }
      }

      el = el.parentNode;
    }
    return null;
  }

  function addPressedStyle(el) {
    if (!el || typeof el.className !== 'string') return;
    if (el.className.indexOf('pressed') === -1) {
      el.className = (el.className + ' pressed').replace(/\s+/g, ' ').trim();
    }
  }

  function removePressedStyle(el) {
    if (!el || typeof el.className !== 'string') return;
    if (el.className.indexOf('pressed') !== -1) {
      el.className = el.className.replace(/\bpressed\b/g, '').replace(/\s+/g, ' ').trim();
    }
  }

  function getElementRect(el) {
    if (!el || !el.getBoundingClientRect) return null;
    try {
      var r = el.getBoundingClientRect();
      return {
        left: r.left,
        top: r.top,
        right: r.right,
        bottom: r.bottom,
        width: r.width || (r.right - r.left),
        height: r.height || (r.bottom - r.top)
      };
    } catch(e) {
      return null;
    }
  }

  function isPointInsideRectWithSlop(x, y, rect, slop) {
    if (!rect) return true; // Fallback to allowing tap if rect cannot be read
    var pad = typeof slop === 'number' ? slop : TOUCH_SLOP;
    return (
      x >= (rect.left - pad) &&
      x <= (rect.right + pad) &&
      y >= (rect.top - pad) &&
      y <= (rect.bottom + pad)
    );
  }

  function executeButtonAction(target) {
    if (!target) return;

    // Suppress redundant synthetic click events
    lastTouchEndTime = new Date().getTime();
    isProgrammaticDispatch = true;

    try {
      // 1. Direct onclick handler execution
      if (typeof target.onclick === 'function') {
        target.onclick.call(target);
      } 
      // 2. Standard DOM .click() dispatch (works on <button>, <a>, etc.)
      else if (typeof target.click === 'function') {
        target.click();
      } 
      // 3. Synthetic MouseEvent dispatch for Opera 12 Presto / custom elements
      else if (document.createEvent) {
        var evt = document.createEvent('MouseEvents');
        evt.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
        target.dispatchEvent(evt);
      }
    } catch(err) {
      if (typeof target.onclick === 'function') {
        try { target.onclick.call(target); } catch(e) {}
      }
    } finally {
      isProgrammaticDispatch = false;
    }
  }

  // =========================================================================
  // TOUCH EVENT LIFECYCLE (Touchscreen / IHU Display)
  // =========================================================================

  function handleTouchStart(e) {
    if (!e.touches || e.touches.length > 1) return;
    var touch = e.touches[0];
    var target = findInteractiveTarget(e.target);
    if (!target) return;

    // Ignore busy / disabled elements
    if (target.className && (target.className.indexOf('busy') !== -1 || target.className.indexOf('disabled') !== -1)) {
      return;
    }

    var rect = getElementRect(target);

    currentSession = {
      target: target,
      rect: rect,
      startX: touch.clientX,
      startY: touch.clientY,
      isHighlighted: true,
      mode: 'touch'
    };

    addPressedStyle(target);
  }

  function handleTouchMove(e) {
    if (!currentSession || currentSession.mode !== 'touch' || !e.touches || e.touches.length === 0) return;
    var touch = e.touches[0];
    var isInside = isPointInsideRectWithSlop(touch.clientX, touch.clientY, currentSession.rect, TOUCH_SLOP);

    if (isInside && !currentSession.isHighlighted) {
      currentSession.isHighlighted = true;
      addPressedStyle(currentSession.target);
    } else if (!isInside && currentSession.isHighlighted) {
      currentSession.isHighlighted = false;
      removePressedStyle(currentSession.target);
    }
  }

  function handleTouchEnd(e) {
    if (!currentSession || currentSession.mode !== 'touch') return;
    var session = currentSession;
    currentSession = null;

    removePressedStyle(session.target);

    if (session.isHighlighted) {
      if (e.cancelable && e.preventDefault) {
        e.preventDefault();
      }
      executeButtonAction(session.target);
    }
  }

  function handleTouchCancel() {
    if (currentSession && currentSession.mode === 'touch') {
      removePressedStyle(currentSession.target);
      currentSession = null;
    }
  }

  // =========================================================================
  // MOUSE & DESKTOP CONTROLLER LIFECYCLE
  // =========================================================================

  function handleMouseDown(e) {
    // If a touch gesture completed recently, ignore mouse emulation
    if (new Date().getTime() - lastTouchEndTime < SYNTHETIC_CLICK_LOCKOUT_MS) {
      return;
    }

    var target = findInteractiveTarget(e.target);
    if (!target) return;
    if (target.className && (target.className.indexOf('busy') !== -1 || target.className.indexOf('disabled') !== -1)) {
      return;
    }

    var rect = getElementRect(target);

    currentSession = {
      target: target,
      rect: rect,
      startX: e.clientX,
      startY: e.clientY,
      isHighlighted: true,
      mode: 'mouse'
    };

    addPressedStyle(target);
  }

  function handleMouseMove(e) {
    if (!currentSession || currentSession.mode !== 'mouse') return;
    var isInside = isPointInsideRectWithSlop(e.clientX, e.clientY, currentSession.rect, TOUCH_SLOP);

    if (isInside && !currentSession.isHighlighted) {
      currentSession.isHighlighted = true;
      addPressedStyle(currentSession.target);
    } else if (!isInside && currentSession.isHighlighted) {
      currentSession.isHighlighted = false;
      removePressedStyle(currentSession.target);
    }
  }

  function handleMouseUp(e) {
    if (!currentSession || currentSession.mode !== 'mouse') return;
    var session = currentSession;
    currentSession = null;

    removePressedStyle(session.target);

    if (session.isHighlighted) {
      executeButtonAction(session.target);
    }
  }

  // Capture phase click guard to suppress delayed 300ms synthetic browser clicks
  function handleCaptureClick(e) {
    if (isProgrammaticDispatch) {
      return true;
    }

    if (new Date().getTime() - lastTouchEndTime < SYNTHETIC_CLICK_LOCKOUT_MS) {
      if (e.preventDefault) e.preventDefault();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      if (e.stopPropagation) e.stopPropagation();
      return false;
    }
    return true;
  }

  // =========================================================================
  // GLOBAL INITIALIZATION
  // =========================================================================

  function init() {
    if (typeof document === 'undefined' || !document.addEventListener) return;

    // Touch listeners
    document.addEventListener('touchstart', handleTouchStart, false);
    document.addEventListener('touchmove', handleTouchMove, false);
    document.addEventListener('touchend', handleTouchEnd, false);
    document.addEventListener('touchcancel', handleTouchCancel, false);

    // Mouse listeners
    document.addEventListener('mousedown', handleMouseDown, false);
    document.addEventListener('mousemove', handleMouseMove, false);
    document.addEventListener('mouseup', handleMouseUp, false);

    // Click filter (Capture phase)
    document.addEventListener('click', handleCaptureClick, true);
  }

  AutoX.ButtonEngine = {
    init: init,
    executeAction: executeButtonAction,
    findTarget: findInteractiveTarget
  };

  // Auto-start button engine globally
  init();

})(window, document);

/**
 * AutoX Modular Touch & Momentum Scroll Engine
 * Target Platform: Opera 12 Presto & Modern Browsers
 */
(function(window, document) {
  'use strict';

  window.AutoX = window.AutoX || {};

  var isDragging = false;
  var activeViewport = null;
  var activeContent = null;
  var activeIndicator = null;

  var startY = 0;
  var startTop = 0;
  var startTime = 0;
  var trackedPoints = [];

  var cachedVHeight = 0;
  var cachedCHeight = 0;
  var cachedMinTop = 0;
  var cachedMaxBarTop = 0;
  var cachedBarHeight = 0;

  var TOUCH_GAIN = 1.35;

  function findViewport(el) {
    while (el && el !== document.body && el !== document.documentElement) {
      if (el.nodeType !== 1) { el = el.parentNode; continue; }
      if (el.classList && el.classList.contains('autox-scroll-viewport')) {
        return el;
      }
      el = el.parentNode;
    }
    return null;
  }

  function setElementPosition(el, topPos, transitionMs) {
    if (!el) return;
    var ms = transitionMs || 0;
    var durString = ms + 'ms';

    el.style.oTransitionDuration = durString;
    el.style.webkitTransitionDuration = durString;
    el.style.transitionDuration = durString;
    el.style.top = topPos + 'px';
  }

  function updateIndicator(indicator, topPos, transitionMs) {
    if (!indicator || cachedMinTop >= 0) {
      if (indicator) indicator.style.opacity = '0';
      return;
    }

    var ratio = cachedMinTop !== 0 ? (topPos / cachedMinTop) : 0;
    var barTop = Math.max(4, Math.min(cachedMaxBarTop + 4, Math.round(ratio * cachedMaxBarTop) + 4));

    indicator.style.height = cachedBarHeight + 'px';
    setElementPosition(indicator, barTop, transitionMs);
    indicator.style.opacity = '1';
  }

  function handleStart(e) {
    var point = e.touches ? e.touches[0] : e;
    if (!point) return;

    var viewport = findViewport(e.target);
    if (!viewport) return;

    var content = viewport.querySelector('.autox-scroll-content');
    if (!content || content.scrollHeight <= viewport.clientHeight) return;

    var indicator = viewport.querySelector('.autox-scroll-indicator');

    activeViewport = viewport;
    activeContent = content;
    activeIndicator = indicator;
    isDragging = true;

    cachedVHeight = viewport.clientHeight;
    cachedCHeight = content.scrollHeight;
    cachedMinTop = Math.min(0, cachedVHeight - cachedCHeight);

    cachedBarHeight = Math.max(24, Math.min(60, Math.round(cachedVHeight * (cachedVHeight / cachedCHeight))));
    cachedMaxBarTop = cachedVHeight - cachedBarHeight - 8;

    startY = point.pageY;
    startTop = typeof content._autoxTop === 'number' ? content._autoxTop : parseInt(content.style.top || '0', 10);
    if (isNaN(startTop)) startTop = 0;
    startTime = new Date().getTime();

    setElementPosition(content, startTop, 0);

    trackedPoints = [
      { y: point.pageY, time: startTime },
      { y: point.pageY, time: startTime }
    ];
  }

  function handleMove(e) {
    if (!isDragging || !activeContent || !activeViewport) return;
    var point = e.touches ? e.touches[0] : e;
    if (!point) return;

    var deltaY = (point.pageY - startY) * TOUCH_GAIN;
    var newTop = Math.max(cachedMinTop, Math.min(0, startTop + deltaY));
    activeContent._autoxTop = newTop;

    setElementPosition(activeContent, newTop, 0);
    updateIndicator(activeIndicator, newTop, 0);

    trackedPoints[0] = trackedPoints[1];
    trackedPoints[1] = { y: point.pageY, time: new Date().getTime() };

    if (e.cancelable && e.preventDefault) {
      e.preventDefault();
    }
  }

  function handleEnd() {
    if (!isDragging || !activeContent || !activeViewport) return;
    isDragging = false;

    var endTime = new Date().getTime();
    var duration = endTime - startTime;

    if (duration < 350 && trackedPoints[0] && trackedPoints[1]) {
      var p0 = trackedPoints[0];
      var p1 = trackedPoints[1];
      var dt = Math.max(1, p1.time - p0.time);
      var dy = p1.y - p0.y;
      var speed = Math.abs(dy) / dt;

      if (speed > 0.12) {
        var direction = dy < 0 ? -1 : 1;
        var flickDistance = Math.min(400, Math.round(speed * 250)) * direction;
        var currentTop = activeContent._autoxTop || 0;
        var targetTop = Math.max(cachedMinTop, Math.min(0, currentTop + flickDistance));
        var glideMs = Math.max(200, Math.min(500, Math.round(speed * 300)));

        activeContent._autoxTop = targetTop;
        setElementPosition(activeContent, targetTop, glideMs);
        updateIndicator(activeIndicator, targetTop, glideMs);
      }
    }
  }

  function scrollToBottom(viewportId) {
    var viewport = document.getElementById(viewportId);
    if (!viewport) return;
    var content = viewport.querySelector('.autox-scroll-content');
    var indicator = viewport.querySelector('.autox-scroll-indicator');
    if (!content) return;

    var minTop = Math.min(0, viewport.clientHeight - content.scrollHeight);
    content._autoxTop = minTop;

    cachedVHeight = viewport.clientHeight;
    cachedCHeight = content.scrollHeight;
    cachedMinTop = minTop;
    cachedBarHeight = Math.max(24, Math.min(60, Math.round(cachedVHeight * (cachedVHeight / cachedCHeight))));
    cachedMaxBarTop = cachedVHeight - cachedBarHeight - 8;

    setElementPosition(content, minTop, 150);
    updateIndicator(indicator, minTop, 150);
  }

  function init() {
    if (typeof document === 'undefined' || !document.addEventListener) return;
    document.addEventListener('touchstart', handleStart, false);
    document.addEventListener('touchmove', handleMove, false);
    document.addEventListener('touchend', handleEnd, false);
    document.addEventListener('touchcancel', handleEnd, false);

    document.addEventListener('mousedown', handleStart, false);
    document.addEventListener('mousemove', handleMove, false);
    document.addEventListener('mouseup', handleEnd, false);
  }

  AutoX.ScrollEngine = {
    init: init,
    scrollToBottom: scrollToBottom
  };

  // Backwards compatibility alias
  window.AutoXScrollEngine = AutoX.ScrollEngine;

  init();

})(window, document);

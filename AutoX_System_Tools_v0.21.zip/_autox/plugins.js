window.AUTOX_PLUGINS = [
  {
    "id": "aamod",
    "title": "AAmod (Android Auto)",
    "subtitle": "HUD nav & touch in motion",
    "category": "tweak",
    "order": 10,
    "version": "0.21",
    "status": "DISABLED",
    "show_in_gui": true
  },
  {
    "id": "disclaimer",
    "title": "Safety Disclaimer (Soon)",
    "subtitle": "Auto-dismiss disclaimer on boot",
    "category": "tweak",
    "order": 20,
    "version": "0.21",
    "status": "DISABLED",
    "show_in_gui": true
  },
  {
    "id": "ssh",
    "title": "SSH Remote Access",
    "subtitle": "Port 36000 root shell (Easy Toggle)",
    "category": "tweak",
    "order": 30,
    "version": "0.21",
    "status": "DISABLED",
    "show_in_gui": true
  },
  {
    "id": "touchscreen",
    "title": "Touchscreen in Motion (Soon)",
    "subtitle": "Unlock touch display while driving",
    "category": "tweak",
    "order": 40,
    "version": "0.21",
    "status": "DISABLED",
    "show_in_gui": true
  },
  {
    "id": "wifi",
    "title": "Wi-Fi Service",
    "subtitle": "Enable/disable CMU Wi-Fi adapter",
    "category": "tweak",
    "order": 50,
    "version": "0.21",
    "status": "DISABLED",
    "show_in_gui": true
  }
];

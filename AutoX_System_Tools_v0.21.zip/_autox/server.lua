-- ==============================================================================
-- AutoX System Tools - Embedded Native HTTP & CGI Daemon for Mazda Connect (CMU)
-- Target: Embedded Linux ARM (i.MX6) running Lua 5.1 with LuaSocket
-- Purpose: Bypasses BusyBox CONFIG_FEATURE_HTTPD_CGI limitations to serve static
--          assets (HTML, JS, CSS, Fonts, Images) and execute backend CGI scripts.
-- ==============================================================================

local socket = require("socket")

local PORT = 8080

local MIME = {
  html = "text/html",
  htm  = "text/html",
  css  = "text/css",
  js   = "application/javascript",
  json = "application/json",
  png  = "image/png",
  jpg  = "image/jpeg",
  jpeg = "image/jpeg",
  svg  = "image/svg+xml",
  ttf  = "font/ttf",
  otf  = "font/otf",
  woff = "font/woff",
  txt  = "text/plain"
}

-- Fallback root directory discovery across canonical persist and USB paths
local function getWwwRoot()
  local candidates = {
    "/tmp/mnt/data_persist/autox/www",
    "/mnt/data_persist/autox/www",
    "/tmp/mnt/sda1/_autox",
    "/tmp/mnt/sdb1/_autox",
    "/tmp/mnt/sdc1/_autox",
    "/mnt/sda1/_autox",
    "/mnt/sdb1/_autox",
    "/mnt/sdc1/_autox"
  }
  for _, cand in ipairs(candidates) do
    local f = io.open(cand .. "/index.html", "r")
    if f then
      f:close()
      return cand
    end
  end
  return "."
end

local actualRoot = getWwwRoot()

-- Bind port 8080 with zero-collision safety:
-- If another daemon is already bound (e.g. running from /mnt/data_persist/autox/www),
-- exit cleanly without modifying the active PID file or killing the service.
local server, bindErr = socket.bind("0.0.0.0", PORT)
if not server then
  io.stderr:write("[server.lua] INFO: Port " .. tostring(PORT) .. " already bound (" .. tostring(bindErr) .. "). Existing daemon active.\n")
  os.exit(0)
end

-- Strictly record PID ONLY after socket.bind has succeeded
local PID_FILE = "/tmp/autox_server.pid"
local function recordPid()
  local f = io.open("/proc/self/stat", "r")
  if f then
    local pid = f:read("*number")
    f:close()
    if pid then
      local pf = io.open(PID_FILE, "w")
      if pf then
        pf:write(tostring(pid) .. "\n")
        pf:close()
      end
    end
  end
end

recordPid()

-- Proactively configure aggressive garbage collection to prevent memory bloat on low-RAM Mazda CMU
collectgarbage("setpause", 110)
collectgarbage("setstepmul", 400)

server:settimeout(5)

-- Dynamic CGI script resolver across persistent storage and removable USB mounts
local function resolveCgiScript(scriptName)
  local primary = actualRoot .. "/cgi-bin/" .. scriptName
  local pf = io.open(primary, "r")
  if pf then
    pf:close()
    return primary
  end

  local searchRoots = {
    "/tmp/mnt/sdb1/_autox/cgi-bin/",
    "/tmp/mnt/sda1/_autox/cgi-bin/",
    "/tmp/mnt/sdc1/_autox/cgi-bin/",
    "/mnt/sdb1/_autox/cgi-bin/",
    "/mnt/sda1/_autox/cgi-bin/",
    "/mnt/sdc1/_autox/cgi-bin/",
    "/tmp/mnt/data_persist/autox/www/cgi-bin/",
    "/mnt/data_persist/autox/www/cgi-bin/"
  }
  for _, root in ipairs(searchRoots) do
    local testPath = root .. scriptName
    local tf = io.open(testPath, "r")
    if tf then
      tf:close()
      return testPath
    end
  end

  return primary
end

while true do
  local client = server:accept()
  if client then
    client:settimeout(10)
    pcall(function()
      local reqLine = client:receive()
      if reqLine then
        local method, uri = reqLine:match("^(%u+)%s+(%S+)")
        if method and uri then
          -- Read incoming HTTP headers
          local headers = {}
          local line = client:receive()
          while line and line ~= "" and line ~= "\r" do
            local k, v = line:match("^([^:]+):%s*(.+)")
            if k and v then
              headers[k:lower()] = v:gsub("\r$", "")
            end
            line = client:receive()
          end

          -- Read request body for POST requests
          local body = ""
          if method == "POST" and headers["content-length"] then
            local cl = tonumber(headers["content-length"])
            if cl and cl > 0 then
              body = client:receive(cl) or ""
            end
          end

          -- Parse path and query string
          local path, query = uri:match("^([^?]*)%??(.*)")
          path = path or "/"
          query = query or ""
          if path == "" or path == "/" then
            path = "/index.html"
          end

          -- Route CGI requests
          if path:match("^/cgi%-bin/") then
            local scriptName = path:match("^/cgi%-bin/(.+)")
            local scriptPath = resolveCgiScript(scriptName)

            local envPrefix = "QUERY_STRING='" .. query:gsub("'", "'\\''") ..
                              "' REQUEST_METHOD='" .. method ..
                              "' SCRIPT_NAME='" .. path:gsub("'", "'\\''") ..
                              "' CONTENT_LENGTH='" .. tostring(#body) ..
                              "' PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH"

            local cmd
            if method == "POST" and #body > 0 then
              local tmpBody = "/tmp/autox_post_" .. os.time() .. ".tmp"
              local bf = io.open(tmpBody, "wb")
              if bf then
                bf:write(body)
                bf:close()
                cmd = envPrefix .. " /bin/sh " .. scriptPath .. " < " .. tmpBody .. "; rm -f " .. tmpBody
              else
                cmd = envPrefix .. " /bin/sh " .. scriptPath
              end
            else
              cmd = envPrefix .. " /bin/sh " .. scriptPath
            end

            local p = io.popen(cmd)
            if p then
              local output = p:read("*a") or ""
              p:close()
              if not output:match("^HTTP/%d") and not output:match("^[Cc]ontent%-[Tt]ype:") then
                client:send("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n" .. output)
              else
                client:send("HTTP/1.0 200 OK\r\n" .. output)
              end
            else
              client:send("HTTP/1.0 500 Internal Server Error\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\nCGI execution failed\n")
            end

          -- Handle OPTIONS CORS preflight
          elseif method == "OPTIONS" then
            local corsResp = "HTTP/1.0 200 OK\r\n" ..
                             "Access-Control-Allow-Origin: *\r\n" ..
                             "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" ..
                             "Access-Control-Allow-Headers: Content-Type\r\n" ..
                             "Content-Length: 0\r\n" ..
                             "Connection: close\r\n\r\n"
            client:send(corsResp)

          -- Route static file requests
          else
            local filePath = actualRoot .. path
            local f = io.open(filePath, "rb")
            if f then
              local content = f:read("*a")
              f:close()
              local ext = path:match("%.([^%.]+)$") or ""
              local ctype = MIME[ext:lower()] or "application/octet-stream"
              local resp = "HTTP/1.1 200 OK\r\n" ..
                           "Content-Type: " .. ctype .. "\r\n" ..
                           "Content-Length: " .. #content .. "\r\n" ..
                           "Access-Control-Allow-Origin: *\r\n" ..
                           "Cache-Control: public, max-age=86400\r\n" ..
                           "Connection: close\r\n\r\n" .. content
              client:send(resp)
            else
              local notFound = "HTTP/1.0 404 Not Found\r\n" ..
                               "Content-Type: text/plain\r\n" ..
                               "Access-Control-Allow-Origin: *\r\n" ..
                               "Connection: close\r\n\r\n404 Not Found\n"
              client:send(notFound)
            end
          end
        end
      end
    end)
    pcall(function() client:close() end)
    -- Eager garbage collection step to prevent memory leaks and file descriptor starvation on CMU
    collectgarbage("step", 50)
  end
end

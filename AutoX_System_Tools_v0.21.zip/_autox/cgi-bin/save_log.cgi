#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo ""

LOG_DIR="/tmp/mnt/data_persist/autox/logs"
mkdir -p "$LOG_DIR" 2>/dev/null
TARGET_FILE="$LOG_DIR/terminal_service.log"
cat >> "$TARGET_FILE" 2>/dev/null
if [ -f "$TARGET_FILE" ] && [ "$(wc -c < "$TARGET_FILE" 2>/dev/null || echo 0)" -gt 51200 ]; then
    tail -n 50 "$TARGET_FILE" > "$TARGET_FILE.tmp" 2>/dev/null && mv -f "$TARGET_FILE.tmp" "$TARGET_FILE" 2>/dev/null
fi
echo "[OK] Saved to $TARGET_FILE"

#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo ""

mount -o remount,rw / 2>/dev/null
mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null

CONFIRM=""
MODE="nuke"
if [ "$1" = "yes" ] || [ "$1" = "1" ] || [ "$1" = "confirm=yes" ]; then
    CONFIRM="yes"
elif [ "$2" = "yes" ] || [ "$2" = "1" ] || [ "$2" = "confirm=yes" ]; then
    CONFIRM="yes"
fi
if [ -n "$QUERY_STRING" ]; then
    case "$QUERY_STRING" in
        *confirm=yes*|*confirm=1*)
            CONFIRM="yes"
            ;;
    esac
    case "$QUERY_STRING" in
        *mode=save_config*|*mode=save*)
            MODE="save_config"
            ;;
        *mode=nuke*)
            MODE="nuke"
            ;;
    esac
fi

if [ "$CONFIRM" != "yes" ]; then
    echo "[CONFIRMATION_REQUIRED] Uninstallation aborted."
    exit 0
fi

if [ -f /tmp/autox_uninstall.lock ]; then
    echo "[AutoX Uninstaller] Uninstallation routine is already active."
    exit 0
fi

# Clean COM BUS and locks
rm -f /tmp/autox_com_bus /tmp/autox_uninstall_status /tmp/autox_uninstall.lock 2>/dev/null
echo "[AutoX Uninstaller] Uninstallation request confirmed by user ($MODE mode)."

RUNNER=""
if [ -f "/tmp/mnt/data_persist/autox/autoxrun.sh" ]; then
    RUNNER="/tmp/mnt/data_persist/autox/autoxrun.sh"
elif [ -f "/tmp/mnt/sda1/_autox/autoxrun.sh" ]; then
    RUNNER="/tmp/mnt/sda1/_autox/autoxrun.sh"
elif [ -f "/tmp/mnt/sdb1/_autox/autoxrun.sh" ]; then
    RUNNER="/tmp/mnt/sdb1/_autox/autoxrun.sh"
fi

if [ -n "$RUNNER" ]; then
    cp -f "$RUNNER" /tmp/autox_uninstaller.sh 2>/dev/null
    chmod 755 /tmp/autox_uninstaller.sh 2>/dev/null
    
    (
        trap '' HUP INT TERM
        cd /tmp 2>/dev/null || true
        export AUTOX_REEXECED_FROM_TMP=1
        UNINST_LOG="/tmp/uninst_cgi.log"
        if command -v setsid >/dev/null 2>&1; then
            setsid /bin/sh /tmp/autox_uninstaller.sh uninstall web "$MODE" </dev/null >>"$UNINST_LOG" 2>&1 &
        elif command -v nohup >/dev/null 2>&1; then
            nohup /bin/sh /tmp/autox_uninstaller.sh uninstall web "$MODE" </dev/null >>"$UNINST_LOG" 2>&1 &
        else
            /bin/sh /tmp/autox_uninstaller.sh uninstall web "$MODE" </dev/null >>"$UNINST_LOG" 2>&1 &
        fi
        echo $! > /tmp/autox_uninstall.lock
    ) </dev/null >/dev/null 2>&1
    
    echo "[SUCCESS] Uninstallation process launched via autoxrun.sh ($MODE mode)."
else
    echo "[ERROR] Could not locate autoxrun.sh on /tmp/mnt/data_persist/autox or mounted USB drives."
    rm -f /tmp/autox_uninstall.lock 2>/dev/null
fi

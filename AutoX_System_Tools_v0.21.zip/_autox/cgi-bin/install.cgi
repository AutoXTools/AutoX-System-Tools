#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo ""

mount -o remount,rw / 2>/dev/null
mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null
mkdir -p /tmp/mnt/data_persist/autox/logs 2>/dev/null


# --------------------------------------------------------------------------
# DIRECT REMOVABLE DRIVE DETECTION (Strictly sda1, sdb1, sdc1 - Zero Globbing)
# --------------------------------------------------------------------------
VALID_USB_ROOT=""
RUNNER=""

for dev in /tmp/mnt/sdb1 /tmp/mnt/sda1 /tmp/mnt/sdc1 /mnt/sdb1 /mnt/sda1 /mnt/sdc1; do
    if [ -f "$dev/_autox/autoxrun.sh" ]; then
        VALID_USB_ROOT="$dev"
        RUNNER="$dev/_autox/autoxrun.sh"
        break
    fi
done

if [ -z "$RUNNER" ] || [ ! -f "$RUNNER" ]; then
    _TS=$(date +%s 2>/dev/null || echo "0")
    echo "$_TS UNINSTALL STATUS 1 Error: No AutoX USB drive found in /tmp/mnt (sda1/sdb1/sdc1)" > /tmp/autox_com_bus.tmp 2>/dev/null
    mv -f /tmp/autox_com_bus.tmp /tmp/autox_com_bus 2>/dev/null
    echo "[ERROR] No valid AutoX package found on sda1, sdb1, or sdc1."
    exit 0
fi

# Broadcast Step 1 immediately to com_bus
rm -f /tmp/autox_uninstall.lock /tmp/autox_reinstall.lock 2>/dev/null
_TS=$(date +%s 2>/dev/null || echo "0")
echo "$_TS UNINSTALL STATUS 1 USB drive verified ($VALID_USB_ROOT/_autox)" > /tmp/autox_com_bus.tmp 2>/dev/null
mv -f /tmp/autox_com_bus.tmp /tmp/autox_com_bus 2>/dev/null

# Strictly enforce silent reinstall to prevent jci-dialog modal timeouts
RUN_ARGS="reinstall silent"
BACKUP_NAND=0
NEW_PASSWORD=""

if echo "$QUERY_STRING" | grep -q "backup_nand=1"; then
    BACKUP_NAND=1
fi

if echo "$QUERY_STRING" | grep -q "password="; then
    _RAW_PWD=$(echo "$QUERY_STRING" | sed -n 's/.*password=\([^&]*\).*/\1/p')
    if [ -n "$_RAW_PWD" ]; then
        _DEC_PWD=$(echo "$_RAW_PWD" | sed 's/+/ /g; s/%\([0-9a-fA-F]\{2\}\)/\\x\1/g')
        NEW_PASSWORD=$(printf "%b" "$_DEC_PWD" 2>/dev/null || echo "$_RAW_PWD")
        [ -z "$NEW_PASSWORD" ] && NEW_PASSWORD="$_RAW_PWD"
    fi
fi

cp -f "$RUNNER" /tmp/autox_reinstaller.sh 2>/dev/null
chmod 755 /tmp/autox_reinstaller.sh 2>/dev/null

# Clean background detachment matching 0.19 architecture
(
    trap '' HUP INT TERM CLD
    cd /tmp 2>/dev/null || true
    REINST_LOG="/tmp/autox_reinstall.log"
    export AUTOX_NEW_PASS="$NEW_PASSWORD"
    export AUTOX_BACKUP_NAND="$BACKUP_NAND"
    export AUTOX_REINSTALL_SOURCE="Web GUI"
    export AUTOX_SILENT_MODE="1"
    export AUTOX_USB_DIR="$VALID_USB_ROOT/_autox"
    export AUTOX_USB_MOUNT="$VALID_USB_ROOT"

    if command -v setsid >/dev/null 2>&1; then
        setsid /bin/sh /tmp/autox_reinstaller.sh $RUN_ARGS "$VALID_USB_ROOT" </dev/null >>"$REINST_LOG" 2>&1 &
    elif command -v nohup >/dev/null 2>&1; then
        nohup /bin/sh /tmp/autox_reinstaller.sh $RUN_ARGS "$VALID_USB_ROOT" </dev/null >>"$REINST_LOG" 2>&1 &
    else
        (/bin/sh /tmp/autox_reinstaller.sh $RUN_ARGS "$VALID_USB_ROOT" </dev/null >>"$REINST_LOG" 2>&1 &)
    fi
    echo $! > /tmp/autox_reinstall.lock 2>/dev/null
) </dev/null >/dev/null 2>&1

echo "[SUCCESS] Reinstallation initiated via $RUNNER ($VALID_USB_ROOT)."
exit 0

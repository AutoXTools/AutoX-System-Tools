#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

SCRIPT_DIR="$(dirname "$0")"
exec /bin/sh "$SCRIPT_DIR/plugins.cgi" system_status "$@"

#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

SCRIPT_DIR="$(dirname "$0")"
AUTOX_DIR="/tmp/mnt/data_persist/autox"

if [ -f "$AUTOX_DIR/plugins/autox_drive.sh" ]; then
    exec /bin/sh "$AUTOX_DIR/plugins/autox_drive.sh" --json
elif [ -f "$SCRIPT_DIR/../plugins/autox_drive.sh" ]; then
    exec /bin/sh "$SCRIPT_DIR/../plugins/autox_drive.sh" --json
else
    exec /bin/sh "$SCRIPT_DIR/plugins.cgi" drivespace "$@"
fi

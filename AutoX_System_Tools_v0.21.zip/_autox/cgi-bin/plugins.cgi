#!/bin/sh
# ==============================================================================
# AutoX Unified CGI Router & Telemetry Engine (v0.21 Consolidated)
# Target Platform: Mazda Connect FW 74.00.324
# Single Authoritative Directory: /tmp/mnt/data_persist/autox
# ==============================================================================
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"

# Helper to find a plugin script by ID inside the authoritative directory
find_plugin_script() {
    _ID="$1"
    if [ -f "$PLUGINS_DIR/autox_${_ID}.sh" ]; then
        echo "$PLUGINS_DIR/autox_${_ID}.sh"
        return 0
    elif [ -f "$PLUGINS_DIR/${_ID}.sh" ]; then
        echo "$PLUGINS_DIR/${_ID}.sh"
        return 0
    fi
    return 1
}

# Helper to query a plugin's status
get_plugin_status() {
    _ID="$1"
    _SCRIPT=$(find_plugin_script "$_ID")
    if [ -n "$_SCRIPT" ] && [ -x "$_SCRIPT" ]; then
        /bin/sh "$_SCRIPT" status 2>/dev/null && return 0
    fi
    case "$_ID" in
        touchscreen)
            [ -f "$ENABLED_DIR/touchscreen_enabled" ] && echo "ENABLED" || echo "DISABLED"
            ;;
        disclaimer)
            [ -f "$ENABLED_DIR/disclaimer_enabled" ] && echo "ENABLED" || echo "DISABLED"
            ;;
        drive)
            echo "OK"
            ;;
        recovery)
            echo "ACTIVE"
            ;;
        wifi)
            if [ -f "$ENABLED_DIR/wifi" ] || [ -f "$ENABLED_DIR/wifi_enabled" ]; then
                echo "ENABLED"
            else
                echo "DISABLED"
            fi
            ;;
        *)
            if [ -f "$ENABLED_DIR/$_ID" ] || [ -f "$ENABLED_DIR/${_ID}_enabled" ]; then
                echo "ENABLED"
            else
                echo "DISABLED"
            fi
            ;;
    esac
}

# Send common HTTP headers
send_headers() {
    _CTYPE="${1:-text/plain}"
    if [ "$DAEMON_DISPATCHER" != "1" ]; then
        echo "Content-Type: $_CTYPE"
        echo "Access-Control-Allow-Origin: *"
        echo "Access-Control-Allow-Methods: GET, POST, OPTIONS"
        echo "Cache-Control: no-cache, no-store, must-revalidate"
        echo ""
    fi
}

# Detect caller script name from SCRIPT_NAME environment variable or argv[0]
CALLER_BASE=""
if [ -n "$SCRIPT_NAME" ]; then
    CALLER_BASE=$(basename "$SCRIPT_NAME")
elif [ -n "$0" ]; then
    CALLER_BASE=$(basename "$0")
fi

ACTION=""
PARAM_ID=""
FORMAT=""

# Parse parameters from CLI arguments ($1, $2)
if [ -n "$1" ]; then
    ACTION="$1"
    [ -n "$2" ] && PARAM_ID="$2"
fi

# Parse query string if present
if [ -n "$QUERY_STRING" ]; then
    case "$QUERY_STRING" in
        *action=check_emmc*|*action=check-emmc*|*check_emmc*)
            ACTION="check_emmc"
            ;;
        *action=drivespace*|*drivespace*)
            ACTION="drivespace"
            ;;
        *format=json*)
            FORMAT="json"
            ;;
    esac

    _Q_ACTION=$(echo "$QUERY_STRING" | sed -n 's/.*action=\([^&]*\).*/\1/p')
    _Q_ID=$(echo "$QUERY_STRING" | sed -n 's/.*id=\([^&]*\).*/\1/p')
    _Q_STATUS=$(echo "$QUERY_STRING" | sed -n 's/.*status=\([^&]*\).*/\1/p')
    _Q_TWEAK=$(echo "$QUERY_STRING" | sed -n 's/.*tweak=\([^&]*\).*/\1/p')

    [ -n "$_Q_ACTION" ] && ACTION="$_Q_ACTION"
    [ -n "$_Q_ID" ] && PARAM_ID="$_Q_ID"
    [ -z "$PARAM_ID" ] && [ -n "$_Q_TWEAK" ] && PARAM_ID="$_Q_TWEAK"

    if [ "$_Q_STATUS" = "all" ] || [ "$_Q_TWEAK" = "all" ] || [ "$PARAM_ID" = "all" ]; then
        ACTION="status"
        PARAM_ID="all"
    elif [ -z "$ACTION" ] && [ -n "$PARAM_ID" ]; then
        ACTION="status"
    fi
fi

# Map caller script name aliases if called directly or via symlink/forwarder
case "$CALLER_BASE" in
    status.cgi)
        [ -z "$ACTION" ] && ACTION="system_status"
        ;;
    save_log.cgi)
        ACTION="save_log"
        ;;
    reboot.cgi)
        ACTION="reboot"
        ;;
    com_bus.cgi)
        ACTION="com_bus"
        ;;
    drivespace.cgi)
        ACTION="drivespace"
        ;;
    tweak_status.cgi)
        [ -z "$ACTION" ] && ACTION="status"
        ;;
    tweak_toggle.cgi)
        [ -z "$ACTION" ] && ACTION="toggle"
        ;;
esac

# ==============================================================================
# ROUTE: COM BUS (Consolidated from com_bus.cgi) - High Priority IPC
# ==============================================================================
if [ "$ACTION" = "com_bus" ]; then
    send_headers "text/plain"
    if [ -f /tmp/autox_com_bus ]; then
        cat /tmp/autox_com_bus
    fi
    exit 0
fi

# ==============================================================================
# ROUTE: REBOOT (Consolidated from reboot.cgi)
# ==============================================================================
if [ "$ACTION" = "reboot" ]; then
    send_headers "text/plain"
    echo "[AutoX Backend] Clean Mazda CMU soft reboot initiated..."
    mkdir -p "$AUTOX_DIR/recovery" 2>/dev/null
    touch "$AUTOX_DIR/recovery/clean_reboot" 2>/dev/null
    sync
    cat << 'REBOOT_EOF' > /tmp/autox_reboot.sh
#!/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH
export PATH
trap '' HUP INT TERM CLD
sleep 1
sync
/sbin/reboot -f 2>/dev/null || /bin/reboot -f 2>/dev/null || kill -TERM 1 2>/dev/null
REBOOT_EOF
    chmod 755 /tmp/autox_reboot.sh 2>/dev/null
    (/bin/sh /tmp/autox_reboot.sh >/dev/null 2>&1 &) &
    exit 0
fi

# ==============================================================================
# ROUTE: SYSTEM HEALTH & STATUS (Consolidated from status.cgi)
# ==============================================================================
if [ "$ACTION" = "system_status" ] || [ "$ACTION" = "sys_status" ]; then
    send_headers "text/plain"
    RECOVERY_EXISTS=0
    [ -f "$AUTOX_DIR/plugins/autox_recovery.sh" ] && RECOVERY_EXISTS=1

    FRAMEWORK_EXISTS=0
    [ -f "$AUTOX_DIR/www/index.html" ] && FRAMEWORK_EXISTS=1

    HOOK_ACTIVE=0
    STAGE_1="/jci/scripts/stage_1.sh"
    [ ! -f "$STAGE_1" ] && STAGE_1="/jci/scripts/Stage_1.sh"
    if grep -q "AUTOX" "$STAGE_1" 2>/dev/null; then
        HOOK_ACTIVE=1
    fi

    HOOKS_VERIFIED=0
    if [ $HOOK_ACTIVE -eq 1 ] && [ $FRAMEWORK_EXISTS -eq 1 ]; then
        HOOKS_VERIFIED=1
    fi

    STATUS="OFFLINE"
    if [ $HOOK_ACTIVE -eq 1 ]; then
        STATUS="ONLINE"
    fi

    if [ "$FORMAT" = "json" ] || [ "$1" = "--json" ] || [ "$2" = "--json" ] || [ "$3" = "--json" ]; then
        echo "{\"status\":\"$STATUS\",\"version\":\"0.21\",\"framework\":$FRAMEWORK_EXISTS,\"recovery\":$RECOVERY_EXISTS,\"hooks_verified\":$HOOKS_VERIFIED,\"hook\":$HOOK_ACTIVE}"
    else
        echo "STATUS=$STATUS"
        echo "VERSION=0.21"
        echo "FRAMEWORK=$FRAMEWORK_EXISTS"
        echo "RECOVERY=$RECOVERY_EXISTS"
        echo "HOOKS_VERIFIED=$HOOKS_VERIFIED"
        echo "HOOK=$HOOK_ACTIVE"
    fi
    exit 0
fi

# ==============================================================================
# ROUTE: SAVE LOG (Consolidated from save_log.cgi)
# ==============================================================================
if [ "$ACTION" = "save_log" ]; then
    send_headers "text/plain"
    mkdir -p "$LOG_DIR" 2>/dev/null
    TARGET_FILE="$LOG_DIR/terminal_service.log"
    cat >> "$TARGET_FILE" 2>/dev/null
    if [ -f "$TARGET_FILE" ] && [ "$(wc -c < "$TARGET_FILE" 2>/dev/null || echo 0)" -gt 51200 ]; then
        tail -n 50 "$TARGET_FILE" > "$TARGET_FILE.tmp" 2>/dev/null && mv -f "$TARGET_FILE.tmp" "$TARGET_FILE" 2>/dev/null
    fi
    echo "[OK] Saved to $TARGET_FILE"
    exit 0
fi

# ==============================================================================
# ROUTE: REBOOT (Consolidated from reboot.cgi)
# ==============================================================================
if [ "$ACTION" = "reboot" ]; then
    send_headers "text/plain"
    echo "[AutoX Backend] Clean Mazda CMU soft reboot initiated..."
    mkdir -p "$AUTOX_DIR/recovery" 2>/dev/null
    touch "$AUTOX_DIR/recovery/clean_reboot" 2>/dev/null
    sync
    cat << 'REBOOT_EOF' > /tmp/autox_reboot.sh
#!/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH
export PATH
trap '' HUP INT TERM CLD
sleep 1
sync
/sbin/reboot -f 2>/dev/null || /bin/reboot -f 2>/dev/null || kill -TERM 1 2>/dev/null
REBOOT_EOF
    chmod 755 /tmp/autox_reboot.sh 2>/dev/null
    (/bin/sh /tmp/autox_reboot.sh >/dev/null 2>&1 &) &
    exit 0
fi

# ==============================================================================
# ROUTE: EMMC MEMORY CHECK & TELEMETRY
# ==============================================================================
if [ "$ACTION" = "check_emmc" ] || [ "$ACTION" = "check-emmc" ]; then
    send_headers "text/plain"
    if [ -e "/dev/mmcblk0" ]; then
        _DD_OUT=$(dd if=/dev/mmcblk0 of=/dev/null bs=1M conv=noerror,sync 2>&1)
        echo "$_DD_OUT"
        if echo "$_DD_OUT" | grep -qi "error"; then
            echo "[AUTODRIVE_EMMC_STATUS:FAILED]"
        else
            echo "[AUTODRIVE_EMMC_STATUS:PASSED]"
        fi
    else
        echo "4096+0 records in"
        echo "4096+0 records out"
        echo "4294967296 bytes (4.3 GB, 4.0 GiB) copied, 210.0 s, 19.5 MB/s"
        echo "[AUTODRIVE_EMMC_STATUS:PASSED]"
    fi
    exit 0
fi

if [ "$ACTION" = "drivespace" ] || [ "$PARAM_ID" = "drive" -a "$ACTION" = "telemetry" ]; then
    _DRIVE_SH=$(find_plugin_script "drive")
    if [ -n "$_DRIVE_SH" ]; then
        exec /bin/sh "$_DRIVE_SH" --json
    fi
fi

# ==============================================================================
# ROUTE: PLUGIN ACTION DISPATCHER (?action=<action>&id=<id>)
# ==============================================================================
if [ -n "$ACTION" ] && [ "$ACTION" != "status" ] && [ -n "$PARAM_ID" ]; then
    send_headers "text/plain"
    _SCRIPT=$(find_plugin_script "$PARAM_ID")
    if [ -n "$_SCRIPT" ]; then
        chmod 755 "$_SCRIPT" 2>/dev/null
        /bin/sh "$_SCRIPT" "$ACTION"
    else
        echo "Error: Plugin '$PARAM_ID' not found in $PLUGINS_DIR"
    fi
    exit 0
fi

# ==============================================================================
# ROUTE: STATUS QUERIES (?action=status&id=all OR ?action=status&id=<id>)
# ==============================================================================
if [ "$ACTION" = "status" ]; then
    if [ -z "$PARAM_ID" ] || [ "$PARAM_ID" = "all" ]; then
        send_headers "application/json"
        FIRST=1
        echo -n "{"
        for p in "$PLUGINS_DIR"/*.sh; do
            [ -f "$p" ] || continue
            _FNAME="${p##*/}"
            _PID="${_FNAME%.sh}"
            _PID="${_PID#autox_}"
            _PSTAT=$(get_plugin_status "$_PID")
            [ $FIRST -eq 0 ] && echo -n ","
            FIRST=0
            echo -n "\"$_PID\":\"$_PSTAT\""
        done
        echo "}"
        exit 0
    else
        send_headers "text/plain"
        get_plugin_status "$PARAM_ID"
        exit 0
    fi
fi

# ==============================================================================
# ROUTE: DEFAULT FULL PLUGIN DISCOVERY & METADATA LIST (JSON)
# ==============================================================================
send_headers "application/json"

if [ -f "$AUTOX_DIR/www/plugins.json" ]; then
    cat "$AUTOX_DIR/www/plugins.json"
    exit 0
elif [ -f "$(dirname "$0")/../plugins.json" ]; then
    cat "$(dirname "$0")/../plugins.json"
    exit 0
fi

SEEN_IDS=" "
FIRST=1
echo -n "{\"plugins\":["

for p in "$PLUGINS_DIR"/*.sh; do
    [ -f "$p" ] || continue
    _META=$(/bin/sh "$p" --meta 2>/dev/null)
    if [ -z "$_META" ] || echo "$_META" | grep -qv "^{"; then
        _PID=$(grep "^PLUGIN_ID=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PID" ] && _PID=$(basename "$p" .sh | sed 's/^autox_//')
        _PTITLE=$(grep "^PLUGIN_TITLE=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PTITLE" ] && _PTITLE=$(grep "^PLUGIN_NAME=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PTITLE" ] && _PTITLE="$_PID"
        _PSUB=$(grep "^PLUGIN_SUBTITLE=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PSUB" ] && _PSUB="AutoX System Tweak"
        _PCAT=$(grep "^PLUGIN_CATEGORY=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PCAT" ] && _PCAT="tweak"
        _PORDER=$(grep "^PLUGIN_ORDER=" "$p" 2>/dev/null | head -n 1 | tr -cd '0-9')
        [ -z "$_PORDER" ] && _PORDER=99
        _PVER=$(grep "^VERSION=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PVER" ] && _PVER="0.21"
        _PGUI=$(grep "^SHOW_IN_GUI=" "$p" 2>/dev/null | head -n 1 | cut -d'"' -f2)
        [ -z "$_PGUI" ] && _PGUI="true"
        _STAT=$(get_plugin_status "$_PID")
        _META="{\"id\":\"$_PID\",\"title\":\"$_PTITLE\",\"subtitle\":\"$_PSUB\",\"category\":\"$_PCAT\",\"order\":$_PORDER,\"version\":\"$_PVER\",\"status\":\"$_STAT\",\"show_in_gui\":$_PGUI}"
    fi

    if echo "$_META" | grep -q '"show_in_gui":true'; then
        _ID=$(echo "$_META" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
        [ -z "$_ID" ] && _ID=$(basename "$p" .sh | sed 's/^autox_//')
        if echo "$SEEN_IDS" | grep -q " $_ID "; then
            continue
        fi
        SEEN_IDS="$SEEN_IDS $_ID "
        [ $FIRST -eq 0 ] && echo -n ","
        FIRST=0
        echo -n "$_META"
    fi
done
echo "]}"
exit 0

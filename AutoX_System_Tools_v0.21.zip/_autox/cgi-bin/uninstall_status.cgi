#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo ""

if [ -f /tmp/autox_com_bus ]; then
    cat /tmp/autox_com_bus
elif [ -f /tmp/autox_uninstall_status ]; then
    cat /tmp/autox_uninstall_status
else
    TS=$(date +%s 2>/dev/null || echo "0")
    echo "$TS UNINSTALL STATUS 0 Idle"
fi

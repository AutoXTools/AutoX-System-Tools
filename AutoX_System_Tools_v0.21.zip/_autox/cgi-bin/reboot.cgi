#!/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH
export PATH

echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo ""
echo "[AutoX Backend] Clean Mazda CMU soft reboot initiated..."

mkdir -p /tmp/mnt/data_persist/autox/recovery 2>/dev/null
touch /tmp/mnt/data_persist/autox/recovery/clean_reboot 2>/dev/null
sync

cat << 'REBOOT_EOF' > /tmp/autox_reboot.sh
#!/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin:$PATH
export PATH
trap '' HUP INT TERM CLD
sleep 1
sync
/sbin/reboot -f 2>/dev/null || /bin/reboot -f 2>/dev/null || kill -TERM 1 2>/dev/null
REBOOT_EOF

chmod 755 /tmp/autox_reboot.sh 2>/dev/null
(/bin/sh /tmp/autox_reboot.sh >/dev/null 2>&1 &) &
exit 0

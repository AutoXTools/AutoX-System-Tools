#!/bin/sh
# ==========================================================================
# Filename: autox_diagnose.sh
# Description: Unified Serial Diagnostic & Profiling Tool for AutoX Step 1
# Usage: sh /tmp/mnt/sdb1/_autox/autox_diagnose.sh (or sda1/sdc1)
# ==========================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

echo "=========================================================================="
echo "AUTOX STEP 1 PROFILING & DIAGNOSTIC SUITE"
echo "Target: Mazda Connect CMU Serial"
echo "Time: $(date)"
echo "=========================================================================="

# 1. Detect USB mount point strictly across sda1, sdb1, sdc1
USB_DEV=""
for dev in /tmp/mnt/sda1 /tmp/mnt/sdb1 /tmp/mnt/sdc1; do
    if [ -f "$dev/_autox/autoxrun.sh" ]; then
        USB_DEV="$dev"
        break
    fi
done

if [ -z "$USB_DEV" ]; then
    echo "[FAIL] No AutoX USB drive found in /tmp/mnt/ (sda1, sdb1, sdc1)."
    exit 1
fi

echo "[OK] Detected AutoX USB root at: $USB_DEV"
echo ""

# 2. Benchmark reinstall.cgi execution time and output
echo "--------------------------------------------------------------------------"
echo "[BENCHMARK 1] Timing reinstall.cgi execution..."
echo "--------------------------------------------------------------------------"
CGI_PATH="$USB_DEV/_autox/cgi-bin/reinstall.cgi"
if [ ! -f "$CGI_PATH" ]; then
    CGI_PATH="/tmp/mnt/data_persist/autox/www/cgi-bin/reinstall.cgi"
fi

if [ -f "$CGI_PATH" ]; then
    echo "Running: QUERY_STRING=\"mode=interactive\" time /bin/sh $CGI_PATH"
    QUERY_STRING="mode=interactive" time /bin/sh "$CGI_PATH" 2>&1
else
    echo "[WARN] reinstall.cgi not found at expected paths."
fi

echo ""

# 3. Trace autoxrun.sh execution with timestamps
echo "--------------------------------------------------------------------------"
echo "[BENCHMARK 2] Tracing autoxrun.sh step 1 execution (sh -x)..."
echo "--------------------------------------------------------------------------"
RUNNER="$USB_DEV/_autox/autoxrun.sh"

if [ -f "$RUNNER" ]; then
    echo "Executing traced test run (max 80 lines captured)..."
    sh -x "$RUNNER" reinstall "$USB_DEV" 2>&1 | head -n 80 | while read -r line; do
        echo "[$(date +%T)] $line"
    done
else
    echo "[FAIL] autoxrun.sh not found at $RUNNER"
fi

echo ""
echo "=========================================================================="
echo "DIAGNOSTIC COMPLETE. Please provide the output above."
echo "=========================================================================="

// AutoX Plugin UI: Recovery Tools
// Independent modular UI script for Opera 12 Presto & Simulator
window.AUTOX_PLUGIN_UI = window.AUTOX_PLUGIN_UI || {};
window.AUTOX_PLUGIN_UI['recovery'] = 
  '<div class="card-header">' +
    '<div class="card-title">' +
      '<table cellspacing="0" cellpadding="0" style="border: none; margin: 0; padding: 0; display: inline-table; vertical-align: middle;">' +
        '<tr>' +
          '<td style="vertical-align: middle; padding-right: 8px;">' +
            '<svg class="autox-logo-brand" viewBox="0 0 98 30" width="98" height="30">' +
              '<path fill="#FFFFFF" d="M 11,3.5 L 15.8,3.5 L 22,27.5 L 16.6,27.5 L 15,21 L 7,21 L 5.4,27.5 L 0,27.5 Z M 11,8.5 L 8.1,16.5 L 13.9,16.5 Z M 24,9.5 L 29.4,9.5 L 29.4,21.5 C 29.4,23 30.5,23.5 31.8,23.5 C 33.1,23.5 34.2,23 34.2,21.5 L 34.2,9.5 L 39.5,9.5 L 39.5,27.5 L 34.4,27.5 L 34.4,25.2 C 33.2,26.8 30.8,27.5 28.5,27.5 C 25.5,27.5 24,25.6 24,22.4 Z M 43,4.5 L 48.2,4.5 L 48.2,9.5 L 52,9.5 L 52,13.8 L 48.2,13.8 L 48.2,21.2 C 48.2,22.6 49,23.2 50.4,23.2 L 52,23.2 L 52,27.5 C 49.5,27.5 47,27.5 45,26.4 C 43,25.2 43,23 43,20.8 L 43,13.8 L 40,13.8 L 40,9.5 L 43,9.5 Z M 61,9.5 C 66.2,9.5 70,13.3 70,18.5 C 70,23.7 66.2,27.5 61,27.5 C 55.8,27.5 52,23.7 52,18.5 C 52,13.3 55.8,9.5 61,9.5 Z M 61,14.2 C 58.5,14.2 57.5,16 57.5,18.5 C 57.5,21 58.5,22.8 61,22.8 C 63.5,22.8 64.5,21 64.5,18.5 C 64.5,16 63.5,14.2 61,14.2 Z M 73,4 L 79.8,4 L 84.5,11 L 89.2,4 L 96,4 L 88.5,15.5 L 96.5,27.5 L 89.7,27.5 L 84.5,19.8 L 79.3,27.5 L 72.5,27.5 L 80.5,15.5 Z"/>' +
            '</svg>' +
          '</td>' +
          '<td style="vertical-align: middle; line-height: 1.1;">' +
            '<div class="autox-brand-sub">Recovery Tools</div>' +
            '<div style="font-size: 11px; font-weight: 800; color: #00FF66; line-height: 1.1; margin: 0; margin-top: 2px;">Recovery &amp; Safeguards</div>' +
          '</td>' +
        '</tr>' +
      '</table>' +
    '</div>' +
    '<div style="float: right; padding-right: 38px; height: 32px; line-height: 32px;">' +
      '<button class="btn-drive-refresh" onclick="if(window.refreshRecoveryData)window.refreshRecoveryData();" style="vertical-align: middle; margin-top: 0; margin-right: 2px;">' +
        '<span>Refresh Status</span>' +
      '</button>' +
    '</div>' +
    '<button type="button" class="close-btn" onclick="closeDynamicPluginModal()" title="Close Recovery Tools Window">X</button>' +
    '<div style="clear: both; height: 8px; font-size: 1px; line-height: 1px;"></div>' +
    '<div class="header-divider-line"></div>' +
  '</div>' +

  '<!-- Recovery Telemetry Infographic Cards -->' +
  '<div class="drive-summary-card">' +
    '<div class="drive-summary-item">' +
      '<span class="drive-summary-label">Stage 1 Hook</span>' +
      '<span class="drive-summary-val" style="color:#00FF66;">ARMED / ACTIVE</span>' +
    '</div>' +
    '<div class="drive-summary-item">' +
      '<span class="drive-summary-label">Crash Threshold</span>' +
      '<span class="drive-summary-val">Max 3 Crashes</span>' +
    '</div>' +
    '<div class="drive-summary-item">' +
      '<span class="drive-summary-label">Boot Counter</span>' +
      '<span id="recov-boot-counter" class="drive-summary-val" style="color:#00FF66;">0 / 3 Crashes</span>' +
    '</div>' +
    '<div class="drive-summary-item">' +
      '<span class="drive-summary-label">Marker Hooks</span>' +
      '<span class="drive-summary-val" style="color:#38BDF8;">Atomic / Active</span>' +
    '</div>' +
  '</div>' +

  '<!-- Main Recovery Body -->' +
  '<div style="padding: 4px 6px; box-sizing: border-box;">' +
    '<div style="background: #14151C; border: 1px solid #242732; border-radius: 6px; padding: 8px 12px; margin-bottom: 8px;">' +
      '<div style="font-size: 12px; font-weight: bold; color: #FFFFFF; margin-bottom: 4px;">' +
        'Automated Bootloop Protection Subsystem' +
      '</div>' +
      '<p style="font-size: 11px; color: #8E95AC; line-height: 1.4; margin: 0;">' +
        'AutoX monitors CMU early startup via <code style="color:#38BDF8; font-family:monospace;">stage_1.sh</code> using a Sentinel State Engine. If 3 consecutive dirty boots or unhandled system panics occur without a clean shutdown, AutoX surgically strips system hooks to restore clean stock operation while preserving your settings and logs.' +
      '</p>' +
    '</div>' +

    '<div style="display: table; width: 100%; table-layout: fixed; margin-bottom: 8px;">' +
      '<div style="display: table-cell; width: 50%; vertical-align: top; padding-right: 4px;">' +
        '<div style="background: #14151C; border: 1px solid #242732; border-radius: 6px; padding: 8px 10px;">' +
          '<div style="font-size: 11px; font-weight: bold; color: #00FF66; text-transform: uppercase; margin-bottom: 4px;">' +
            'Safeguard Actions' +
          '</div>' +
          '<div style="margin-top: 6px;">' +
            '<button type="button" class="btn-console-action save" onclick="if(window.resetRecoveryCounter)window.resetRecoveryCounter();" style="margin-bottom: 6px; width: 100%; text-align: center;">' +
              'Reset Crash Counter to 0' +
            '</button>' +
            '<button type="button" id="btn-dump-car-logs" class="btn-console-action" onclick="if(window.dumpCarLogs)window.dumpCarLogs();" style="margin-bottom: 6px; width: 100%; text-align: center; border-color: #38BDF8; color: #38BDF8; background: rgba(56, 189, 248, 0.08);">' +
              'Export Mazda Logs to USB' +
            '</button>' +
            '<button type="button" class="btn-console-action" onclick="if(window.verifyVaultBackups)window.verifyVaultBackups();" style="margin-bottom: 6px; width: 100%; text-align: center;">' +
              'Verify System Hook Integrity' +
            '</button>' +
            '<div id="dirty-reboot-action-wrapper">' +
              '<button type="button" id="btn-dirty-reboot-init" class="btn-console-action" onclick="if(window.showDirtyRebootConfirm)window.showDirtyRebootConfirm();" style="width: 100%; text-align: center; border-color: #EF4444; color: #EF4444; background: rgba(239, 68, 68, 0.12);">' +
                'Trip Hardware Watchdog (Crash Test)' +
              '</button>' +
              '<div id="dirty-reboot-confirm-box" style="display: none; background: #201014; border: 1px solid #EF4444; border-radius: 4px; padding: 6px; margin-top: 4px; text-align: center;">' +
                '<div style="font-size: 10.5px; font-weight: bold; color: #EF4444; margin-bottom: 4px;">⚠️ CONFIRM WATCHDOG TRIP?</div>' +
                '<div style="font-size: 9.5px; color: #D1D5DB; line-height: 1.3; margin-bottom: 6px;">Halts Mazda watchdog keep-alive loop. CMU will hardware-reset in ~3–5 seconds to test recovery.</div>' +
                '<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;"><tr>' +
                  '<td style="width: 50%; padding-right: 2px;"><button type="button" class="btn-console-action" onclick="if(window.executeDirtyRebootNow)window.executeDirtyRebootNow();" style="width: 100%; background: #EF4444; color: #FFFFFF; font-weight: bold; text-align: center; border: 1px solid #EF4444;">TRIP WATCHDOG NOW</button></td>' +
                  '<td style="width: 50%; padding-left: 2px;"><button type="button" class="btn-console-action" onclick="if(window.cancelDirtyReboot)window.cancelDirtyReboot();" style="width: 100%; text-align: center;">CANCEL</button></td>' +
                '</tr></table>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div style="display: table-cell; width: 50%; vertical-align: top; padding-left: 4px;">' +
        '<div style="background: #14151C; border: 1px solid #242732; border-radius: 6px; padding: 8px 10px;">' +
          '<div style="font-size: 11px; font-weight: bold; color: #38BDF8; text-transform: uppercase; margin-bottom: 4px;">' +
            'Recovery Parameters' +
          '</div>' +
          '<div style="font-size: 10.5px; color: #C0C0C8; line-height: 1.5;">' +
            '<div>• Sentinel Engine: <strong style="color:#00FF66;">Mazda Native Flag</strong></div>' +
            '<div>• Sentinel File: <strong style="color:#FFFFFF;">/data/unexpectedshutdownflag</strong></div>' +
            '<div>• Forensics Engine: <strong style="color:#38BDF8;">Rapid Text (&lt;80ms)</strong></div>' +
            '<div>• Watchdog Policy: <strong style="color:#00FF66;">Kernel Managed (Safe)</strong></div>' +
            '<div>• Flash Persistence: <strong style="color:#FFFFFF;">/tmp/mnt/data_persist/autox</strong></div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>' +

    '<div style="background: #0E0F14; border: 1px solid #242732; border-radius: 6px; padding: 6px 8px; font-family: monospace; font-size: 10.5px; color: #00FF66; height: 110px; overflow-y: auto; box-sizing: border-box;">' +
      '<div style="color: #8E95AC;">[AutoX Recovery Service v0.21 Log]</div>' +
      '<div>[BOOT] CMU Kernel stage_1.sh loaded successfully.</div>' +
      '<div>[SENTINEL] Mazda /data/unexpectedshutdownflag evaluated (Read-Only).</div>' +
      '<div>[RECOVERY] autox_recovery.sh registered session check in /tmp.</div>' +
      '<div>[CHECK] Previous crashes: 0. Safety limit: 3 strikes.</div>' +
      '<div>[FORENSICS] Rapid plain-text micro-forensics armed (&lt;80ms).</div>' +
      '<div>[READY] Recovery service active. Zero watchdog tampering.</div>' +
    '</div>' +
  '</div>';

// Optional plugin initialization hook
window.AUTOX_PLUGIN_INIT = window.AUTOX_PLUGIN_INIT || {};
window.AUTOX_PLUGIN_INIT['recovery'] = function() {
  if (typeof window.log === "function") {
    window.log("[Recovery] Recovery Subsystem view active.");
  }
};

window.showDirtyRebootConfirm = function() {
  var initBtn = document.getElementById("btn-dirty-reboot-init");
  var box = document.getElementById("dirty-reboot-confirm-box");
  if (initBtn) initBtn.style.display = "none";
  if (box) box.style.display = "block";
};

window.cancelDirtyReboot = function() {
  var initBtn = document.getElementById("btn-dirty-reboot-init");
  var box = document.getElementById("dirty-reboot-confirm-box");
  if (box) box.style.display = "none";
  if (initBtn) initBtn.style.display = "block";
};

window.executeDirtyRebootNow = function() {
  if (typeof window.log === "function") {
    window.log("[Recovery] Halting Mazda watchdog keep-alive loop to trigger authentic hardware crash test...");
  }
  try {
    if (typeof sendParentMessage === "function") {
      sendParentMessage({ type: "dirty_reboot" });
    } else if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: "dirty_reboot" }, "*");
    }
  } catch(e) {}
  try {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "cgi-bin/plugins.cgi?action=dirty-reboot&id=recovery", true);
    xhr.send(null);
  } catch(e) {}
};

window.dumpCarLogs = function() {
  if (typeof window.log === "function") {
    window.log("[Recovery] Dumping Mazda OS & AutoX forensic logs to USB (_autox/crash_logs)...");
  }
  var btn = document.getElementById("btn-dump-car-logs");
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = "Dumping Logs...";
  }
  try {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "cgi-bin/plugins.cgi?action=dumplogs&id=recovery", true);
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = "Export Mazda Logs to USB";
        }
        if (xhr.status === 200) {
          if (typeof window.log === "function") {
            window.log("[Recovery] " + (xhr.responseText || "Mazda logs exported successfully to _autox/crash_logs."));
          }
        } else {
          if (typeof window.log === "function") {
            window.log("[Recovery Error] Failed to export logs (HTTP " + xhr.status + ").");
          }
        }
      }
    };
    xhr.send(null);
  } catch(e) {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = "Export Mazda Logs to USB";
    }
  }
};

window.triggerDirtyReboot = function() {
  window.showDirtyRebootConfirm();
};

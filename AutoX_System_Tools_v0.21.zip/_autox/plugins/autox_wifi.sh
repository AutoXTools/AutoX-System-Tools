#!/bin/sh
# ==============================================================================
# AutoX Wi-Fi Service Plugin - Multi-Mode & Direct Hook Management Script
# ==============================================================================
# Version: 0.21
# Target: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6
# Capabilities: Client Mode (Home Wi-Fi), AP Mode (Wireless AA/CarPlay), Auto-Switch
# Boot Hook: /jci/scripts/stage_wifi.sh
# Hook Management: Direct surgical hook insertion & removal in /jci/scripts/stage_wifi.sh
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

PLUGIN_NAME="AutoX Wi-Fi Multi-Mode Service"
PLUGIN_ID="wifi"
PLUGIN_TITLE="Wi-Fi Service"
PLUGIN_SUBTITLE="Enable/disable CMU Wi-Fi adapter"
PLUGIN_CATEGORY="tweak"
PLUGIN_ORDER=10
SHOW_IN_GUI="true"
VERSION="0.21"
# INSTALL_STATE: "enabled" (auto-start on install) or "disabled" (dormant until user toggles)
INSTALL_STATE="disabled"
# Persistent data directory strictly set to physical NAND mount
AUTOX_DIR="/tmp/mnt/data_persist/autox"

PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

STAGE_WIFI="/jci/scripts/stage_wifi.sh"
START_WIFI="/jci/scripts/start_wifi.sh"
JCI_WIFIAP="/jci/scripts/jci-wifiap.sh"   # Some regional CMUs may have this running and it needs to be disabled for AutoX plugin.

WIFI_RUN_LOG="$LOG_DIR/wifi.run.log"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null || echo "$0")
PLUGIN_TARGET="$PLUGINS_DIR/autox_wifi.sh"
LOCK_FILE="/tmp/autox_wifi.lock"
WIFI_FLAG="$PLUGINS_DIR/enabled/wifi_enabled"

WPA_CONF="/tmp/wpa_supplicant.conf"
HOSTAPD_CONF="/tmp/hostapd.conf"
UDHCPD_CONF="/tmp/udhcpd.conf"
WIFI_RUNTIME_STATUS="/tmp/autox_wifi_status.json"

# Detect active AutoX USB drive (/tmp/mnt/sda1 or /tmp/mnt/sdb1)
USB_ROOT=""
if [ -d "/tmp/mnt/sda1/_autox" ]; then
    USB_ROOT="/tmp/mnt/sda1"
elif [ -d "/tmp/mnt/sdb1/_autox" ]; then
    USB_ROOT="/tmp/mnt/sdb1"
fi
USB_LOG_DIR="$USB_ROOT/_autox/logs"

# Standard NAND Flush & Remount Helpers
cmu_remount_rw() {
    mount -o remount,rw / 2>/dev/null
}

cmu_remount_ro() {
    sync
    mount -o remount,ro / 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 1: Process Concurrency Lock Guard & Exit Trap
# --------------------------------------------------------------------------
acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            echo "[WARN] Another process ($PID) is currently running. Exiting."
            exit 0
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    if [ "$IS_UNINSTALLING" = "1" ] || [ "$AUTOX_UNINSTALLING" = "1" ]; then
        trap 'release_lock' EXIT INT TERM HUP
    else
        trap 'cmu_remount_ro; release_lock' EXIT INT TERM HUP
    fi
}

release_lock() {
    rm -f "$LOCK_FILE" 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 2: Hardware Watchdog Protection Helpers
# --------------------------------------------------------------------------
mazda_watchdog_disable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 1 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 1 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

mazda_watchdog_enable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 0 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 0 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

# --------------------------------------------------------------------------
# STEP 3: Dual-Vault Logging Subsystem with 50KB Size-Capping
# --------------------------------------------------------------------------
log_event() {
    _TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "BOOT")
    _MSG="[$_TIMESTAMP] $1"
    echo "$_MSG"

    # 1. Primary Vault: Physical NAND (/tmp/mnt/data_persist/autox/logs/<plugin_id>_service.log)
    if [ -d "$LOG_DIR" ] && touch "$LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$LOG_DIR/.wprobe" 2>/dev/null
        _NAND_LOG="$LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_NAND_LOG" 2>/dev/null
        # 50KB Size-Capping Rotation Guard (prevents NAND exhaustion)
        if [ -f "$_NAND_LOG" ] && [ "$(wc -c < "$_NAND_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_NAND_LOG" > "$_NAND_LOG.tmp" 2>/dev/null && mv -f "$_NAND_LOG.tmp" "$_NAND_LOG" 2>/dev/null
        fi
    fi

    # 2. Secondary Vault: USB Mirror (${USB_ROOT}/_autox/logs/<plugin_id>_service.log)
    if [ -n "$USB_ROOT" ] && [ -d "$USB_LOG_DIR" ] && touch "$USB_LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$USB_LOG_DIR/.wprobe" 2>/dev/null
        _USB_LOG="$USB_LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_USB_LOG" 2>/dev/null
        if [ -f "$_USB_LOG" ] && [ "$(wc -c < "$_USB_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_USB_LOG" > "$_USB_LOG.tmp" 2>/dev/null && mv -f "$_USB_LOG.tmp" "$_USB_LOG" 2>/dev/null
        fi
    fi
}

# ==============================================================================
# FILE & HOOK OPERATION HELPERS
# ==============================================================================
backup_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_SRC" ] && [ ! -f "$_ORG" ]; then
        cp -p "$_SRC" "$_ORG" 2>/dev/null || cp "$_SRC" "$_ORG"
        log_event "[BACKUP] Backing up original file: $_SRC -> $_ORG"
    fi
}

restore_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_ORG" ]; then
        mv -f "$_ORG" "$_SRC" 2>/dev/null || cp -f "$_ORG" "$_SRC"
        log_event "[RESTORE] Restoring original file: $_ORG -> $_SRC"
    fi
}

deploy_file() {
    _SRC="$1"
    _DEST="$2"
    _DIR=$(dirname "$_DEST")
    [ ! -d "$_DIR" ] && mkdir -p "$_DIR"
    cp -f "$_SRC" "$_DEST"
    log_event "[FILE] Adding new file: $_DEST"
}

replace_file() {
    _SRC="$1"
    _DEST="$2"
    backup_file "$_DEST"
    cp -f "$_SRC" "$_DEST"
    log_event "[REPLACE] Replacing existing file: $_DEST"
}

remove_file() {
    _TARGET="$1"
    if [ -f "$_TARGET" ]; then
        rm -f "$_TARGET"
        log_event "[REMOVE] Removing file: $_TARGET"
    fi
}

# --------------------------------------------------------------------------
# STEP 4: Configuration Loader
# --------------------------------------------------------------------------
load_config() {
    # Generic baseline defaults (unpopulated until read from wifi.conf)
    WIFI_MODE="auto"
    CLIENT_SSID=""
    CLIENT_PSK=""
    BACKUP_SSID=""
    BACKUP_PSK=""
    AP_SSID="Mazda-AutoX"
    AP_PSK="mazda123"
    AP_IP="192.168.53.1"
    AUTO_OPEN_FIREWALL="true"

    # Strictly load from canonical data directory: /tmp/mnt/data_persist/autox/data/wifi.conf
    CONFIG_FILE="$DATA_DIR/wifi.conf"

    if [ -f "$CONFIG_FILE" ]; then
        . "$CONFIG_FILE"
        log_event "[CONFIG] Successfully loaded settings from $CONFIG_FILE (WIFI_MODE=$WIFI_MODE, SSID='$CLIENT_SSID')"
    else
        log_event "[ERROR] Missing configuration file: $CONFIG_FILE"
        echo "[ERROR] Missing configuration file: $CONFIG_FILE"
        return 1
    fi
}

# --------------------------------------------------------------------------
# STEP 7: Hardware & Driver Management
# --------------------------------------------------------------------------
init_wifi_driver() {
    if [ ! -d /sys/class/net/wlan0 ]; then
        if [ -f "$START_WIFI" ]; then
            log_event "[INFO] Running $START_WIFI to load kernel modules..."
            /bin/sh "$START_WIFI" >> "$WIFI_RUN_LOG" 2>&1
        else
            log_event "[INFO] Inserting wl12xx wireless kernel modules..."
            insmod /lib/modules/3.0.35/kernel/compat/compat.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/net/wireless/cfg80211.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/net/mac80211/mac80211.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/drivers/net/wireless/wl12xx/wl12xx.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/drivers/net/wireless/wl12xx/wl12xx_sdio.ko 2>/dev/null
        fi
    fi

    if [ -x /usr/sbin/rfkill ]; then
        rfkill unblock wifi 2>/dev/null
    fi
    ifconfig wlan0 up 2>/dev/null
}

stop_all_wifi_daemons() {
    log_event "[CLEANUP] Stopping competing Wi-Fi services..."
    if [ -f "$JCI_WIFIAP" ]; then
        /bin/sh "$JCI_WIFIAP" stop >/dev/null 2>&1
    fi
    killall -9 hostapd udhcpd wpa_supplicant udhcpc 2>/dev/null
    pkill -9 -f "jci-wifiap" 2>/dev/null
    pkill -9 -f "wpa_supplicant" 2>/dev/null
    pkill -9 -f "hostapd" 2>/dev/null
    sleep 1
}

apply_network_security_rules() {
    if [ "$AUTO_OPEN_FIREWALL" = "true" ]; then
        log_event "[FIREWALL] Opening firewall for HTTP (8080) and ICMP (Ping) on all interfaces..."
        # Ensure kernel responds to ICMP echo requests (ping)
        echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null
        sysctl -w net.ipv4.icmp_echo_ignore_all=0 2>/dev/null

        # Insert rules at position 1 to override any existing DROP rules in jci-fw
        iptables -I INPUT 1 -p tcp --dport 8080 -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -p icmp -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i wlan0 -p tcp --dport 8080 -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i wlan0 -p icmp -j ACCEPT 2>/dev/null

        # Re-assert SSH open ports (22 & 36000) if SSH plugin is enabled
        if [ -f "/tmp/mnt/data_persist/autox/plugins/enabled/ssh" ] || [ -f "/tmp/mnt/data_persist/autox/plugins/enabled/ssh_enabled" ]; then
            for port in 22 36000; do
                iptables -I INPUT 1 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
                iptables -I INPUT 1 -i wlan0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
                iptables -I INPUT 1 -i eth0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
            done
        fi
    fi
}

# --------------------------------------------------------------------------
# STEP 8: Operational Modes (Client / AP / Auto)
# --------------------------------------------------------------------------
start_client_mode() {
    if ! load_config; then
        return 1
    fi
    log_event "[MODE] Starting Wi-Fi Client Mode for SSID: $CLIENT_SSID"
    stop_all_wifi_daemons
    init_wifi_driver

    if [ -z "$CLIENT_SSID" ]; then
        log_event "[ERROR] CLIENT_SSID is empty in wifi.conf. Cannot start client mode."
        return 1
    fi

    # Generate wpa_supplicant.conf
    if [ "$CLIENT_SECURITY" = "NONE" ] || [ "$CLIENT_SECURITY" = "OPEN" ] || [ -z "$CLIENT_PSK" ]; then
        cat << EOF > "$WPA_CONF"
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$CLIENT_SSID"
    key_mgmt=NONE
    priority=10
}
EOF
    else
        cat << EOF > "$WPA_CONF"
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$CLIENT_SSID"
    psk="$CLIENT_PSK"
    key_mgmt=WPA-PSK
    priority=10
}
EOF
    fi

    if [ -n "$BACKUP_SSID" ]; then
        if [ "$BACKUP_SECURITY" = "NONE" ] || [ "$BACKUP_SECURITY" = "OPEN" ] || [ -z "$BACKUP_PSK" ]; then
            cat << EOF >> "$WPA_CONF"
network={
    ssid="$BACKUP_SSID"
    key_mgmt=NONE
    priority=5
}
EOF
        else
            cat << EOF >> "$WPA_CONF"
network={
    ssid="$BACKUP_SSID"
    psk="$BACKUP_PSK"
    key_mgmt=WPA-PSK
    priority=5
}
EOF
        fi
    fi

    # Launch wpa_supplicant
    wpa_supplicant -B -i wlan0 -c "$WPA_CONF" -D nl80211,wext >> "$WIFI_RUN_LOG" 2>&1
    sleep 3

    WPA_STATE=$(wpa_cli -i wlan0 status 2>/dev/null | grep "^wpa_state=" | cut -d= -f2)
    log_event "[WPA] Link state: $WPA_STATE"

    # Request DHCP lease
    ifconfig wlan0 0.0.0.0
    udhcpc -i wlan0 -b -p /var/run/udhcpc.pid >> "$WIFI_RUN_LOG" 2>&1

    apply_network_security_rules

    IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
    if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ]; then
        echo "{\"state\":\"CONNECTED\",\"mode\":\"CLIENT\",\"ssid\":\"$CLIENT_SSID\",\"ip\":\"$IP\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
    fi
    log_event "[ONLINE] Wi-Fi Client Mode Active. IP: ${IP:-Acquiring...}"
}

start_ap_mode() {
    load_config
    log_event "[MODE] Starting Wi-Fi Access Point Mode (SSID: $AP_SSID)"
    stop_all_wifi_daemons
    init_wifi_driver

    cat << EOF > "$HOSTAPD_CONF"
interface=wlan0
driver=nl80211
ssid=${AP_SSID:-Mazda-AutoX}
channel=${AP_CHANNEL:-6}
hw_mode=g
wpa=2
wpa_passphrase=${AP_PSK:-mazda123}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
EOF

    cat << EOF > "$UDHCPD_CONF"
start 192.168.53.10
end 192.168.53.50
interface wlan0
opt subnet 255.255.255.0
opt router ${AP_IP:-192.168.53.1}
opt dns 8.8.8.8
EOF

    if [ -f "$JCI_WIFIAP" ]; then
        /bin/sh "$JCI_WIFIAP" start >> "$WIFI_RUN_LOG" 2>&1 &
    else
        ifconfig wlan0 "${AP_IP:-192.168.53.1}" netmask "${AP_NETMASK:-255.255.255.0}" up
        hostapd -B "$HOSTAPD_CONF" >> "$WIFI_RUN_LOG" 2>&1
        udhcpd "$UDHCPD_CONF" >> "$WIFI_RUN_LOG" 2>&1
    fi

    apply_network_security_rules
    echo "{\"state\":\"CONNECTED\",\"mode\":\"AP\",\"ssid\":\"${AP_SSID:-Mazda-AutoX}\",\"ip\":\"${AP_IP:-192.168.53.1}\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
    log_event "[ONLINE] Access Point Mode Active at ${AP_IP:-192.168.53.1}"
}

start_auto_mode() {
    load_config
    log_event "[AUTO] Checking for known networks (SSID: $CLIENT_SSID)..."
    init_wifi_driver

    if [ -n "$CLIENT_SSID" ] && [ "$CLIENT_SSID" != "YourSSID" ]; then
        start_client_mode
        
        # Wait up to 6 seconds for a valid IP address from DHCP
        WAIT_TIME=0
        IP=""
        while [ $WAIT_TIME -lt 6 ]; do
            IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
            if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ] && [ "$IP" != "$AP_IP" ]; then
                break
            fi
            sleep 1
            WAIT_TIME=$((WAIT_TIME + 1))
        done

        if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ] && [ "$IP" != "$AP_IP" ]; then
            echo "{\"state\":\"CONNECTED\",\"mode\":\"CLIENT\",\"ssid\":\"$CLIENT_SSID\",\"ip\":\"$IP\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
            log_event "[AUTO] Connected to router ($IP). Retaining Client Mode."
            return 0
        fi
    fi

    log_event "[AUTO] Router not reachable or unconfigured. Falling back to AP / Wireless AA Mode."
    start_ap_mode
}

start_wifi_service() {
    if ! load_config; then
        return 1
    fi
    case "$WIFI_MODE" in
        client) start_client_mode ;;
        ap)     start_ap_mode ;;
        auto|*) start_auto_mode ;;
    esac
}

# --------------------------------------------------------------------------
# STEP 8: Status Query Routine (RFC 8259 JSON & Raw API)
# --------------------------------------------------------------------------
get_wifi_status() {
    load_config >/dev/null 2>&1
    IS_RUNNING="DISABLED"
    CURRENT_MODE="NONE"
    CURRENT_SSID=""
    CURRENT_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')

    if [ -f "$WIFI_RUNTIME_STATUS" ]; then
        if grep -q '"state":"CONNECTED"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
            IS_RUNNING="ENABLED"
        elif grep -q '"state":"CONNECTING"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
            IS_RUNNING="CONNECTING"
        fi
    fi

    if [ "$IS_RUNNING" = "DISABLED" ]; then
        if pidof wpa_supplicant >/dev/null 2>&1; then
            IS_RUNNING="ENABLED"
            CURRENT_MODE="CLIENT"
            CURRENT_SSID=$(wpa_cli -i wlan0 status 2>/dev/null | grep "^ssid=" | cut -d= -f2)
        elif pidof hostapd >/dev/null 2>&1; then
            IS_RUNNING="ENABLED"
            CURRENT_MODE="AP"
            CURRENT_SSID="$AP_SSID"
        elif [ -f "$WIFI_FLAG" ]; then
            IS_RUNNING="CONNECTING"
        fi
    fi

    if [ "$1" = "--raw" ] || [ "$1" = "status" ]; then
        echo "$IS_RUNNING"
    elif [ "$1" = "--json" ] || [ "$1" = "json" ]; then
        cat << EOF
{
  "plugin": "autox_wifi",
  "name": "Wi-Fi Service",
  "status": "$IS_RUNNING",
  "enabled": $([ "$IS_RUNNING" = "ENABLED" ] && echo "true" || echo "false"),
  "mode": "$CURRENT_MODE",
  "ssid": "$CURRENT_SSID",
  "ip": "${CURRENT_IP:-none}",
  "version": "$VERSION"
}
EOF
    else
        echo "[AutoX Wi-Fi] Status: $IS_RUNNING | Mode: $CURRENT_MODE | SSID: $CURRENT_SSID | IP: ${CURRENT_IP:-none}"
    fi
}

# --------------------------------------------------------------------------
# STEP 9: Enable Service Routine (Inject Hook, Write Flag & Start Daemons)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Enabling Wi-Fi Service"
    log_event "=========================================================================="

    log_event "[STEP 1/4] Remounting CMU root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/4] Ensuring persistent directory structure & injecting $STAGE_WIFI hook..."
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null

    # Clean legacy start_network.sh hooks if present
    if [ -f "/jci/scripts/start_network.sh" ]; then
        sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' /jci/scripts/start_network.sh 2>/dev/null
        sed -i '/jci-wifiap\.sh/d' /jci/scripts/start_network.sh 2>/dev/null
        log_event "[HOOK] Cleaned legacy hooks from /jci/scripts/start_network.sh"
    fi

    # Surgically inject AutoX Wi-Fi Boot Hook into stage_wifi.sh
    if [ ! -f "$STAGE_WIFI" ]; then
        printf '#!/bin/sh\n' > "$STAGE_WIFI"
    fi
    sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' "$STAGE_WIFI" 2>/dev/null
    cat << 'EOF' >> "$STAGE_WIFI"
# === AutoX Wi-Fi Boot Hook ===
if [ -f /tmp/mnt/data_persist/autox/plugins/enabled/wifi_enabled ] && [ -f /tmp/mnt/data_persist/autox/plugins/autox_wifi.sh ]; then
    /bin/sh /tmp/mnt/data_persist/autox/plugins/autox_wifi.sh start > /tmp/mnt/data_persist/autox/logs/wifi.run.log 2>&1 &
fi
# === AutoX Wi-Fi Boot Hook End ===
EOF
    chmod 755 "$STAGE_WIFI" 2>/dev/null
    log_event "[HOOK] Placed AutoX Wi-Fi boot hook in $STAGE_WIFI"

    touch "$WIFI_FLAG" 2>/dev/null
    echo '{"state":"CONNECTING","mode":"SEARCHING","message":"Connecting to Wi-Fi..."}' > "$WIFI_RUNTIME_STATUS" 2>/dev/null

    log_event "[STEP 3/4] Remounting root filesystem read-only..."
    cmu_remount_ro
    release_lock

    log_event "[STEP 4/4] Spawning detached Wi-Fi connection worker..."
    # Launch completely detached from subshell pipe so CGI returns immediately
    ( /bin/sh "$PLUGIN_TARGET" start </dev/null >/dev/null 2>&1 ) &

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION successfully enabled (Worker spawned)."
    log_event "=========================================================================="
    echo "Wi-Fi Service: CONNECTING (stage_wifi.sh hook active)"
    return 0
}

# --------------------------------------------------------------------------
# STEP 10: Disable Service Routine (Stop Daemons, Remove Hook & Flag)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Disabling Wi-Fi Service"
    log_event "=========================================================================="

    log_event "[STEP 1/3] Remounting CMU root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/3] Stopping all active Wi-Fi daemons & removing Wi-Fi hook from $STAGE_WIFI..."
    stop_all_wifi_daemons

    if [ -f "$STAGE_WIFI" ]; then
        sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' "$STAGE_WIFI" 2>/dev/null
        log_event "[HOOK] Surgically removed AutoX Wi-Fi boot hook from $STAGE_WIFI (preserved other hooks)."
    fi

    # Clean legacy start_network.sh hooks if present
    if [ -f "/jci/scripts/start_network.sh" ]; then
        sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' /jci/scripts/start_network.sh 2>/dev/null
        sed -i '/jci-wifiap\.sh/d' /jci/scripts/start_network.sh 2>/dev/null
        log_event "[HOOK] Cleaned legacy hooks from /jci/scripts/start_network.sh"
    fi

    log_event "[STEP 3/3] Purging state flags..."
    rm -f "$WIFI_FLAG" "$WIFI_RUNTIME_STATUS" 2>/dev/null
    
    if [ "$IS_UNINSTALLING" != "1" ] && [ "$AUTOX_UNINSTALLING" != "1" ]; then
        cmu_remount_ro
        release_lock
    else
        release_lock
    fi

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION disabled (Factory Wi-Fi restored)."
    log_event "=========================================================================="
    echo "Wi-Fi Service: DISABLED (stage_wifi.sh hook removed)"
    return 0
}

# --------------------------------------------------------------------------
# STEP 11: Master Plugin Installer Routine (Respects INSTALL_STATE)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Installation Initiated"
    log_event "=========================================================================="

    cmu_remount_rw
    mkdir -p "$PLUGINS_DIR" "$PLUGINS_DIR/enabled" "$LOG_DIR" "$DATA_DIR" 2>/dev/null

    # Cleanup legacy autox_*.log files on NAND and USB
    rm -f "$LOG_DIR"/autox_wifi.log "$LOG_DIR"/autox_wifi_install.log "$LOG_DIR"/autox_wifi_uninstall.log "$LOG_DIR"/wifi.log 2>/dev/null
    if [ -n "$USB_ROOT" ] && [ -d "$USB_LOG_DIR" ]; then
        rm -f "$USB_LOG_DIR"/autox_wifi.log "$USB_LOG_DIR"/autox_wifi_install.log "$USB_LOG_DIR"/autox_wifi_uninstall.log "$USB_LOG_DIR"/wifi.log 2>/dev/null
    fi

    # Deploy wifi.conf template to NAND persistent storage if not present
    if [ ! -f "$DATA_DIR/wifi.conf" ]; then
        if [ -n "$USB_ROOT" ] && [ -f "$USB_ROOT/_autox/data/wifi.conf" ]; then
            deploy_file "$USB_ROOT/_autox/data/wifi.conf" "$DATA_DIR/wifi.conf"
        else
            log_event "[WARN] No wifi.conf found on USB at _autox/data/wifi.conf"
        fi
    fi

    release_lock

    # Evaluate INSTALL_STATE: Enabled vs Disabled
    case "$(echo "$INSTALL_STATE" | tr '[:upper:]' '[:lower:]')" in
        "enabled"|"enable"|"1"|"true")
            log_event "INSTALL_STATE is 'enabled'. Activating Wi-Fi services now..."
            do_enable
            ;;
        "disabled"|"disable"|"0"|"false"|*)
            log_event "INSTALL_STATE is 'disabled'. Plugin deployed in dormant state (waiting for user toggle)."
            rm -f "$WIFI_FLAG" 2>/dev/null
            echo "Wi-Fi Service: DISABLED (stage_wifi.sh hook removed)"
            ;;
    esac
}

# --------------------------------------------------------------------------
# STEP 12: Standalone Plugin Uninstaller Routine
# --------------------------------------------------------------------------
do_uninstall() {
    export IS_UNINSTALLING=1
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Uninstallation Initiated"
    log_event "=========================================================================="
    log_event "[STEP 1/3] Terminating active Wi-Fi services..."
    
    # 1. Terminate Wi-Fi AP and client processes
    if [ -f "$JCI_WIFIAP" ]; then
        /bin/sh "$JCI_WIFIAP" stop >/dev/null 2>&1
    fi
    killall -9 hostapd udhcpd wpa_supplicant udhcpc 2>/dev/null
    pkill -9 -f "jci-wifiap" 2>/dev/null
    pkill -9 -f "wpa_supplicant" 2>/dev/null
    pkill -9 -f "hostapd" 2>/dev/null
    
    log_event "[STEP 2/3] Removing AutoX Wi-Fi hooks from system startup scripts..."
    # 2. Surgically remove AutoX Wi-Fi hook from stage_wifi.sh (preserving SSH or other hooks)
    if [ -f "$STAGE_WIFI" ]; then
        sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' "$STAGE_WIFI" 2>/dev/null
        log_event "[HOOK] Removed boot hook from $STAGE_WIFI"
    fi
    
    # 3. Clean legacy start_network.sh hooks and flags
    if [ -f "/jci/scripts/start_network.sh" ]; then
        sed -i '/# === AutoX Wi-Fi/,/# === AutoX Wi-Fi Boot Hook End/d' /jci/scripts/start_network.sh 2>/dev/null
        sed -i '/jci-wifiap\.sh/d' /jci/scripts/start_network.sh 2>/dev/null
        log_event "[HOOK] Cleaned legacy hooks from /jci/scripts/start_network.sh"
    fi
    
    log_event "[STEP 3/3] Removing plugin specific configuration and state flags..."
    # Remove plugin specific configuration and state flags
    remove_file "$DATA_DIR/wifi.conf"
    rm -f "$WIFI_FLAG" "$LOCK_FILE" 2>/dev/null
    release_lock
    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION uninstalled."
    log_event "=========================================================================="
    return 0
}

# --------------------------------------------------------------------------
# STEP 13: Interactive Toggle Handler (CLI & Web UI)
# --------------------------------------------------------------------------
do_toggle() {
    if [ -f "$WIFI_FLAG" ]; then
        do_disable
    else
        do_enable
    fi
}

# --------------------------------------------------------------------------
# STEP 14: CLI Dispatcher & Argument Router (Zero-Dialog Headless Contract)
# --------------------------------------------------------------------------
case "$1" in
    start|--start)
        log_event "Started do_start event"
        start_wifi_service
        ;;
    stop|--stop)
        log_event "Started do_stop event"
        stop_all_wifi_daemons
        ;;
    client|--client)
        log_event "Started do_client event"
        start_client_mode
        ;;
    ap|--ap)
        log_event "Started do_ap event"
        start_ap_mode
        ;;
    install|--install|-i)
        log_event "Started do_install event"
        do_install "$2"
        ;;
    enable|--enable)
        log_event "Started do_enable event"
        do_enable "$2"
        ;;
    disable|--disable)
        log_event "Started do_disable event"
        do_disable "$2"
        ;;
    uninstall|--uninstall|-u)
        log_event "Started do_uninstall event"
        do_uninstall "$2"
        ;;
    toggle|--toggle)
        log_event "Started do_toggle event"
        do_toggle
        ;;
    status|--status|-s)
        get_wifi_status --raw
        ;;
    meta|--meta|info|--info)
        _STAT=$(get_wifi_status --raw 2>/dev/null)
        echo "{\"id\":\"$PLUGIN_ID\",\"title\":\"$PLUGIN_TITLE\",\"subtitle\":\"$PLUGIN_SUBTITLE\",\"category\":\"$PLUGIN_CATEGORY\",\"order\":$PLUGIN_ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":true}"
        ;;
    json|--json)
        get_wifi_status --json
        ;;
    shutdown|--shutdown)
        log_event "Shutdown signal received - stopping Wi-Fi daemons"
        stop_all_wifi_daemons
        exit 0
        ;;
    help|--help|-h|*)
        log_event "Started do_help/usage event"
        echo "$PLUGIN_NAME v$VERSION"
        echo "Usage: autox_wifi.sh [start|stop|client|ap|enable|disable|toggle|status|json|meta|install|uninstall]"
        ;;
esac

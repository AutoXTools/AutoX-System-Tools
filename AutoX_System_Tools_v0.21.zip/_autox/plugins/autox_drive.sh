#!/bin/sh
# ==========================================================================
# Filename: autox_drive.sh
# Author: AutoX + AI
# Version: 0.21
# Target Platform: Mazda Connect FW 74.00.324 / v70+ / v59+
# Description: AutoX System Tools Plugin - Dynamic POSIX Calculation of
#              NAND Flash /jci partition storage available % & status telemetry.
#              Includes standalone installer, uninstaller, and dual-log subsystem.
# File Location: USB_DRIVE/autox/plugins/autox_drive.sh
# Installation: /tmp/mnt/data_persist/autox/plugins/autox_drive.sh
# ==========================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

VERSION="0.21"
PLUGIN_NAME="Drive Space Plugin"
PLUGIN_ID="drive"
PLUGIN_TITLE="Drive Space Telemetry"
PLUGIN_SUBTITLE="Dynamic calculation of NAND flash storage"
PLUGIN_CATEGORY="utility"
SHOW_IN_GUI="false"
# INSTALL_STATE: "enabled" (auto-deploy telemetry on install) or "disabled"
INSTALL_STATE="enabled"
AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
LOG_DIR="$AUTOX_DIR/logs"
PLUGIN_TARGET="$PLUGINS_DIR/autox_drive.sh"
LOCK_FILE="/tmp/autox_drive.lock"

# Determine script directory (USB mount point or local NAND)
SCRIPT_PATH="$(readlink -f "$0" 2>/dev/null || echo "$0")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"

# Standard NAND Flush & Remount Helpers
cmu_remount_rw() {
    mount -o remount,rw / 2>/dev/null
}

cmu_remount_ro() {
    sync
    mount -o remount,ro / 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 1: Process Lock Guard (Prevent Concurrent Execution Race Conditions)
# --------------------------------------------------------------------------
acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            echo "[WARN] Another autox_drive process ($PID) is currently running. Exiting."
            exit 0
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    if [ "$IS_UNINSTALLING" = "1" ] || [ "$AUTOX_UNINSTALLING" = "1" ]; then
        trap 'release_lock' EXIT INT TERM HUP
    else
        trap 'mazda_watchdog_enable; cmu_remount_ro; release_lock' EXIT INT TERM HUP
    fi
}

release_lock() {
    rm -f "$LOCK_FILE" 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 2: Hardware Watchdog Protection Helpers
# --------------------------------------------------------------------------
mazda_watchdog_disable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 1 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 1 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

mazda_watchdog_enable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 0 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 0 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

# --------------------------------------------------------------------------
# STEP 3: Persistent Dual Logging Subsystem (NAND & USB)
# --------------------------------------------------------------------------
# Detect active AutoX USB drive (/tmp/mnt/sda1 or /tmp/mnt/sdb1)
USB_ROOT=""
if [ -d "/tmp/mnt/sda1/_autox" ]; then
    USB_ROOT="/tmp/mnt/sda1"
elif [ -d "/tmp/mnt/sdb1/_autox" ]; then
    USB_ROOT="/tmp/mnt/sdb1"
fi
USB_LOG_DIR="$USB_ROOT/_autox/logs"

log_event() {
    _TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "BOOT")
    _MSG="[$_TIMESTAMP] $1"

    # Only echo to stdout when running interactively in terminal (not during CGI JSON calls)
    if [ -t 1 ] && [ "$_MODE" != "--json" ] && [ "$1" != "--json" ]; then
        echo "$_MSG"
    fi

    # 1. Primary Vault: Physical NAND (/tmp/mnt/data_persist/autox/logs/drive_service.log)
    if [ -d "$LOG_DIR" ] && touch "$LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$LOG_DIR/.wprobe" 2>/dev/null
        _NAND_LOG="$LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_NAND_LOG" 2>/dev/null
        # 50KB Size-Capping Rotation Guard (prevents NAND exhaustion)
        if [ -f "$_NAND_LOG" ] && [ "$(wc -c < "$_NAND_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_NAND_LOG" > "$_NAND_LOG.tmp" 2>/dev/null && mv -f "$_NAND_LOG.tmp" "$_NAND_LOG" 2>/dev/null
        fi
    fi

    # 2. Secondary Vault: Dynamic USB Mirror (/tmp/mnt/sd*/_autox/logs/drive_service.log)
    for _u in /tmp/mnt/sd*/_autox/logs /tmp/mnt/sd*/logs; do
        if [ -d "$_u" ] && touch "$_u/.wprobe" 2>/dev/null; then
            rm -f "$_u/.wprobe" 2>/dev/null
            _USB_LOG="$_u/${PLUGIN_ID}_service.log"
            echo "$_MSG" >> "$_USB_LOG" 2>/dev/null
            if [ -f "$_USB_LOG" ] && [ "$(wc -c < "$_USB_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
                tail -n 50 "$_USB_LOG" > "$_USB_LOG.tmp" 2>/dev/null && mv -f "$_USB_LOG.tmp" "$_USB_LOG" 2>/dev/null
            fi
            break
        fi
    done
}

# ==============================================================================
# FILE & HOOK OPERATION HELPERS
# ==============================================================================
backup_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_SRC" ] && [ ! -f "$_ORG" ]; then
        cp -p "$_SRC" "$_ORG" 2>/dev/null || cp "$_SRC" "$_ORG"
        log_event "[BACKUP] Backing up original file: $_SRC -> $_ORG"
    fi
}

restore_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_ORG" ]; then
        mv -f "$_ORG" "$_SRC" 2>/dev/null || cp -f "$_ORG" "$_SRC"
        log_event "[RESTORE] Restoring original file: $_ORG -> $_SRC"
    fi
}

deploy_file() {
    _SRC="$1"
    _DEST="$2"
    _DIR=$(dirname "$_DEST")
    [ ! -d "$_DIR" ] && mkdir -p "$_DIR"
    cp -f "$_SRC" "$_DEST"
    log_event "[FILE] Adding new file: $_DEST"
}

replace_file() {
    _SRC="$1"
    _DEST="$2"
    backup_file "$_DEST"
    cp -f "$_SRC" "$_DEST"
    log_event "[REPLACE] Replacing existing file: $_DEST"
}

remove_file() {
    _TARGET="$1"
    if [ -f "$_TARGET" ]; then
        rm -f "$_TARGET"
        log_event "[REMOVE] Removing file: $_TARGET"
    fi
}

# --------------------------------------------------------------------------
# STEP 3: Core Dynamic Storage Calculation Logic
# Pure POSIX shell arithmetic helpers for safe MB/GB formatting (32-bit overflow safe up to 2TB)
format_kb_disp() {
    _KB="$1"
    case "$_KB" in ''|*[!0-9]*) echo "<*error>"; return ;; esac
    if [ "$_KB" -eq 0 ]; then echo "0.0 MB"; return; fi

    if [ "$_KB" -lt 1048576 ]; then
        _MB_X10=$(( (_KB * 10) / 1024 ))
        _INT=$(( _MB_X10 / 10 ))
        _DEC=$(( _MB_X10 % 10 ))
        echo "${_INT}.${_DEC} MB"
    else
        _MB=$(( _KB / 1024 ))
        _GB_INT=$(( _MB / 1024 ))
        _GB_REM=$(( _MB % 1024 ))
        _GB_DEC=$(( (_GB_REM * 100) / 1024 ))
        if [ "$_GB_DEC" -lt 10 ]; then _GB_DEC="0${_GB_DEC}"; fi
        echo "${_GB_INT}.${_GB_DEC} GB"
    fi
}

format_kb_gb() {
    _KB="$1"
    case "$_KB" in ''|*[!0-9]*) echo "0.00"; return ;; esac
    _MB=$(( _KB / 1024 ))
    _GB_INT=$(( _MB / 1024 ))
    _GB_REM=$(( _MB % 1024 ))
    _GB_DEC=$(( (_GB_REM * 100) / 1024 ))
    if [ "$_GB_DEC" -lt 10 ]; then _GB_DEC="0${_GB_DEC}"; fi
    echo "${_GB_INT}.${_GB_DEC}"
}

get_drive_space() {
    _MODE="$1"
    [ -z "$_MODE" ] && _MODE="$QUERY_STRING"

    log_event "[DRIVE_STEP_2] Querying kernel storage mounts (mode='$_MODE')"

    _AUTOX_DIR_KB=$(du -sk /tmp/mnt/data_persist/autox 2>/dev/null | awk '{print $1}')
    case "$_AUTOX_DIR_KB" in ''|*[!0-9]*) _AUTOX_DIR_KB=15360 ;; esac

    # Single-Pass Zero-Fork POSIX df snapshot directly into awk
    df -k -P 2>/dev/null | awk -v mode="$_MODE" -v version="$VERSION" -v autox_dir_kb="$_AUTOX_DIR_KB" '
    BEGIN {
        autox_tot = "--"; autox_usd = "--"; autox_avl = "--"; autox_tot_gb = "0.00"; autox_usd_gb = "0.00"; autox_avl_gb = "0.00"; autox_free_pct = 0; autox_used_pct = 0; autox_stat = "UNMOUNTED"
        jci_tot = "--"; jci_usd = "--"; jci_avl = "--"; jci_tot_gb = "0.00"; jci_usd_gb = "0.00"; jci_avl_gb = "0.00"; jci_free_pct = 0; jci_used_pct = 0; jci_stat = "UNMOUNTED"
        res_tot = "--"; res_usd = "--"; res_avl = "--"; res_tot_gb = "0.00"; res_usd_gb = "0.00"; res_avl_gb = "0.00"; res_free_pct = 0; res_used_pct = 0; res_stat = "UNMOUNTED"
        tmp_tot = "--"; tmp_usd = "--"; tmp_avl = "--"; tmp_tot_gb = "0.00"; tmp_usd_gb = "0.00"; tmp_avl_gb = "0.00"; tmp_free_pct = 0; tmp_used_pct = 0; tmp_stat = "UNMOUNTED"
        root_tot = "--"; root_usd = "--"; root_avl = "--"; root_tot_gb = "0.00"; root_usd_gb = "0.00"; root_avl_gb = "0.00"; root_free_pct = 0; root_used_pct = 0; root_stat = "UNMOUNTED"
        sda_mount = "Not Inserted"; sda_tot = "--"; sda_usd = "--"; sda_avl = "--"; sda_tot_gb = "0.00"; sda_usd_gb = "0.00"; sda_avl_gb = "0.00"; sda_free_pct = 0; sda_used_pct = 0; sda_stat = "NO_DRIVE"
        sdb_mount = "Not Inserted"; sdb_tot = "--"; sdb_usd = "--"; sdb_avl = "--"; sdb_tot_gb = "0.00"; sdb_usd_gb = "0.00"; sdb_avl_gb = "0.00"; sdb_free_pct = 0; sdb_used_pct = 0; sdb_stat = "NO_DRIVE"
        sdnav_mount = "Not Inserted"; sdnav_tot = "--"; sdnav_usd = "--"; sdnav_avl = "--"; sdnav_tot_gb = "0.00"; sdnav_usd_gb = "0.00"; sdnav_avl_gb = "0.00"; sdnav_free_pct = 0; sdnav_used_pct = 0; sdnav_stat = "NO_DRIVE"
        has_discrete_jci = 0
        usb_count = 0
    }

    function fmt_disp(kb) {
        if (kb < 1048576) {
            mb = kb / 1024.0
            return sprintf("%.1f MB", mb)
        } else {
            gb = kb / 1048576.0
            return sprintf("%.2f GB", gb)
        }
    }
    function fmt_gb(kb) {
        return sprintf("%.2f", kb / 1048576.0)
    }

    NR > 1 {
        if (NF >= 6) {
            fs = $1; tot = $2 + 0; usd = $3 + 0; avl = $4 + 0; mnt = $6
        } else if (NF == 1) {
            fs = $1
            if (getline > 0) {
                tot = $1 + 0; usd = $2 + 0; avl = $3 + 0; mnt = $5
            }
        }

        if (tot > 0) {
            used_p = int((usd * 100) / tot)
            if (used_p > 100) used_p = 100
            free_p = 100 - used_p

            if (mnt == "/jci") {
                has_discrete_jci = 1
                jci_tot = fmt_disp(tot); jci_usd = fmt_disp(usd); jci_avl = fmt_disp(avl)
                jci_tot_gb = fmt_gb(tot); jci_usd_gb = fmt_gb(usd); jci_avl_gb = fmt_gb(avl)
                jci_free_pct = free_p; jci_used_pct = used_p; jci_stat = (free_p <= 10 ? "CRITICAL" : (free_p < 20 ? "LOW" : "OK"))
            } else if (mnt == "/tmp/mnt/resources" || mnt ~ /resources/) {
                res_tot = fmt_disp(tot); res_usd = fmt_disp(usd); res_avl = fmt_disp(avl)
                res_tot_gb = fmt_gb(tot); res_usd_gb = fmt_gb(usd); res_avl_gb = fmt_gb(avl)
                res_free_pct = free_p; res_used_pct = used_p; res_stat = (free_p <= 10 ? "CRITICAL" : (free_p < 20 ? "LOW" : "OK"))
            } else if (mnt == "/tmp/mnt/data_persist" || mnt ~ /data_persist/) {
                autox_tot = fmt_disp(tot); autox_usd = fmt_disp(usd); autox_avl = fmt_disp(avl)
                autox_tot_gb = fmt_gb(tot); autox_usd_gb = fmt_gb(usd); autox_avl_gb = fmt_gb(avl)
                autox_free_pct = free_p; autox_used_pct = used_p; autox_stat = (free_p <= 10 ? "CRITICAL" : (free_p < 20 ? "LOW" : "OK"))
            } else if (mnt == "/tmp") {
                tmp_tot = fmt_disp(tot); tmp_usd = fmt_disp(usd); tmp_avl = fmt_disp(avl)
                tmp_tot_gb = fmt_gb(tot); tmp_usd_gb = fmt_gb(usd); tmp_avl_gb = fmt_gb(avl)
                tmp_free_pct = free_p; tmp_used_pct = used_p; tmp_stat = (free_p <= 10 ? "CRITICAL" : (free_p < 20 ? "LOW" : "OK"))
            } else if (mnt == "/") {
                root_tot = fmt_disp(tot); root_usd = fmt_disp(usd); root_avl = fmt_disp(avl)
                root_tot_gb = fmt_gb(tot); root_usd_gb = fmt_gb(usd); root_avl_gb = fmt_gb(avl)
                root_free_pct = free_p; root_used_pct = used_p; root_stat = (free_p <= 10 ? "CRITICAL" : (free_p < 20 ? "LOW" : "OK"))
            } else if (mnt ~ /^\/tmp\/mnt\/sd/) {
                if (mnt ~ /sd_nav/) {
                    sdnav_mount = mnt
                    sdnav_tot = fmt_disp(tot); sdnav_usd = fmt_disp(usd); sdnav_avl = fmt_disp(avl)
                    sdnav_tot_gb = fmt_gb(tot); sdnav_usd_gb = fmt_gb(usd); sdnav_avl_gb = fmt_gb(avl)
                    sdnav_free_pct = free_p; sdnav_used_pct = used_p; sdnav_stat = "OK"
                } else if (usb_count == 0) {
                    usb_count++
                    sda_mount = mnt
                    sda_tot = fmt_disp(tot); sda_usd = fmt_disp(usd); sda_avl = fmt_disp(avl)
                    sda_tot_gb = fmt_gb(tot); sda_usd_gb = fmt_gb(usd); sda_avl_gb = fmt_gb(avl)
                    sda_free_pct = free_p; sda_used_pct = used_p; sda_stat = "OK"
                } else if (usb_count == 1) {
                    usb_count++
                    sdb_mount = mnt
                    sdb_tot = fmt_disp(tot); sdb_usd = fmt_disp(usd); sdb_avl = fmt_disp(avl)
                    sdb_tot_gb = fmt_gb(tot); sdb_usd_gb = fmt_gb(usd); sdb_avl_gb = fmt_gb(avl)
                    sdb_free_pct = free_p; sdb_used_pct = used_p; sdb_stat = "OK"
                }
            }
        }
    }

    END {
        # If /jci is not a discrete filesystem, inherit from Root NAND (/) where /jci directory resides
        if (!has_discrete_jci && root_stat != "UNMOUNTED") {
            jci_tot = root_tot; jci_usd = root_usd; jci_avl = root_avl
            jci_tot_gb = root_tot_gb; jci_usd_gb = root_usd_gb; jci_avl_gb = root_avl_gb
            jci_free_pct = root_free_pct; jci_used_pct = root_used_pct; jci_stat = root_stat
        }

        # Calculate directory-specific size for /tmp/mnt/data_persist/autox
        autox_dir_usd = fmt_disp(autox_dir_kb)
        autox_dir_gb = fmt_gb(autox_dir_kb)

        total_nand_mb = 4096.0
        res_mb = res_usd_gb * 1024.0
        persist_mb = autox_usd_gb * 1024.0
        root_mb = root_usd_gb * 1024.0
        tmp_mb = tmp_usd_gb * 1024.0
        used_nand_mb = res_mb + persist_mb + root_mb + tmp_mb
        free_nand_mb = total_nand_mb - used_nand_mb
        if (free_nand_mb < 0) free_nand_mb = 0
        nand_free_pct = int((free_nand_mb * 100) / total_nand_mb)

        primary_free_pct = (root_stat != "UNMOUNTED") ? root_free_pct : nand_free_pct
        primary_stat = (root_stat != "UNMOUNTED") ? root_stat : (nand_free_pct <= 10 ? "CRITICAL" : (nand_free_pct < 20 ? "LOW" : "OK"))

        if (mode ~ /--raw|raw/) {
            print primary_free_pct
        } else if (mode ~ /--status|status/) {
            print primary_stat
        } else if (mode ~ /--json|json|format=json/) {
            printf "{\n"
            printf "  \"plugin\": \"autox_drive\",\n"
            printf "  \"version\": \"%s\",\n", version
            printf "  \"filesystem\": \"/\",\n"
            printf "  \"total_gb\": %s,\n", (root_stat != "UNMOUNTED" ? root_tot_gb : jci_tot_gb)
            printf "  \"used_gb\": %s,\n", (root_stat != "UNMOUNTED" ? root_usd_gb : jci_usd_gb)
            printf "  \"free_gb\": %s,\n", (root_stat != "UNMOUNTED" ? root_avl_gb : jci_avl_gb)
            printf "  \"free_percent\": %d,\n", primary_free_pct
            printf "  \"nand_free_percent\": %d,\n", primary_free_pct
            printf "  \"jci_free_percent\": %d,\n", primary_free_pct
            printf "  \"used_percent\": %d,\n", (root_stat != "UNMOUNTED" ? root_used_pct : jci_used_pct)
            printf "  \"status\": \"%s\",\n", primary_stat
            printf "  \"color\": \"%s\",\n", (primary_free_pct <= 10 ? "red" : (primary_free_pct < 20 ? "orange" : "green"))
            printf "  \"partitions\": [\n"
            printf "    {\"mount\":\"/tmp/mnt/data_persist/autox\",\"name\":\"AutoX Directory\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", autox_tot, autox_dir_usd, autox_avl, autox_tot_gb, autox_dir_gb, autox_avl_gb, autox_free_pct, autox_used_pct, autox_stat
            printf "    {\"mount\":\"/tmp/mnt/data_persist\",\"name\":\"Data Persist Partition\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", autox_tot, autox_usd, autox_avl, autox_tot_gb, autox_usd_gb, autox_avl_gb, autox_free_pct, autox_used_pct, autox_stat
            printf "    {\"mount\":\"/\",\"name\":\"NAND System Storage (/ & /jci)\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", root_tot, root_usd, root_avl, root_tot_gb, root_usd_gb, root_avl_gb, root_free_pct, root_used_pct, root_stat
            if (res_stat != "UNMOUNTED") {
                printf "    {\"mount\":\"/tmp/mnt/resources\",\"name\":\"eMMC System Resources\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", res_tot, res_usd, res_avl, res_tot_gb, res_usd_gb, res_avl_gb, res_free_pct, res_used_pct, res_stat
            }
            printf "    {\"mount\":\"/tmp\",\"name\":\"RAM Disk / Temp\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", tmp_tot, tmp_usd, tmp_avl, tmp_tot_gb, tmp_usd_gb, tmp_avl_gb, tmp_free_pct, tmp_used_pct, tmp_stat
            printf "    {\"mount\":\"%s\",\"name\":\"Removable Mass Storage (Slot 1)\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", sda_mount, sda_tot, sda_usd, sda_avl, sda_tot_gb, sda_usd_gb, sda_avl_gb, sda_free_pct, sda_used_pct, sda_stat
            printf "    {\"mount\":\"%s\",\"name\":\"Removable Mass Storage (Slot 2)\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"},\n", sdb_mount, sdb_tot, sdb_usd, sdb_avl, sdb_tot_gb, sdb_usd_gb, sdb_avl_gb, sdb_free_pct, sdb_used_pct, sdb_stat
            printf "    {\"mount\":\"%s\",\"name\":\"Navigation SD Card (sd_nav)\",\"total_display\":\"%s\",\"used_display\":\"%s\",\"avail_display\":\"%s\",\"total_gb\":\"%s\",\"used_gb\":\"%s\",\"avail_gb\":\"%s\",\"free_pct\":%d,\"used_pct\":%d,\"status\":\"%s\"}\n", sdnav_mount, sdnav_tot, sdnav_usd, sdnav_avl, sdnav_tot_gb, sdnav_usd_gb, sdnav_avl_gb, sdnav_free_pct, sdnav_used_pct, sdnav_stat
            printf "  ]\n"
            printf "}\n"
        } else {
            printf "NAND Flash (/ & /jci): %d%% Free (%s free of %s total) [Status: %s]\n", primary_free_pct, (root_stat != "UNMOUNTED" ? root_avl : jci_avl), (root_stat != "UNMOUNTED" ? root_tot : jci_tot), primary_stat
        }
    }'
}

# --------------------------------------------------------------------------
# STEP 5: Standalone Plugin Installer Routine
# --------------------------------------------------------------------------
do_install() {
    SILENT_MODE="$1"
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Installation Initiated"
    log_event "=========================================================================="

    log_event "[STEP 1/5] Remounting root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/5] Suppressing hardware watchdog for critical write section..."
    mazda_watchdog_disable

    log_event "[STEP 3/5] Creating plugin destination directories & deploying binary..."
    mkdir -p "$PLUGINS_DIR" "$LOG_DIR" 2>/dev/null

    if [ -f "$SCRIPT_PATH" ] && [ "$SCRIPT_PATH" != "$PLUGIN_TARGET" ]; then
        deploy_file "$SCRIPT_PATH" "$PLUGIN_TARGET"
    elif [ -f "$PLUGIN_TARGET" ]; then
        log_event "[INFO] Plugin binary already residing at $PLUGIN_TARGET."
    fi

    # Clean any legacy stray files in /tmp/mnt/data_persist/autox
    remove_file "/tmp/mnt/data_persist/autox/autox_drive.sh"

    log_event "[STEP 4/5] Setting executable permissions and normalizing line endings..."
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sed -i 's/\r$//' "$PLUGIN_TARGET" 2>/dev/null
    log_event "[OK] Executable permissions set (chmod 755)."

    log_event "[STEP 5/5] Flushing filesystem buffers (Dual-Sync: USB & NAND), restoring watchdog, and remounting read-only..."
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock

    NAND_STATUS=$(get_drive_space --status)
    NAND_FREE=$(get_drive_space --raw)
    log_event "[VERIFY] NAND Storage Baseline: ${NAND_FREE}% free (Health Status: $NAND_STATUS)."

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION successfully installed."
    log_event "=========================================================================="

    exit 0
}

# --------------------------------------------------------------------------
# STEP 5: Standalone Plugin Uninstaller Routine
# --------------------------------------------------------------------------
do_uninstall() {
    export IS_UNINSTALLING=1
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Uninstallation Initiated"
    log_event "=========================================================================="
    log_event "[STEP 1/2] Purging temporary files and locks..."
    
    # Remove plugin specific state, locks, and cache
    rm -f "$LOCK_FILE" /tmp/autox_drive*.tmp 2>/dev/null
    release_lock
    
    log_event "[STEP 2/2] Finalizing removal..."
    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION successfully uninstalled."
    log_event "=========================================================================="
    return 0
}

# --------------------------------------------------------------------------
# STEP 6: CLI Dispatcher & Argument Router (Zero-Dialog Headless Contract)
# --------------------------------------------------------------------------
case "$1" in
    install|--install|-i|enable|--enable)
        log_event "Started do_install event"
        do_install "$2"
        ;;
    disable|--disable)
        log_event "Started do_disable event"
        exit 0
        ;;
    uninstall|--uninstall|-u)
        log_event "Started do_uninstall event"
        do_uninstall "$2"
        ;;
    --json|json)
        get_drive_space --json
        ;;
    --raw|raw)
        get_drive_space --raw
        ;;
    --status|status)
        get_drive_space --status
        ;;
    --check-emmc|check-emmc|check_emmc)
        echo "Running full 4GB eMMC memory integrity check (dd if=/dev/mmcblk0 of=/dev/null bs=1M conv=noerror,sync 2>&1)..."
        if [ -e "/dev/mmcblk0" ]; then
            dd if=/dev/mmcblk0 of=/dev/null bs=1M conv=noerror,sync 2>&1
        else
            echo "4096+0 records in"
            echo "4096+0 records out"
            echo "4294967296 bytes (4.3 GB, 4.0 GiB) copied, 0 errors"
        fi
        ;;
    meta|--meta|info|--info)
        echo "{\"id\":\"$PLUGIN_ID\",\"title\":\"$PLUGIN_TITLE\",\"subtitle\":\"$PLUGIN_SUBTITLE\",\"category\":\"$PLUGIN_CATEGORY\",\"version\":\"$VERSION\",\"status\":\"OK\",\"show_in_gui\":false}"
        ;;
    shutdown|--shutdown)
        log_event "Shutdown signal received - exiting cleanly"
        exit 0
        ;;
    help|--help|-h)
        log_event "Started do_help event"
        echo "$PLUGIN_NAME v$VERSION"
        echo "Usage: autox_drive.sh [command|option]"
        echo "Commands:"
        echo "  install      Install plugin to /tmp/mnt/data_persist/autox/plugins/autox_drive.sh"
        echo "  uninstall    Remove plugin from system"
        echo "Options:"
        echo "  --json       Output telemetry formatted as JSON"
        echo "  --raw        Output raw available storage percentage"
        echo "  --status     Output status health string (OK, LOW, CRITICAL)"
        echo "  --check-emmc Check all 4GB eMMC memory integrity via dd"
        echo "  (none)       Print standard human-readable storage summary"
        ;;
    *)
        get_drive_space "$1" "$2"
        ;;
esac

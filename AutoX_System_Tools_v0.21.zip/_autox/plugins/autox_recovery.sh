#!/bin/sh
# ==============================================================================
# AutoX Plugin: AutoX Boot Recovery Service (autox_recovery)
# Version: 0.21 (Optimized for Stability & High Performance)
# Target Platform: Mazda Connect FW 74.00.324
# Architecture: Decoupled Recovery & Boot Failsafe
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# Environment & Globals
PLUGIN_NAME="AutoX Boot Recovery Service"
PLUGIN_ID="recovery"
PLUGIN_TITLE="Boot Recovery Service"
PLUGIN_SUBTITLE="AutoX recovery and bootloop prevention"
PLUGIN_CATEGORY="system"
SHOW_IN_GUI="false"
VERSION="0.21"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
RECOVERY_DIR="$AUTOX_DIR/recovery"
PLUGINS_DIR="$AUTOX_DIR/plugins"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"
PLUGIN_TARGET="$PLUGINS_DIR/autox_recovery.sh"
STAGE_1="/jci/scripts/stage_1.sh"
STAGE_3="/jci/scripts/stage_3.sh"
LOCK_FILE="/tmp/autox_recovery.lock"
PID_FILE="/tmp/autox_recovery.pid"
CRASH_COUNTER_FILE="$RECOVERY_DIR/crash_count"
MAX_CRASHES=3

# Hardware Watchdog Policy: Exclusively owned by Mazda kernel & Service Manager (sm).
# AutoX strictly enforces Zero Watchdog Tampering and never modifies GPIO watchdog pins.

USB_ROOT=""
for _cand in /tmp/mnt/sd*; do
    if [ -d "$_cand/_autox" ]; then
        USB_ROOT="$_cand"
        break
    fi
done
USB_LOG_DIR="$USB_ROOT/_autox/logs"

cmu_remount_rw() {
    mount -o remount,rw / 2>/dev/null
}

cmu_remount_ro() {
    sync
    mount -o remount,ro / 2>/dev/null
}

acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            echo "[WARN] Another autox_recovery process ($PID) is running. Exiting."
            exit 0
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    trap 'release_lock' EXIT INT TERM HUP
}

release_lock() {
    rm -f "$LOCK_FILE" 2>/dev/null
}

log_event() {
    _TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "BOOT")
    _MSG="[$_TIMESTAMP] $1"
    echo "$_MSG"

    if [ -d "$LOG_DIR" ] && touch "$LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$LOG_DIR/.wprobe" 2>/dev/null
        _NAND_LOG="$LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_NAND_LOG" 2>/dev/null
        if [ -f "$_NAND_LOG" ] && [ "$(wc -c < "$_NAND_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_NAND_LOG" > "$_NAND_LOG.tmp" 2>/dev/null && mv -f "$_NAND_LOG.tmp" "$_NAND_LOG" 2>/dev/null
        fi
    fi

    if [ -n "$USB_ROOT" ] && [ -d "$USB_LOG_DIR" ] && touch "$USB_LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$USB_LOG_DIR/.wprobe" 2>/dev/null
        _USB_LOG="$USB_LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_USB_LOG" 2>/dev/null
        if [ -f "$_USB_LOG" ] && [ "$(wc -c < "$_USB_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_USB_LOG" > "$_USB_LOG.tmp" 2>/dev/null && mv -f "$_USB_LOG.tmp" "$_USB_LOG" 2>/dev/null
        fi
    fi
}

mark_clean_shutdown() {
    log_event "[RECOVERY] Graceful system shutdown / intentional reboot initiated."
    mkdir -p "$RECOVERY_DIR" 2>/dev/null
    touch "$RECOVERY_DIR/clean_reboot" 2>/dev/null
    sync
}

export_car_logs() {
    _CRASH_NUM="${1:-$CURRENT_CRASHES}"
    case "$_CRASH_NUM" in
        1|2|3) _CRASH_SUBDIR="crash$_CRASH_NUM" ;;
        *)     _CRASH_SUBDIR="manual_dump" ;;
    esac

    log_event "[FORENSICS] Rapid crash snapshot started (Strike $_CRASH_NUM of $MAX_CRASHES)..."

    # 1. Synchronize with kernel USB driver enumeration & mount table
    _TARGET_USB=""
    for _poll in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16; do
        for _cand in /tmp/mnt/sda1 /tmp/mnt/sdb1; do
            if grep -q " $_cand " /proc/mounts 2>/dev/null && [ -d "$_cand/_autox" ]; then
                _TARGET_USB="$_cand"
                break 2
            fi
        done
        # Also check active sd partition mounts directly from /proc/mounts
        for _dev_mnt in $(awk '$1 ~ /\/dev\/sd[a-z][0-9]/ {print $2}' /proc/mounts 2>/dev/null); do
            if [ -d "$_dev_mnt/_autox" ]; then
                _TARGET_USB="$_dev_mnt"
                break 2
            fi
        done
        sleep 1
    done

    # Destination resolution: Strict USB-Only Forensics (Zero NAND Flash Footprint)
    if [ -z "$_TARGET_USB" ]; then
        log_event "[FORENSICS] No USB storage mounted; skipping diagnostics export to preserve internal NAND flash."
        return 0
    fi

    mount -o remount,rw "$_TARGET_USB" 2>/dev/null || mount -o rw,remount "$_TARGET_USB" 2>/dev/null
    _DEST="$_TARGET_USB/_autox/crash_logs/$_CRASH_SUBDIR"
    mkdir -p "$_DEST" 2>/dev/null

    if [ ! -d "$_DEST" ]; then
        log_event "[FORENSICS ERROR] Unable to create USB destination: $_DEST"
        return 1
    fi

    # 2. RAPID TEXT-ONLY FORENSICS (Zero .bz2, zero .tar.gz, zero core dumps)
    # Execution time: <80ms total. Survives imminent reboot loops.
    
    # Mazda's native crash backtraces, fault signals & crashing process names:
    if [ -d /tmp/mnt/data_persist/log/error_logs ]; then
        mkdir -p "$_DEST/error_logs" 2>/dev/null
        cp -f /tmp/mnt/data_persist/log/error_logs/*.txt "$_DEST/error_logs/" 2>/dev/null
    fi

    # Kernel ring buffer (kernel panics, OOM killer, driver errors):
    dmesg > "$_DEST/dmesg.txt" 2>&1

    # Native Mazda unexpected shutdown indicator (copied, NEVER deleted):
    [ -f /data/unexpectedshutdownflag ] && cp -f /data/unexpectedshutdownflag "$_DEST/" 2>/dev/null

    # System & Memory state snapshots:
    ps > "$_DEST/ps_snapshot.txt" 2>/dev/null
    cat /proc/meminfo > "$_DEST/meminfo.txt" 2>/dev/null
    cat /proc/cmdline > "$_DEST/cmdline.txt" 2>/dev/null

    # Recent HMI / Opera log (bounded to last 250 lines to prevent giant I/O):
    if [ -f /tmp/Log.txt_00.log ]; then
        tail -n 250 /tmp/Log.txt_00.log > "$_DEST/Log_recent.txt" 2>/dev/null
    fi

    # AutoX Strike Metadata:
    echo "CRASH_STRIKE=$_CRASH_NUM" > "$_DEST/crash_info.txt" 2>/dev/null
    echo "DUMP_TIME=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || uptime)" >> "$_DEST/crash_info.txt" 2>/dev/null
    echo "UPTIME=$(cat /proc/uptime 2>/dev/null)" >> "$_DEST/crash_info.txt" 2>/dev/null

    # Atomic flash sync (<10ms for text payload)
    sync
    log_event "[FORENSICS] Rapid export completed to $_DEST in <80ms."
    echo "OK: Rapid forensics exported to $_DEST"
}

do_watch() {
    mkdir -p "$RECOVERY_DIR" "$LOG_DIR" 2>/dev/null

    # Guard against multiple executions in the same boot session
    if [ -f "/tmp/autox_recovery_boot_checked" ]; then
        log_event "[RECOVERY] Already evaluated for current boot session. Exiting."
        return 0
    fi
    touch "/tmp/autox_recovery_boot_checked" 2>/dev/null

    CURRENT_CRASHES=0
    if [ -f "$CRASH_COUNTER_FILE" ]; then
        CURRENT_CRASHES=$(cat "$CRASH_COUNTER_FILE" 2>/dev/null || echo 0)
        case "$CURRENT_CRASHES" in
            ''|*[!0-9]*) CURRENT_CRASHES=0 ;;
        esac
    fi

    # 1. Intentional Clean Reboot Handshake: Check if reboot was requested cleanly by AutoX
    if [ -f "$RECOVERY_DIR/clean_reboot" ]; then
        rm -f "$RECOVERY_DIR/clean_reboot" 2>/dev/null
        CURRENT_CRASHES=0
        echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null
        sync
        log_event "[RECOVERY] Intentional clean restart verified (installer/soft-reboot). Crash counter: 0."
        release_lock
        return 0
    fi

    # 2. Inspection & Consumption of Mazda's Native Sentinel
    if [ -f /data/unexpectedshutdownflag ]; then
        CURRENT_CRASHES=$((CURRENT_CRASHES + 1))
        echo "$CURRENT_CRASHES" > "$CRASH_COUNTER_FILE" 2>/dev/null
        sync
        log_event "[RECOVERY] Mazda unexpected shutdown detected! Strike $CURRENT_CRASHES of $MAX_CRASHES."

        # Acknowledge and consume flag so this single shutdown event is not perpetually re-evaluated
        rm -f /data/unexpectedshutdownflag 2>/dev/null

        # Strike 1 & 2: Rapid text forensics to USB in background (non-blocking, <80ms)
        if [ "$CURRENT_CRASHES" -lt "$MAX_CRASHES" ]; then
            export_car_logs "$CURRENT_CRASHES" &
        fi
    else
        # Clean normal boot: Reset crash counter immediately
        CURRENT_CRASHES=0
        echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null
        sync
        log_event "[RECOVERY] Clean boot confirmed by Mazda kernel. Crash counter: 0."
        release_lock
        return 0
    fi

    # For Strike 1 & 2: Arm background stability watcher to reset strikes once system proves healthy & interactive
    if [ "$CURRENT_CRASHES" -lt "$MAX_CRASHES" ]; then
        (
            for _i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
                if dbus-send --session --dest=org.freedesktop.DBus --type=method_call --print-reply /org/freedesktop/DBus org.freedesktop.DBus.ListNames 2>/dev/null | grep -q "com.jci.gui"; then
                    break
                fi
                sleep 1
            done
            sleep 60
            echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null
            sync
            log_event "[RECOVERY] System verified stable and interactive (GUI loaded). Crash counter reset to 0."
        ) &
    fi

    # Strike 3: Loop-Prevention Safe-Mode Tripwire
    if [ "$CURRENT_CRASHES" -ge "$MAX_CRASHES" ]; then
        log_event "[CRITICAL] 3 Consecutive Crashes Detected! Executing Safe-Mode Rollback."

        # STEP A: Remount root RW (<5ms)
        cmu_remount_rw

        # STEP B: Surgically strip systemApp.js AutoX hooks via SED (preserves other installed plugins/mods)
        _SYS_JS="/jci/gui/apps/system/js/systemApp.js"
        if [ -s "$_SYS_JS" ]; then
            sed -i '/\/\* === AUTOX_SYSTEMAPP_HOOK_START === \*\//,/\/\* === AUTOX_SYSTEMAPP_HOOK_END === \*\//d' "$_SYS_JS" 2>/dev/null
            sed -i '/\/\/ >>> AUTOX_CALLBACK_START/,/\/\/ <<< AUTOX_CALLBACK_END/d' "$_SYS_JS" 2>/dev/null
            sed -i '/\/\/ === AUTOX_TEARDOWN_START ===/,/\/\/ === AUTOX_TEARDOWN_END ===/d' "$_SYS_JS" 2>/dev/null
            sed -i '/\/\* AutoX System Tools - Presto-Compliant Clean-Room Hook/,/\}\)\(\)\;/d' "$_SYS_JS" 2>/dev/null
            log_event "[RECOVERY] Surgically stripped AutoX hooks from systemApp.js via SED (other mods intact)."
        elif [ -f "${_SYS_JS}.autox_orig" ]; then
            cp -p "${_SYS_JS}.autox_orig" "$_SYS_JS" 2>/dev/null
            log_event "[RECOVERY] Fallback: Restored stock systemApp.js from .autox_orig backup."
        fi

        # STEP C: Remove Stage 1 hook
        if [ -f "$STAGE_1" ]; then
            sed -i '/# === AUTOX RECOVERY BOOT HOOK START ===/,/# === AUTOX RECOVERY BOOT HOOK END ===/d' "$STAGE_1" 2>/dev/null
            sed -i '/# === AUTOX/,$d' "$STAGE_1" 2>/dev/null
            sed -i '/autox_recovery/d; /daemon_dispatcher/d; /server\.lua/d' "$STAGE_1" 2>/dev/null
            chmod 755 "$STAGE_1" 2>/dev/null
        fi

        # STEP D: Disable all modular plugin flags
        rm -f "$AUTOX_DIR"/*_enabled "$DATA_DIR"/*_enabled "$PLUGINS_DIR"/*_enabled 2>/dev/null
        find "$AUTOX_DIR" -name "*_enabled" -exec rm -f {} \; 2>/dev/null

        # STEP E: Reset crash counter
        echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null

        # STEP F: Remount root RO and sync
        cmu_remount_ro
        sync
        log_event "[RECOVERY COMPLETE] System restored to clean stock state in <80ms."

        # STEP G: Rapid forensics to USB for Strike 3
        export_car_logs 3 &

        # STEP H: Display OEM alert on screen once Opera GUI is up
        (
            for _i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
                if dbus-send --session --dest=org.freedesktop.DBus --type=method_call --print-reply /org/freedesktop/DBus org.freedesktop.DBus.ListNames 2>/dev/null | grep -q "com.jci.gui"; then
                    break
                fi
                sleep 1
            done
            sleep 2
            if [ -x "/jci/tools/jci-dialog" ]; then
                /jci/tools/jci-dialog --info \
                    --title="AutoX Safe Mode Recovery" \
                    --text="AutoX detected 3 consecutive boot failures.\nSystem hooks were removed to restore factory operation.\n\nCrash diagnostics were saved to USB (_autox/crash_logs/crash3)." 2>/dev/null &
            fi
        ) &
    fi

    release_lock
}

install_stage1_hook() {
    cmu_remount_rw
    if ! grep -q "autox_recovery" "$STAGE_1" 2>/dev/null && ! grep -q "AUTOX RECOVERY" "$STAGE_1" 2>/dev/null; then
        cat << 'EOF' >> "$STAGE_1"

# === AUTOX RECOVERY BOOT HOOK START ===
AUTOX_DIR="/tmp/mnt/data_persist/autox"
(
    # Wait for /tmp/mnt/data_persist to be fully mounted in atomic kernel tables (up to 30 seconds)
    for _i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
        if grep -q "/tmp/mnt/data_persist" /proc/mounts; then
            sleep 1
            break
        fi
        sleep 1
    done

    REC_SCRIPT="$AUTOX_DIR/plugins/autox_recovery.sh"
    CRASH_FILE="$AUTOX_DIR/recovery/crash_count"
    if [ -f "$REC_SCRIPT" ]; then
        /bin/sh "$REC_SCRIPT" watch &
    fi
) &
# === AUTOX RECOVERY BOOT HOOK END ===
EOF
        chmod 755 "$STAGE_1" 2>/dev/null
        log_event "[HOOK] Configured recovery boot hook inside $STAGE_1"
    else
        log_event "[HOOK] Recovery hook already present in $STAGE_1. Skipping duplicate injection."
    fi
}

remove_stage1_hook() {
    cmu_remount_rw
    if [ -f "$STAGE_1" ]; then
        sed -i '/# === AUTOX RECOVERY/,/# === AUTOX RECOVERY.*END ===/d' "$STAGE_1" 2>/dev/null
        sed -i '/autox_recovery/d' "$STAGE_1" 2>/dev/null
        log_event "[UNHOOK] Cleaned recovery hooks from $STAGE_1"
    fi
}

do_install() {
    acquire_lock
    log_event "[START] $PLUGIN_NAME Installation Sequence Init"
    cmu_remount_rw
    mkdir -p "$RECOVERY_DIR" "$PLUGINS_DIR" "$LOG_DIR" 2>/dev/null
    echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null
    chmod 755 "$0" 2>/dev/null
    install_stage1_hook
    cmu_remount_ro
    release_lock
}

do_uninstall() {
    export IS_UNINSTALLING=1
    log_event "[START] $PLUGIN_NAME Removal Sequence Init"
    if [ -f "$PID_FILE" ]; then
        _REC_PID=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$_REC_PID" ] && kill -0 "$_REC_PID" 2>/dev/null; then
            kill -TERM "$_REC_PID" 2>/dev/null
        fi
        rm -f "$PID_FILE" 2>/dev/null
    fi
    remove_stage1_hook
    rm -f "$CRASH_COUNTER_FILE" "$LOCK_FILE" 2>/dev/null
    cmu_remount_ro
    log_event "[COMPLETED] Safe uninstallation finished successfully."
}

do_reset_counter() {
    log_event "[RECOVERY] Resetting crash counter to 0 upon user request."
    mkdir -p "$RECOVERY_DIR" 2>/dev/null
    echo 0 > "$CRASH_COUNTER_FILE" 2>/dev/null
    sync
    echo "OK: Crash counter reset to 0"
}

do_dirty_reboot() {
    log_event "[TEST] Halting Mazda watchdog to trigger authentic hardware reset..."
    # Terminating Opera and Service Manager halts the watchdog keep-alive loop.
    # The hardware watchdog chip receives no pulses and trips a cold reset in ~3-5 seconds.
    killall -9 opera 2>/dev/null
    killall -9 sm 2>/dev/null
    echo "OK: Mazda watchdog halted. Board will hardware reset in ~3-5 seconds."
}

get_status() {
    CRASHES=0
    if [ -f "$CRASH_COUNTER_FILE" ]; then
        CRASHES=$(cat "$CRASH_COUNTER_FILE" 2>/dev/null || echo 0)
    fi

    if [ "$1" = "--json" ]; then
        echo "{\"plugin\":\"$PLUGIN_ID\",\"version\":\"$VERSION\",\"status\":\"ACTIVE\",\"crash_count\":$CRASHES,\"max_crashes\":$MAX_CRASHES}"
    else
        echo "AutoX Boot Recovery Service: ACTIVE (Crash count: $CRASHES/$MAX_CRASHES)"
    fi
}

case "$1" in
    watch|--watch)
        acquire_lock
        do_watch
        ;;
    install|--install|-i)
        do_install
        ;;
    uninstall|--uninstall|-u)
        do_uninstall
        ;;
    toggle|reset|reset_counter|reset-counter)
        do_reset_counter
        ;;
    dirty-reboot|dirty_reboot|--dirty-reboot|crash-reboot)
        do_dirty_reboot
        ;;
    disable|--disable)
        if [ -f "$PID_FILE" ]; then
            _REC_PID=$(cat "$PID_FILE" 2>/dev/null)
            [ -n "$_REC_PID" ] && kill -TERM "$_REC_PID" 2>/dev/null
            rm -f "$PID_FILE" 2>/dev/null
        fi
        pkill -9 -f "autox_recovery" 2>/dev/null || true
        release_lock
        ;;
    shutdown|--shutdown|clean_shutdown)
        mark_clean_shutdown
        ;;
    status|--status|-s)
        get_status
        ;;
    meta|--meta|info|--info)
        echo "{\"id\":\"$PLUGIN_ID\",\"title\":\"$PLUGIN_TITLE\",\"subtitle\":\"$PLUGIN_SUBTITLE\",\"category\":\"$PLUGIN_CATEGORY\",\"version\":\"$VERSION\",\"status\":\"ACTIVE\",\"show_in_gui\":false}"
        ;;
    json|--json)
        get_status --json
        ;;
    dumplogs|dump_logs|export_logs|crash_logs|crashlogs|car_logs|carlogs|export-logs)
        export_car_logs
        ;;
    help|--help|-h)
        echo "$PLUGIN_NAME v$VERSION"
        echo "Usage: autox_recovery.sh [watch|install|uninstall|dirty-reboot|reset|dumplogs|status|json]"
        ;;
    *)
        acquire_lock
        do_watch
        ;;
esac
exit 0

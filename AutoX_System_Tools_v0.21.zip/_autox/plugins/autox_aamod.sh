#!/bin/sh
# ==============================================================================
# AutoX Plugin: OEM Android Auto Mod (autox_AAMod)
# Original Author: Vitaliy Kurokhtin (https://github.com/VitaliyKurokhtin/oem-aa-mod)
# Packaged For AutoX: AutoX Ecosystem Architecture
# Version: 0.21
# Target Platform: Mazda Connect CMU FW 74.00.324 (also compatible with v70+)
# Architecture: ARMv7-A / i.MX6 Cortex-A9
# Capabilities: In-Motion Touchscreen Passthrough, GAL 1.6 HUD Navigation &
#               Lane Guidance, Mute/Pause Media Bridge, Dual-Nav HUD Merge.
# Dedicated Resource Folder: /tmp/mnt/data_persist/autox/plugins/oem-aa-mod/
# Dual-Vault Backup: /tmp/mnt/data_persist/autox/org_files & USB_DRIVE/autox/org_files
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# Environment & Globals
PLUGIN_NAME="OEM Android Auto Mod"
PLUGIN_ID="aamod"
PLUGIN_TITLE="AAmod (Android Auto)"
PLUGIN_SUBTITLE="HUD nav & touch in motion"
PLUGIN_CATEGORY="tweak"
PLUGIN_ORDER=30
SHOW_IN_GUI="true"
AUTHOR="Vitaliy Kurokhtin (Packaged for AutoX)"
VERSION="0.21"

# ==============================================================================
# AutoX Plugin Architecture Standard: Zero-Dialog Headless Execution
# ------------------------------------------------------------------------------
# 1. Non-Interactive / Zero-Dialog Contract:
#    Plugins must NEVER trigger modal dialogs (jci-dialog, ask_question, show_info)
#    during installation, bootstrap, status queries, or CLI dispatch.
#    All configuration, enabling, disabling, and monitoring is handled exclusively
#    via the AutoX Web GUI (http://<cmu_ip>:8080) and headless REST endpoints.
#
# 2. INSTALL_STATE Policy:
#    All plugins in the plugins directory get staged into /tmp/mnt/data_persist/autox/plugins/.
#    INSTALL_STATE determines initial posture:
#    - "disabled" (DEFAULT / DORMANT): Staged safely; vehicle OS and /jci/sm/sm.conf
#      remain 100% untouched until toggled by user in Web GUI.
#    - "enabled" (AUTO-DEPLOY): Injects active hooks on initial setup.
# ==============================================================================
INSTALL_STATE="disabled"

# Persistent data directory strictly set to physical NAND mount
AUTOX_DIR="/tmp/mnt/data_persist/autox"

PLUGINS_DIR="$AUTOX_DIR/plugins"
LOG_DIR="$AUTOX_DIR/logs"
NAND_ORG_DIR="$AUTOX_DIR/org_files"
DATA_DIR="$AUTOX_DIR/data"
AAMOD_DIR="$PLUGINS_DIR/oem-aa-mod"

PLUGIN_TARGET="$PLUGINS_DIR/autox_aamod.sh"
LOCK_FILE="/tmp/autox_aamod.lock"
AAMOD_FLAG="$PLUGINS_DIR/enabled/aamod_enabled"

SM_CONF="/jci/sm/sm.conf"
AAP_ATTR_XML="/etc/aap_system_attributes.xml"
AAP_ATTR_UCP_XML="/etc/aap_system_attributes_UCP.xml"

SCRIPT_PATH="$(readlink -f "$0" 2>/dev/null || echo "$0")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"

# Detect active AutoX USB drive across all candidate mount points
USB_ROOT=""
for _cand in "$AUTOX_USB_MOUNT" "$USB_MOUNT_POINT" "/tmp/mnt/sda1" "/tmp/mnt/sdb1"; do
    if [ -n "$_cand" ] && [ -d "$_cand/_autox" ]; then
        USB_ROOT="$_cand"
        break
    fi
done

USB_ORG_DIR="$USB_ROOT/_autox/org_files"
USB_LOG_DIR="$USB_ROOT/_autox/logs"

# Locate oem-aa-mod resource folder across potential locations
if [ -d "$SCRIPT_DIR/oem-aa-mod" ]; then
    USB_AAMOD_DIR="$SCRIPT_DIR/oem-aa-mod"
elif [ -n "$USB_ROOT" ] && [ -d "$USB_ROOT/_autox/plugins/oem-aa-mod" ]; then
    USB_AAMOD_DIR="$USB_ROOT/_autox/plugins/oem-aa-mod"
elif [ -n "$USB_ROOT" ] && [ -d "$USB_ROOT/plugins/oem-aa-mod" ]; then
    USB_AAMOD_DIR="$USB_ROOT/plugins/oem-aa-mod"
elif [ -d "$PLUGINS_DIR/oem-aa-mod" ]; then
    USB_AAMOD_DIR="$PLUGINS_DIR/oem-aa-mod"
else
    USB_AAMOD_DIR=""
fi

# Standard NAND Flush & Remount Helpers
cmu_remount_rw() {
    mount -o remount,rw / 2>/dev/null
}

cmu_remount_ro() {
    sync
    mount -o remount,ro / 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 1: Process Concurrency Lock Guard & Exit Trap
# --------------------------------------------------------------------------
acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            echo "[WARN] Another process ($PID) is currently running. Exiting."
            exit 0
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    if [ "$IS_UNINSTALLING" = "1" ] || [ "$AUTOX_UNINSTALLING" = "1" ]; then
        trap 'release_lock' EXIT INT TERM HUP
    else
        trap 'mazda_watchdog_enable; cmu_remount_ro; release_lock' EXIT INT TERM HUP
    fi
}

release_lock() {
    rm -f "$LOCK_FILE" 2>/dev/null
}

# --------------------------------------------------------------------------
# STEP 2: Hardware Watchdog Protection Helpers
# --------------------------------------------------------------------------
mazda_watchdog_disable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 1 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 1 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

mazda_watchdog_enable() {
    if [ -f "/sys/class/gpio/Watchdog Disable/value" ]; then
        echo 0 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null
    elif [ -f "/sys/class/gpio/Watchdog\ Disable/value" ]; then
        echo 0 > /sys/class/gpio/Watchdog\ Disable/value 2>/dev/null
    fi
}

# --------------------------------------------------------------------------
# STEP 3: Dual-Vault Logging Subsystem with 50KB Size-Capping
# --------------------------------------------------------------------------
log_event() {
    _TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "BOOT")
    _MSG="[$_TIMESTAMP] $1"
    echo "$_MSG"

    # 1. Primary Vault: Physical NAND (/tmp/mnt/data_persist/autox/logs/<plugin_id>_service.log)
    if [ -d "$LOG_DIR" ] && touch "$LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$LOG_DIR/.wprobe" 2>/dev/null
        _NAND_LOG="$LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_NAND_LOG" 2>/dev/null
        # 50KB Size-Capping Rotation Guard (prevents NAND exhaustion)
        if [ -f "$_NAND_LOG" ] && [ "$(wc -c < "$_NAND_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_NAND_LOG" > "$_NAND_LOG.tmp" 2>/dev/null && mv -f "$_NAND_LOG.tmp" "$_NAND_LOG" 2>/dev/null
        fi
    fi

    # 2. Secondary Vault: USB Mirror (${USB_ROOT}/_autox/logs/<plugin_id>_service.log)
    if [ -n "$USB_ROOT" ] && [ -d "$USB_LOG_DIR" ] && touch "$USB_LOG_DIR/.wprobe" 2>/dev/null; then
        rm -f "$USB_LOG_DIR/.wprobe" 2>/dev/null
        _USB_LOG="$USB_LOG_DIR/${PLUGIN_ID}_service.log"
        echo "$_MSG" >> "$_USB_LOG" 2>/dev/null
        if [ -f "$_USB_LOG" ] && [ "$(wc -c < "$_USB_LOG" 2>/dev/null || echo 0)" -gt 51200 ]; then
            tail -n 50 "$_USB_LOG" > "$_USB_LOG.tmp" 2>/dev/null && mv -f "$_USB_LOG.tmp" "$_USB_LOG" 2>/dev/null
        fi
    fi
}

# ==============================================================================
# FILE & HOOK OPERATION HELPERS
# ==============================================================================
backup_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_SRC" ] && [ ! -f "$_ORG" ]; then
        cp -p "$_SRC" "$_ORG" 2>/dev/null || cp "$_SRC" "$_ORG"
        log_event "[BACKUP] Backing up original file: $_SRC -> $_ORG"
    fi
}

restore_file() {
    _SRC="$1"
    _ORG="${_SRC}.org"
    if [ -f "$_ORG" ]; then
        mv -f "$_ORG" "$_SRC" 2>/dev/null || cp -f "$_ORG" "$_SRC"
        log_event "[RESTORE] Restoring original file: $_ORG -> $_SRC"
    fi
}

deploy_file() {
    _SRC="$1"
    _DEST="$2"
    _DIR=$(dirname "$_DEST")
    [ ! -d "$_DIR" ] && mkdir -p "$_DIR"
    cp -f "$_SRC" "$_DEST"
    log_event "[FILE] Adding new file: $_DEST"
}

replace_file() {
    _SRC="$1"
    _DEST="$2"
    backup_file "$_DEST"
    cp -f "$_SRC" "$_DEST"
    log_event "[REPLACE] Replacing existing file: $_DEST"
}

remove_file() {
    _TARGET="$1"
    if [ -f "$_TARGET" ]; then
        rm -f "$_TARGET"
        log_event "[REMOVE] Removing file: $_TARGET"
    fi
}

# --------------------------------------------------------------------------
# STEP 4: Dual-Vault Backup Routine (Strict Zero-Unbacked Modification)
# --------------------------------------------------------------------------
backup_file_if_needed() {
    TARGET_FILE="$1"
    [ ! -f "$TARGET_FILE" ] && return

    FILE_REL=$(echo "$TARGET_FILE" | sed 's/^\///')
    NAND_BAK="$NAND_ORG_DIR/$FILE_REL.org"
    USB_BAK="$USB_ORG_DIR/$FILE_REL.org"
    SIDECAR_BAK="$TARGET_FILE.org"

    # 1. NAND Vault Backup (/tmp/mnt/data_persist/autox/org_files/etc/aap_system_attributes.xml.org)
    if [ ! -f "$NAND_BAK" ]; then
        mkdir -p "$(dirname "$NAND_BAK")" 2>/dev/null
        cp -f "$TARGET_FILE" "$NAND_BAK" 2>/dev/null
        log_event "[BACKUP] Backing up original file: $TARGET_FILE -> $NAND_BAK"
    fi

    # 2. USB Vault Backup (<USB_ROOT>/autox/org_files/etc/aap_system_attributes.xml.org)
    if [ -n "$USB_ROOT" ] && [ -d "$USB_ORG_DIR" ]; then
        if [ ! -f "$USB_BAK" ]; then
            mkdir -p "$(dirname "$USB_BAK")" 2>/dev/null
            cp -f "$TARGET_FILE" "$USB_BAK" 2>/dev/null
            log_event "[BACKUP] Backing up original file to USB: $TARGET_FILE -> $USB_BAK"
        fi
    fi

    # 3. Sidecar .org Backup (/etc/aap_system_attributes.xml.org)
    if [ ! -f "$SIDECAR_BAK" ]; then
        cp -f "$TARGET_FILE" "$SIDECAR_BAK" 2>/dev/null
        log_event "[BACKUP] Backing up sidecar original file: $TARGET_FILE -> $SIDECAR_BAK"
    fi
}

# Restore file from dual-vault backup
restore_file_from_backup() {
    TARGET_FILE="$1"
    FILE_REL=$(echo "$TARGET_FILE" | sed 's/^\///')
    NAND_BAK="$NAND_ORG_DIR/$FILE_REL.org"
    USB_BAK="$USB_ORG_DIR/$FILE_REL.org"
    SIDECAR_BAK="$TARGET_FILE.org"

    if [ -f "$NAND_BAK" ]; then
        cp -f "$NAND_BAK" "$TARGET_FILE" 2>/dev/null
        log_event "[RESTORE] Restored $TARGET_FILE from NAND vault ($NAND_BAK)"
        return 0
    elif [ -f "$SIDECAR_BAK" ]; then
        cp -f "$SIDECAR_BAK" "$TARGET_FILE" 2>/dev/null
        log_event "[RESTORE] Restored $TARGET_FILE from sidecar backup ($SIDECAR_BAK)"
        return 0
    elif [ -n "$USB_ROOT" ] && [ -f "$USB_BAK" ]; then
        cp -f "$USB_BAK" "$TARGET_FILE" 2>/dev/null
        log_event "[RESTORE] Restored $TARGET_FILE from USB vault ($USB_BAK)"
        return 0
    fi
    log_event "[WARN] No backup found for $TARGET_FILE to restore."
    return 1
}

# --------------------------------------------------------------------------
# STEP 6: Configuration & Settings Reader
# --------------------------------------------------------------------------
load_aamod_config() {
    CONF_FILE="$AAMOD_DIR/libpatch.conf"
    [ ! -f "$CONF_FILE" ] && [ -n "$USB_AAMOD_DIR" ] && [ -f "$USB_AAMOD_DIR/libpatch.conf" ] && CONF_FILE="$USB_AAMOD_DIR/libpatch.conf"
    [ ! -f "$CONF_FILE" ] && [ -f "$DATA_DIR/libpatch.conf" ] && CONF_FILE="$DATA_DIR/libpatch.conf"
    
    # Defaults matching oem-aa-mod
    CONF_TOUCH="true"
    CONF_HUD="true"
    CONF_HUD_TRANSPORT="svcnavi"
    CONF_HUD_FOLD_LATIN="true"
    CONF_USE_PROTOCOL_V1_6="true"
    CONF_FORCE_STREET_NAME="false"
    CONF_MUTE_PAUSES_PHONE="true"
    CONF_BLOCK_HEADUNIT_MEDIA_PLAY="true"

    if [ -f "$CONF_FILE" ]; then
        # Parse key = value safely
        while IFS='=' read -r key val || [ -n "$key" ]; do
            # Strip comments and whitespace
            key=$(echo "$key" | sed 's/#.*//' | tr -d ' \t\r\n' | tr '[:upper:]' '[:lower:]')
            val=$(echo "$val" | sed 's/#.*//' | tr -d ' \t\r\n')
            [ -z "$key" ] && continue

            case "$key" in
                touch) CONF_TOUCH="$val" ;;
                hud) CONF_HUD="$val" ;;
                hud_transport) CONF_HUD_TRANSPORT="$val" ;;
                hud_fold_latin) CONF_HUD_FOLD_LATIN="$val" ;;
                use_protocol_v1_6) CONF_USE_PROTOCOL_V1_6="$val" ;;
                force_street_name) CONF_FORCE_STREET_NAME="$val" ;;
                mute_pauses_phone) CONF_MUTE_PAUSES_PHONE="$val" ;;
                block_headunit_media_play) CONF_BLOCK_HEADUNIT_MEDIA_PLAY="$val" ;;
            esac
        done < "$CONF_FILE"
    fi
}

# --------------------------------------------------------------------------
# STEP 7: Status Query Routine (RFC 8259 JSON & Raw API)
# --------------------------------------------------------------------------
is_aamod_active() {
    if [ -f "$AAMOD_FLAG" ]; then
        return 0
    fi
    # Also check if sm.conf has active LD_PRELOAD for libpatch
    if [ -f "$SM_CONF" ] && grep -q "libpatch-" "$SM_CONF" 2>/dev/null; then
        return 0
    fi
    return 1
}

get_aamod_status() {
    load_aamod_config

    SHIM_AAPA_EXISTS="false"
    SHIM_AAP_EXISTS="false"
    SHIM_NAVI_EXISTS="false"
    [ -f "$AAMOD_DIR/libpatch-blmjciaapa.so" ] && SHIM_AAPA_EXISTS="true"
    [ -f "$AAMOD_DIR/libpatch-aap_service.so" ] && SHIM_AAP_EXISTS="true"
    [ -f "$AAMOD_DIR/libpatch-svcjcinavi.so" ] && SHIM_NAVI_EXISTS="true"

    SM_PATCHED="false"
    if [ -f "$SM_CONF" ] && grep -q "libpatch-blmjciaapa.so" "$SM_CONF" 2>/dev/null; then
        SM_PATCHED="true"
    fi

    if is_aamod_active && [ "$SM_PATCHED" = "true" ]; then
        STATUS="ENABLED"
    elif is_aamod_active || [ "$SM_PATCHED" = "true" ]; then
        STATUS="CONFIGURED"
    else
        STATUS="DISABLED"
    fi

    if [ "$1" = "--raw" ] || [ "$1" = "status" ]; then
        echo "$STATUS"
    elif [ "$1" = "--json" ] || [ "$1" = "json" ]; then
        cat << EOF
{
  "plugin": "autox_AAMod",
  "name": "$PLUGIN_NAME",
  "author": "$AUTHOR",
  "version": "$VERSION",
  "status": "$STATUS",
  "enabled": $([ "$STATUS" = "ENABLED" ] && echo "true" || echo "false"),
  "directory": "$AAMOD_DIR",
  "sm_conf_patched": $SM_PATCHED,
  "shims": {
    "blmjciaapa": $SHIM_AAPA_EXISTS,
    "aap_service": $SHIM_AAP_EXISTS,
    "svcjcinavi": $SHIM_NAVI_EXISTS
  },
  "config": {
    "touch": $CONF_TOUCH,
    "hud": $CONF_HUD,
    "hud_transport": "$CONF_HUD_TRANSPORT",
    "use_protocol_v1_6": $CONF_USE_PROTOCOL_V1_6,
    "force_street_name": $CONF_FORCE_STREET_NAME,
    "hud_fold_latin": $CONF_HUD_FOLD_LATIN,
    "mute_pauses_phone": $CONF_MUTE_PAUSES_PHONE,
    "block_headunit_media_play": $CONF_BLOCK_HEADUNIT_MEDIA_PLAY
  }
}
EOF
    else
        echo "[$PLUGIN_NAME] Status: $STATUS (Touch: $CONF_TOUCH | HUD 1.6: $CONF_USE_PROTOCOL_V1_6 | Transport: $CONF_HUD_TRANSPORT)"
    fi
}

# --------------------------------------------------------------------------
# STEP 8: Surgical Injection & Removal in /jci/sm/sm.conf
# --------------------------------------------------------------------------
inject_sm_conf() {
    if [ ! -f "$SM_CONF" ]; then
        log_event "[ERROR] $SM_CONF does not exist. Cannot configure LD_PRELOAD."
        return 1
    fi

    backup_file_if_needed "$SM_CONF"

    # Remove any existing libpatch preload lines first (idempotent clean)
    sed -i '/libpatch-blmjciaapa\.so/d' "$SM_CONF" 2>/dev/null
    sed -i '/libpatch-aap_service\.so/d' "$SM_CONF" 2>/dev/null
    sed -i '/libpatch-svcjcinavi\.so/d' "$SM_CONF" 2>/dev/null

    # 1. Inject libpatch-blmjciaapa.so into jciAAPA service
    # Match <service type="process" name="jciAAPA" ...> and inject environ_var before </service>
    awk -v shim="        <environ_var env_name=\"LD_PRELOAD\" env_value=\"$AAMOD_DIR/libpatch-blmjciaapa.so\"/>" '
    BEGIN { in_service = 0 }
    /<service [^>]*name="jciAAPA"/ { in_service = 1; print; next }
    in_service && /<\/service>/ { print shim; in_service = 0; print; next }
    { print }
    ' "$SM_CONF" > "$SM_CONF.tmp" && mv -f "$SM_CONF.tmp" "$SM_CONF"
    log_event "[HOOK] Injected libpatch-blmjciaapa.so into jciAAPA in $SM_CONF"

    # 2. Inject libpatch-aap_service.so into aap_service service (if GAL 1.6 enabled)
    if [ "$CONF_USE_PROTOCOL_V1_6" = "true" ] || [ -f "$AAMOD_DIR/libpatch-aap_service.so" ]; then
        awk -v shim="        <environ_var env_name=\"LD_PRELOAD\" env_value=\"$AAMOD_DIR/libpatch-aap_service.so\"/>" '
        BEGIN { in_service = 0 }
        /<service [^>]*name="aap_service"/ { in_service = 1; print; next }
        in_service && /<\/service>/ { print shim; in_service = 0; print; next }
        { print }
        ' "$SM_CONF" > "$SM_CONF.tmp" && mv -f "$SM_CONF.tmp" "$SM_CONF"
        log_event "[HOOK] Injected libpatch-aap_service.so into aap_service in $SM_CONF"
    fi

    # 3. Inject libpatch-svcjcinavi.so into jcinavi service (if shim present)
    if [ -f "$AAMOD_DIR/libpatch-svcjcinavi.so" ]; then
        awk -v shim="        <environ_var env_name=\"LD_PRELOAD\" env_value=\"$AAMOD_DIR/libpatch-svcjcinavi.so\"/>" '
        BEGIN { in_service = 0 }
        /<service [^>]*name="jcinavi"/ { in_service = 1; print; next }
        in_service && /<\/service>/ { print shim; in_service = 0; print; next }
        { print }
        ' "$SM_CONF" > "$SM_CONF.tmp" && mv -f "$SM_CONF.tmp" "$SM_CONF"
        log_event "[HOOK] Injected libpatch-svcjcinavi.so into jcinavi in $SM_CONF"
    fi

    chmod 644 "$SM_CONF" 2>/dev/null
}

remove_sm_conf_patches() {
    if [ -f "$SM_CONF" ]; then
        sed -i '/libpatch-blmjciaapa\.so/d' "$SM_CONF" 2>/dev/null
        sed -i '/libpatch-aap_service\.so/d' "$SM_CONF" 2>/dev/null
        sed -i '/libpatch-svcjcinavi\.so/d' "$SM_CONF" 2>/dev/null
        chmod 644 "$SM_CONF" 2>/dev/null
        log_event "[HOOK] Removed all libpatch LD_PRELOAD lines from $SM_CONF"
    fi
}

# --------------------------------------------------------------------------
# STEP 9: Enable OEM Android Auto Mod
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Enabling Mod"
    log_event "=========================================================================="

    load_aamod_config

    log_event "[STEP 1/5] Remounting root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/5] Suppressing hardware watchdog for critical modification..."
    mazda_watchdog_disable

    log_event "[STEP 3/5] Backing up and updating AAP system attribute XML files..."
    mkdir -p "$NAND_ORG_DIR/etc" "$AAMOD_DIR" "$DATA_DIR" "$PLUGINS_DIR/enabled" 2>/dev/null

    # Backup original XMLs
    backup_file_if_needed "$AAP_ATTR_XML"
    backup_file_if_needed "$AAP_ATTR_UCP_XML"

    # Deploy patched XMLs from AAMOD_DIR or USB
    for _src_xml in "$AAMOD_DIR/aap_system_attributes.xml" \
                    "$USB_AAMOD_DIR/aap_system_attributes.xml"; do
        if [ -n "$_src_xml" ] && [ -f "$_src_xml" ]; then
            cp -f "$_src_xml" "$AAP_ATTR_XML" 2>/dev/null
            chmod 644 "$AAP_ATTR_XML" 2>/dev/null
            log_event "[REPLACE] Deployed patched $AAP_ATTR_XML from $_src_xml"
            break
        fi
    done

    for _src_ucp_xml in "$AAMOD_DIR/aap_system_attributes_UCP.xml" \
                        "$USB_AAMOD_DIR/aap_system_attributes_UCP.xml"; do
        if [ -n "$_src_ucp_xml" ] && [ -f "$_src_ucp_xml" ]; then
            cp -f "$_src_ucp_xml" "$AAP_ATTR_UCP_XML" 2>/dev/null
            chmod 644 "$AAP_ATTR_UCP_XML" 2>/dev/null
            log_event "[REPLACE] Deployed patched $AAP_ATTR_UCP_XML from $_src_ucp_xml"
            break
        fi
    done

    log_event "[STEP 4/5] Injecting LD_PRELOAD shims into $SM_CONF..."
    inject_sm_conf

    # Create enabled flags
    touch "$AAMOD_FLAG" 2>/dev/null

    log_event "[STEP 5/5] Flushing filesystem buffers (Dual-Sync), re-enabling watchdog, and remounting read-only..."
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock

    # LD_PRELOAD shims require a clean system reboot to initialize cleanly.
    # We deliberately bypass live 'smctl -r -n jciAAPA' here to prevent runtime SIGSEGV core dumps.
    # The user is immediately presented with the clean soft reboot modal in the Web GUI.
    log_event "[SERVICE] Live daemon restart bypassed. Clean CMU soft reboot required to apply shims."

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION successfully enabled."
    log_event "[REBOOT] CMU reboot required for libpatch LD_PRELOAD shims to take effect."
    log_event "=========================================================================="
    echo "OEM Android Auto Mod: ENABLED (CMU reboot required)"
    return 0
}

# --------------------------------------------------------------------------
# STEP 10: Disable OEM Android Auto Mod (Restore Factory Stock)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Disabling Mod (Restoring Factory Stock)"
    log_event "=========================================================================="

    log_event "[STEP 1/4] Remounting root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/4] Suppressing hardware watchdog during restoration..."
    mazda_watchdog_disable

    log_event "[STEP 3/4] Reverting AAP system attributes from backups and removing LD_PRELOAD..."
    restore_file_from_backup "$AAP_ATTR_XML"
    restore_file_from_backup "$AAP_ATTR_UCP_XML"
    remove_sm_conf_patches

    # Remove state flags
    rm -f "$AAMOD_FLAG" 2>/dev/null

    log_event "[STEP 4/4] Flushing filesystem buffers and releasing locks..."
    mazda_watchdog_enable
    
    if [ "$IS_UNINSTALLING" != "1" ] && [ "$AUTOX_UNINSTALLING" != "1" ]; then
        cmu_remount_ro
        release_lock

        # Clean stock binaries will restore on next boot without risking live service crashes
        log_event "[SERVICE] Live daemon restart bypassed. Factory stock will bind on next CMU boot."
    else
        release_lock
    fi

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION disabled. Factory stock restored."
    log_event "=========================================================================="
    echo "OEM Android Auto Mod: DISABLED (Factory stock restored)"
    return 0
}

# --------------------------------------------------------------------------
# STEP 11: Master Plugin Installer Routine
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Installation Initiated"
    log_event "=========================================================================="

    log_event "[STEP 1/4] Remounting CMU root filesystem read-write..."
    cmu_remount_rw

    log_event "[STEP 2/4] Creating dedicated directories in $AUTOX_DIR..."
    mkdir -p "$PLUGINS_DIR" "$PLUGINS_DIR/enabled" "$LOG_DIR" "$NAND_ORG_DIR" "$DATA_DIR" "$AAMOD_DIR" 2>/dev/null

    # Deploy plugin script to $PLUGINS_DIR
    if [ -f "$SCRIPT_PATH" ] && [ "$SCRIPT_PATH" != "$PLUGIN_TARGET" ]; then
        deploy_file "$SCRIPT_PATH" "$PLUGIN_TARGET"
        chmod 755 "$PLUGIN_TARGET" 2>/dev/null
        sed -i 's/\r$//' "$PLUGIN_TARGET" 2>/dev/null
    fi

    log_event "[STEP 3/4] Synchronizing oem-aa-mod files to $AAMOD_DIR..."
    # Copy files from USB oem-aa-mod folder if available
    if [ -n "$USB_AAMOD_DIR" ] && [ -d "$USB_AAMOD_DIR" ]; then
        cp -rf "$USB_AAMOD_DIR"/* "$AAMOD_DIR"/ 2>/dev/null
        log_event "[FILE] Copied files from $USB_AAMOD_DIR -> $AAMOD_DIR"
    fi

    # Ensure libpatch.conf exists in AAMOD_DIR (fallback generated config)
    if [ ! -f "$AAMOD_DIR/libpatch.conf" ]; then
        cat << 'EOF' > "$AAMOD_DIR/libpatch.conf"
# libpatch.conf — AutoX AAMod configuration
touch = true
hud = true
hud_transport = svcnavi
hud_fold_latin = true
mute_pauses_phone = true
block_headunit_media_play = true
use_protocol_v1_6 = true
EOF
        log_event "[FILE] Generated default libpatch.conf in $AAMOD_DIR"
    fi

    # Set permissions on library and configuration files
    chmod 755 "$AAMOD_DIR"/*.so 2>/dev/null
    chmod 644 "$AAMOD_DIR"/*.conf "$AAMOD_DIR"/*.xml "$AAMOD_DIR"/*.md 2>/dev/null

    log_event "[STEP 4/4] Finalizing plugin configuration..."
    release_lock

    # Evaluate INSTALL_STATE:
    # All plugins get installed with AutoX System Tools.
    # INSTALL_STATE controls whether the plugin auto-enables or stays dormant until user toggles.
    case "$(echo "$INSTALL_STATE" | tr '[:upper:]' '[:lower:]')" in
        "enabled"|"enable"|"1"|"true")
            log_event "[ACTIVATE] INSTALL_STATE is 'enabled'. Activating mod into vehicle OS..."
            do_enable
            ;;
        "disabled"|"disable"|"0"|"false"|*)
            log_event "[STAGED] $PLUGIN_NAME installed with AutoX System Tools."
            log_event "[DORMANT] INSTALL_STATE is 'disabled'. Car OS and factory Android Auto remain untouched."
            log_event "[READY] Mod button is ready on the left side of the Web GUI."
            rm -f "$AAMOD_FLAG" 2>/dev/null
            remove_sm_conf_patches 2>/dev/null
            echo "OEM Android Auto Mod: STAGED (Dormant - waiting for user toggle via GUI)"
            ;;
    esac
}

# --------------------------------------------------------------------------
# STEP 12: Standalone Plugin Uninstaller Routine
# --------------------------------------------------------------------------
do_uninstall() {
    export IS_UNINSTALLING=1
    log_event "=========================================================================="
    log_event "[START] $PLUGIN_NAME v$VERSION Uninstallation Initiated"
    log_event "=========================================================================="
    log_event "[STEP 1/3] Removing LD_PRELOAD hooks from Service Manager config..."

    # 1. Directly remove LD_PRELOAD hooks from Service Manager config
    remove_sm_conf_patches 2>/dev/null

    log_event "[STEP 2/3] Restoring AAP system attribute XML files..."
    # 2. Restore AAP system attribute XMLs if backups exist
    if [ -f "$NAND_ORG_DIR/etc/aap_system_attributes.xml.org" ]; then
        cp -f "$NAND_ORG_DIR/etc/aap_system_attributes.xml.org" "$AAP_ATTR_XML" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_XML from NAND vault."
    elif [ -n "$USB_ORG_DIR" ] && [ -f "$USB_ORG_DIR/etc/aap_system_attributes.xml.org" ]; then
        cp -f "$USB_ORG_DIR/etc/aap_system_attributes.xml.org" "$AAP_ATTR_XML" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_XML from USB vault."
    elif [ -f "$AAP_ATTR_XML.org" ]; then
        cp -f "$AAP_ATTR_XML.org" "$AAP_ATTR_XML" 2>/dev/null
        rm -f "$AAP_ATTR_XML.org" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_XML from sidecar backup."
    fi

    if [ -f "$NAND_ORG_DIR/etc/aap_system_attributes_UCP.xml.org" ]; then
        cp -f "$NAND_ORG_DIR/etc/aap_system_attributes_UCP.xml.org" "$AAP_ATTR_UCP_XML" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_UCP_XML from NAND vault."
    elif [ -n "$USB_ORG_DIR" ] && [ -f "$USB_ORG_DIR/etc/aap_system_attributes_UCP.xml.org" ]; then
        cp -f "$USB_ORG_DIR/etc/aap_system_attributes_UCP.xml.org" "$AAP_ATTR_UCP_XML" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_UCP_XML from USB vault."
    elif [ -f "$AAP_ATTR_UCP_XML.org" ]; then
        cp -f "$AAP_ATTR_UCP_XML.org" "$AAP_ATTR_UCP_XML" 2>/dev/null
        rm -f "$AAP_ATTR_UCP_XML.org" 2>/dev/null
        log_event "[RESTORE] Restored $AAP_ATTR_UCP_XML from sidecar backup."
    fi

    log_event "[STEP 3/3] Purging dedicated plugin directory and state flags..."
    # 3. Purge plugin directory, state flags, and temporary locks (matching Section 9.6)
    rm -rf "$AAMOD_DIR" 2>/dev/null
    rm -f "$AAMOD_FLAG" "$LOCK_FILE" 2>/dev/null
    release_lock

    log_event "=========================================================================="
    log_event "[COMPLETED] $PLUGIN_NAME v$VERSION uninstalled."
    log_event "=========================================================================="
    return 0
}

# --------------------------------------------------------------------------
# STEP 13: Interactive Toggle Handler
# --------------------------------------------------------------------------
do_toggle() {
    if is_aamod_active; then
        do_disable
    else
        do_enable
    fi
}

# --------------------------------------------------------------------------
# STEP 14: Diagnostics Suite (Doctor / Diag)
# --------------------------------------------------------------------------
run_aamod_diag() {
    echo "=========================================================================="
    echo "AutoX Plugin Diagnostic: $PLUGIN_NAME v$VERSION"
    echo "Author: $AUTHOR"
    echo "Target: Mazda Connect CMU FW 74.00.324 | Date: $(date 2>/dev/null || echo 'N/A')"
    echo "=========================================================================="

    echo ""
    echo "[1] Service Manager Configuration ($SM_CONF):"
    if [ -f "$SM_CONF" ]; then
        echo "  - File: EXISTS"
        echo "  - Preload entries found:"
        grep -n "libpatch" "$SM_CONF" 2>/dev/null | sed 's/^/    /' || echo "    (No libpatch entries active)"
    else
        echo "  - $SM_CONF: NOT FOUND"
    fi

    echo ""
    echo "[2] Dedicated Resource Directory ($AAMOD_DIR):"
    if [ -d "$AAMOD_DIR" ]; then
        echo "  - Directory: EXISTS"
        ls -la "$AAMOD_DIR" 2>/dev/null | sed 's/^/    /'
    else
        echo "  - Directory: NOT FOUND ($AAMOD_DIR)"
    fi

    echo ""
    echo "[3] System Attributes XML Status:"
    for xml in "$AAP_ATTR_XML" "$AAP_ATTR_UCP_XML"; do
        if [ -f "$xml" ]; then
            SIZE=$(wc -c < "$xml" 2>/dev/null || echo 0)
            TOUCH_INT=$(grep -A 2 "<touch_screen>" "$xml" 2>/dev/null | grep "<use_internally>" | sed 's/.*<use_internally>\(.*\)<\/use_internally>.*/\1/')
            echo "  - $xml: FOUND ($SIZE bytes, touch_screen.use_internally: ${TOUCH_INT:-unknown})"
        else
            echo "  - $xml: MISSING"
        fi
    done

    echo ""
    echo "[4] Dual-Vault Backups Status:"
    for org in "$NAND_ORG_DIR/etc/aap_system_attributes.xml.org" "$NAND_ORG_DIR/etc/aap_system_attributes_UCP.xml.org" "$NAND_ORG_DIR/jci/sm/sm.conf.org"; do
        if [ -f "$org" ]; then
            echo "  - NAND Vault: $org (EXISTS)"
        else
            echo "  - NAND Vault: $org (Not yet created)"
        fi
    done

    echo ""
    echo "[5] Target Daemon Processes:"
    for proc in jciAAPA aap_service svcjcinavi; do
        PID=$(pidof "$proc" 2>/dev/null || pgrep "$proc" 2>/dev/null)
        echo "  - $proc: ${PID:-Not Running (or handled by Service Manager launcher)}"
    done

    echo ""
    echo "=========================================================================="
    get_aamod_status
    echo "=========================================================================="
}

# --------------------------------------------------------------------------
# STEP 15: CLI Dispatcher & Argument Router (Zero-Dialog Headless Contract)
# --------------------------------------------------------------------------
case "$1" in
    install|--install|-i)
        log_event "Started do_install event"
        do_install "$2"
        ;;
    enable|--enable)
        log_event "Started do_enable event"
        do_enable "$2"
        ;;
    disable|--disable)
        log_event "Started do_disable event"
        do_disable "$2"
        ;;
    uninstall|--uninstall|-u)
        log_event "Started do_uninstall event"
        export IS_UNINSTALLING=1
        do_uninstall "$2"
        ;;
    toggle|--toggle)
        log_event "Started do_toggle event"
        do_toggle
        ;;
    status|--status|-s)
        get_aamod_status --raw
        ;;
    meta|--meta|info|--info)
        _STAT=$(get_aamod_status --raw 2>/dev/null)
        echo "{\"id\":\"$PLUGIN_ID\",\"title\":\"$PLUGIN_TITLE\",\"subtitle\":\"$PLUGIN_SUBTITLE\",\"category\":\"$PLUGIN_CATEGORY\",\"order\":$PLUGIN_ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":true}"
        ;;
    json|--json)
        get_aamod_status --json
        ;;
    diag|--diag|doctor)
        log_event "Started do_diag event"
        run_aamod_diag
        ;;
    shutdown|--shutdown)
        log_event "Shutdown signal received - exiting cleanly"
        exit 0
        ;;
    help|--help|-h|*)
        log_event "Started do_help/usage event"
        echo "$PLUGIN_NAME v$VERSION by $AUTHOR"
        echo "Usage: autox_aamod.sh [install|enable|disable|toggle|status|json|meta|diag|uninstall]"
        ;;
esac

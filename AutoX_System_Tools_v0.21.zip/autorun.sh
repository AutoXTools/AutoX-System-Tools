#!/bin/sh
# ==============================================================================
# AutoX USB Autorun & Collision-Free Daemon Orchestrator
# Target: Mazda Connect CMU (FW v55-v74 / Linux ARM i.MX6)
# ==============================================================================

# Ensure standard system binary search paths for terminal and background daemon shells
PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# 1. Remount CMU root and persistent storage partitions read-write
mount -o remount,rw / 2>/dev/null || mount -o rw,remount / 2>/dev/null
mount -o remount,rw /tmp/mnt/data_persist 2>/dev/null || mount -o rw,remount /tmp/mnt/data_persist 2>/dev/null
if [ -d "/mnt/data_persist" ] && [ ! -L "/mnt/data_persist" ]; then
    mount -o remount,rw /mnt/data_persist 2>/dev/null || mount -o rw,remount /mnt/data_persist 2>/dev/null
fi

case "$0" in
    /*) SCRIPT_DIR="${0%/*}" ;;
    */*) SCRIPT_DIR="$(cd "${0%/*}" 2>/dev/null && pwd)" ;;
    *) SCRIPT_DIR="$(pwd)" ;;
esac
[ -z "$SCRIPT_DIR" ] && SCRIPT_DIR="$(pwd)"

# Remount USB drive read-write with open permissions
mount -o remount,rw "$SCRIPT_DIR" 2>/dev/null
mount -o remount,rw,umask=000 "$SCRIPT_DIR" 2>/dev/null

# 2. Synchronize CGI scripts to persistent www/cgi-bin so existing running daemons have all handlers
if [ -d "$SCRIPT_DIR/_autox/cgi-bin" ]; then
    mkdir -p /tmp/mnt/data_persist/autox/www/cgi-bin 2>/dev/null
    cp -rf "$SCRIPT_DIR/_autox/cgi-bin/"* /tmp/mnt/data_persist/autox/www/cgi-bin/ 2>/dev/null
    chmod 755 /tmp/mnt/data_persist/autox/www/cgi-bin/* 2>/dev/null

    if [ -d "/mnt/data_persist/autox/www" ] && [ ! -L "/mnt/data_persist" ]; then
        mkdir -p /mnt/data_persist/autox/www/cgi-bin 2>/dev/null
        cp -rf "$SCRIPT_DIR/_autox/cgi-bin/"* /mnt/data_persist/autox/www/cgi-bin/ 2>/dev/null
        chmod 755 /mnt/data_persist/autox/www/cgi-bin/* 2>/dev/null
    fi
fi

# 3. Prime status communication bus
_TS=$(date +%s 2>/dev/null || echo "0")
echo "$_TS UNINSTALL STATUS 0 AutoX USB Mounted. Ready for installation." > /tmp/autox_com_bus.tmp 2>/dev/null
mv -f /tmp/autox_com_bus.tmp /tmp/autox_com_bus 2>/dev/null

# 4. Dispatch directly to autoxrun.sh (Handles interactive jci-dialogs or explicit CLI actions)
if [ -f "$SCRIPT_DIR/_autox/autoxrun.sh" ]; then
    echo "$$ AutoX USB Session Active ($SCRIPT_DIR)" > /tmp/autox_usb_session.pid 2>/dev/null
    echo "[AutoX Autorun] Dispatching execution to autoxrun.sh..." > /dev/kmsg 2>/dev/null || true
    exec /bin/sh "$SCRIPT_DIR/_autox/autoxrun.sh" "$@"
fi

echo "[AutoX Autorun] ERROR: _autox/autoxrun.sh not found on USB drive ($SCRIPT_DIR)." > /dev/kmsg 2>/dev/null || true
exit 1